# Third-party notices

## ESP-IDF v4.4.7

This project integrates a custom hook/monitor with Espressif's original ESP-IDF v4.4.7 second-stage bootloader and bootloader_support code.

- Original ESP-IDF source code: Copyright (C) 2015–2022 Espressif Systems.
- License for original Espressif-authored ESP-IDF source: Apache License 2.0.
- Upstream source: https://github.com/espressif/esp-idf/tree/v4.4.7
- Upstream license: `LICENSES/Apache-2.0.txt`
- Upstream copyright and third-party inventory: `https://github.com/espressif/esp-idf/blob/v4.4.7/docs/en/COPYRIGHT.rst`

The ESP-IDF v4.4.7 source tree states that original source code in that repository is licensed under Apache License 2.0. It also contains third-party code under separate licenses. Where an individual source file has its own copyright or license header, that file's notice takes precedence over this summary.

The stock second-stage bootloader and `bootloader_support` source are from the ESP-IDF checkout. The hook build also compiles source files from the external `$IDF_PATH`, including `opiram_psram.c`, `spi_timing_config.c`, and `spi_flash_timing_tuning.c` for ESP32-S3 OPI PSRAM/SPI-flash timing. Those upstream files are not relicensed by this repository. Their upstream notices and license terms must be retained.

## Firmware-specific dependency inventory

The exact third-party material linked into a firmware image depends on the ESP-IDF configuration and the components pulled into the second-stage bootloader. Check the actual ESP-IDF v4.4.7 checkout and generated build artifacts before redistribution. ESP-IDF's v4.4.7 copyright inventory identifies, among others, Newlib (BSD), Xtensa headers (MIT), FreeRTOS (MIT), lwIP (BSD), linenoise (BSD-2-Clause), Mbed TLS (Apache-2.0), and other optional components. This list is not a claim that every listed component is present in this bootloader image.

Do not remove or replace individual upstream copyright headers. Keep the applicable third-party license texts and attribution notices with any binary distribution.

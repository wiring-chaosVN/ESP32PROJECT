# ESP32-OS Bootloader v1.0.0

v1.0.0 first release for ESP32-S3 N16R8. The project is still under hardware bring-up; see the validation notes below before flashing.

Prototype bootloader/monitor for ESP32-S3 N16R8, pinned to **ESP-IDF v4.4.7**. The partition layout is organized as follows: ESP-IDF's partition table is retained as the primary bootloader-format table, but it only declares the `nexus_ptb` anchor and a factory/recovery placeholder. A separate binary, CRC-protected `nexus.ptb` (MTD table: mtd0 bootloader, mtd1 romfile, mtd2 kernel, mtd3 rootfs, mtd4 rootfs_data, mtd5 dtb) describes the ESP-OS partitions and their virtual addresses. See docs/NEXUS_PTB.md.

> **Verification status:** source/static validations can be run locally with the included scripts, but this source revision has not been compiled by a real ESP-IDF v4.4.7 toolchain or tested on hardware in this workspace. Run the GitHub Actions workflow before flashing. Do not enable Secure Boot or flash-encryption eFuses during initial bring-up.

## Boot architecture

1. The ESP-IDF ROM loads the second-stage bootloader at flash offset `0x0`. ESP-IDF's `bootloader_init()` initializes the flash path before the after-init hook. The hook keeps the ESP-IDF-configured UART0 clock/baud, initializes octal PSRAM using the ESP-IDF v4.4.7 device/timing sources, detects its capacity, maps the detected physical range, prints the usable PSRAM range, and waits 1000 ms for a key. A dot is printed every 200 ms. Any key enters the monitor.
2. Automatic boot runs a read-only POST. The monitor's destructive commands are not run during POST.
3. POST validates the standard ESP-IDF partition table, locates `nexus_ptb`, validates `nexus.ptb` header/CRC/entries/non-overlap, verifies the native ESP kernel image, and checks the `ROMF`/`RAMD` blob headers and payload CRC32. `rootfs` is a raw filesystem, so the bootloader only tests flash readability; filesystem integrity is filesystem-specific. `rootfs_data` is checked for a declared region, not for a particular filesystem/config format.
4. If checks pass, the hook calls ESP-IDF's own image loader using the **kernel position from `nexus.ptb`**, not the standard factory app position. A native ESP-IDF segmented image is required: ESP-IDF maps IROM/DROM segments through its cache/MMU setup and loads any image segments declared for IRAM/DRAM. Just before that call the bootloader writes the `NBIF` boot-info block into the reserved first 4 KiB of PSRAM and refuses to boot if it cannot (see "Boot-info handed to the kernel"). Thus the whole kernel is not copied into RAM; code/data that the image format explicitly places in RAM still follows ESP-IDF's loader rules.
5. The bootloader initializes and maps PSRAM before monitor entry. Its PSRAM base is computed from the detected size and ESP-IDF v4.4.7's ESP32-S3 external-data window; for an 8-MiB device the mapped range is `0x3D800000..0x3E000000`. The first 4 KiB are reserved and excluded from monitor operations. Internal SRAM/IRAM buffers remain private to the bootloader. A `ramdisk` MTD, if you define one, remains on flash through POST/handoff; kernel startup owns copying and mounting the RAMD payload. Kernel startup must coordinate any later PSRAM reconfiguration with the bootloader's mapping and must not assume memory contents survive a PSRAM reinitialization or memory test.
6. On a POST/image failure, the bootloader stays in `bldr>` and does not return to normal ESP-IDF factory/OTA selection. Use `mtd`, `crc32`, `verify`, or reflash a valid image and retry `go`. If the image-loader handoff itself hits a fatal ESP-IDF load error, ESP-IDF's loader may reset the device.

## Device tree (DTB) and black screen initialization

On startup the UART console prints a small attribution line, `Wiring-ChaosVN by Nick`. The `version` command prints the full identity: the watermark `By Wiring-ChaosVN`, version, target, NBIF/NPTB format versions, flash/UART/PSRAM state, the GNU GPL v3.0 notice for the project code and the Apache-2.0 attribution for the original Espressif ESP-IDF v4.4.7 bootloader that this project hooks into. All of it is compiled into the second-stage bootloader image, not added later by the CI packaging step.

The bootloader also has a deliberate cosmetic pause of roughly 50–200 ms before selected POST/status messages. It is only a presentation effect; it is not a hardware timing requirement. Set `BLDR_FX_MIN_MS` and `BLDR_FX_SPAN_MS` to `0` in `hooks.c` to disable it.


`board.dts` describes the board: which pins do what, plus the detail of attached hardware (display, I2C devices, SD card, ...). `tools/build_dtb.py` compiles it with `dtc` to `board.dtb`, which CI flashes to the `dtb` MTD (`0x22000`, 56 KiB, writable with `unlock`). Schema and examples: `docs/DTS.md`.

The bootloader reads **only** the enabled node named `display*` and the SPI node its `bus` property names (`bldr_dt.c`, a bounds-checked read-only FDT reader, fuzz-tested under ASAN). Everything else is for the kernel, and external flash / SD cards are never touched by the bootloader, which only exposes the internal-flash MTDs.

The bootloader works without a display: with no DTB, an invalid DTB, no display node, a disabled node or an unsupported controller it silently skips the display (nothing is logged) and does **not touch any GPIO**. When a supported ST7735 display (`sitronix,st7735s` or `sitronix,st7735`) is listed, `bldr_display.c` initializes the panel and writes the pixel value needed to display black across the full 132x162 controller GRAM (including the configured inversion mode) before enabling the display/backlight. This happens exactly once per boot, at the very start of the hook, so the panel never shows a white screen. It does not draw a logo or text. The pins and panel options come from the DTB. The kernel owns the display after hand-off and can initialize its UI later.

## Partition table ownership

The ESP-IDF table at `CONFIG_PARTITION_TABLE_OFFSET=0x20000` contains only:

| Label | Offset | Size | Purpose |
|---|---:|---:|---|
| `nexus_ptb` | `0x21000` | `0x1000` | Stores the binary `nexus.ptb` MTD table |
| `factory` | `0x30000` | `0x100000` | ESP-IDF-format recovery app (not an MTD, so the monitor cannot rewrite it); not the ESP-OS kernel |

`partitions.csv` configures this primary table. The CI image includes `nexus.ptb` at flash offset `0x21000` and `board.dtb` at `0x22000`. The bootloader binary size check ensures the second-stage image remains before the partition table.

The generated custom layout for a **16-MiB flash** is:

| Region | Offset | Size | Format/access |
|---|---:|---:|---|
| bootloader (mtd0) | `0x000000` | `0x20000` (128 KiB) | Second-stage bootloader, read-only |
| ESP-IDF table | `0x020000` | `0x1000` | Primary table (anchor + recovery), not an MTD |
| `nexus.ptb` | `0x021000` | `0x1000` | This MTD table (IDF label `nexus_ptb`), not an MTD |
| `dtb` (mtd5) | `0x022000` | `0xE000` (56 KiB) | Device-tree blob, writable with monitor unlock |
| recovery (`factory`) | `0x030000` | `0x100000` (1 MiB) | ESP-IDF recovery app, IDF table only |
| `kernel` (mtd2) | `0x130000` | `0x600000` (6 MiB) | Native ESP image, XIP-capable, writable only with monitor unlock |
| `rootfs` (mtd3) | `0x730000` | `0x600000` (6 MiB) | Raw read-only base filesystem by OS convention; monitor unlock permits reflashing |
| `rootfs_data` (mtd4) | `0xD30000` | `0x2CF000` (~2.81 MiB) | Mutable overlay/config storage |
| `romfile` (mtd1) | `0xFFF000` | `0x1000` | ROMF defaults/calibration blob, protected read-only in monitor |

There is no default `ramdisk` MTD any more (the initramfs can come from a PSRAM boot image); if you add one named `ramdisk` as a `blob` row, POST still checks its `RAMD` header/CRC. `dtb` is optional: without it the bootloader simply has no display.

**Boot-info handed to the kernel.** On every hand-off (`go`, automatic boot, `jump`) the bootloader writes an `NBIF` v3 block into the reserved first 4 KiB of PSRAM (PSRAM physical offset 0), containing the MTD rows, flash size, the DTB flash offset/size, the current UART0 baud (`uart_baud`) and flags, protected by a CRC32. It refuses to boot the kernel if the block cannot be written (no PSRAM). The kernel must read it before running any PSRAM memory test or zeroing. Layout: `docs/NEXUS_PTB.md`.

`nexus.ptb.csv` is the human-readable source; `tools/generate_nexus_ptb.py` validates it and writes the binary `nexus.ptb`: 16-byte header (`NPTB`, version, count, total size, CRC32 of rows) followed by 32-byte rows (`name[16]`, offset, size, vaddr, kind, flags; row index = MTD number). The table is independent of the standard ESP-IDF table; the bootloader validates that neither the custom entries nor the primary table overlap.

> The chosen offsets are for **16 MiB only**. If the flash capacity or recovery partition changes, update both `partitions.csv` and `nexus.ptb.csv`, then rerun the generator and rebuild. Do not manually edit the generated `nexus.ptb` without recalculating its CRC.

## RAMD/ROMF image format

`ramdisk` and `romfile` start with a 16-byte little-endian header:

| Field | Size | Meaning |
|---|---:|---|
| magic | 4 bytes | ASCII `RAMD` or `ROMF` |
| version | 4 bytes | unsigned little-endian integer, currently `1` |
| payload_size | 4 bytes | payload bytes following the header |
| payload_crc32 | 4 bytes | IEEE CRC32 of the payload only |

Payload size must fit inside the corresponding partition. Create a wrapped blob with:

```sh
python3 tools/make_os_blob.py --magic ROMF --input romfile.defaults.example --output romfile.bin --max-size 0x1000
python3 tools/make_os_blob.py --magic RAMD --input ramdisk.img --output ramdisk.bin --max-size 0x200000
```

`romfile.defaults.example` is a sample key/value payload schema for the **kernel** to interpret. The bootloader treats ROMF as opaque bytes and only validates its header/CRC. `rootfs` is raw and has no generic payload CRC in this build; use a filesystem-specific verifier if one is defined. `rootfs_data` format and first-boot initialization are kernel responsibilities. The sample password policy intentionally requires first-boot setup rather than a universal hard-coded password.

## UART monitor commands

All commands support `-h`/`--help`, and `help [command]` displays usage. Arrow/function-key escape sequences are ignored by the line editor. CRC32 uses the chip's ROM routine (fast enough to check a 2-MiB ramdisk during POST).

| Command | Behavior |
|---|---|
| `help [command]` | List commands/show help |
| `version` | Build version |
| `partitions`, `mtd` | Validate and list custom `nexus.ptb` regions |
| `go [mtdN\|label]` | Run POST and hand off to the esp-image selected in `nexus.ptb` (default `kernel`) |
| `reboot` | Reset the chip |
| `verify <label>` | Validate a native ESP image in a custom partition |
| `verify <flash_addr> <len>` | Validate an ESP image at an internal-flash offset |
| `crc32 <label>` | Verify native kernel image or RAMD/ROMF payload CRC; raw rootfs has no generic CRC |
| `unlock <label>` | Arm one destructive command on an unlocked, writable custom region (single-use, 30-s expiry) |
| `erase <label>` | Erase a complete writable partition; requires `unlock` |
| `erase <flash_addr> <blocks>` | Erase aligned 4-KiB sectors; range must fit a writable custom partition and requires `unlock` |
| `flash <flash_addr> <psram_addr> <len>` | Program a writable custom flash partition from a validated PSRAM range; requires `unlock` and erased/compatible target contents; every chunk is read back and compared (plain writes), so a write to non-erased flash fails with `verify failed (erase first?)` |
| `dump <flash_addr> <len> <psram_addr>` | Copy internal-flash bytes into a validated PSRAM range |
| `info` | Show CPU frequency, UART baud, flash size and PSRAM status |
| `xmdm <psram_addr_hex> <len_hex>` | Receive XMODEM/CRC into PSRAM using a private 1-KiB SRAM packet staging buffer |
| `xmdm flash <label> <offset> <max_len>` | Receive XMODEM into a custom partition; a packet is written only after sequence and CRC validation; requires `unlock` |
| `jump <psram_addr>` | Start an NPIM image in PSRAM (XIP via IBUS, header-only check, no CRC; a2 = boot-info). Untested on hardware |
| `baud <rate>` | Change shared UART0 console/XMODEM baud temporarily |

The monitor keeps a 256-byte SRAM buffer for POST, a separate 1-KiB internal-SRAM (DRAM) XMODEM packet staging buffer, and a 256-byte flash-I/O scratch buffer. These internal buffers are never valid monitor addresses. All user-addressed RAM operations pass through the dynamically detected PSRAM range validator; arbitrary SRAM, IRAM, flash-mapped pointers, MMIO and out-of-range PSRAM are rejected. XMODEM stages a complete SOH/STX packet privately, checks block complement, sequence and CRC, and only then commits accepted bytes to PSRAM or flash. `jump` accepts only a 64-KiB-aligned PSRAM address holding an `NPIM` header (see docs/NEXUS_PTB.md). The verbose `info`, `memrl`, `memwl`, and `cpufreq` diagnostics were removed to limit second-stage size. The monitor does not load the RAMD blob into PSRAM; the OS kernel controls the later load/mount lifecycle.

### XMODEM semantics retained

- Session timeout is one absolute 15 seconds from command invocation. `C` is sent every second only before the first SOH/STX packet; once transfer begins, no more `C` is sent.
- `Received len=<HEX>` reports accepted payload bytes, excluding protocol framing and detected trailing `0x1A` padding. It prints on timeout/EOT/completion and returns to `bldr>`.
- If EOT arrives early, ACK it and continue waiting until the same absolute deadline. `baud` controls the actual UART speed used by both console and XMODEM; reset restores 115200. The current baud is handed to the kernel in the NBIF block (`uart_baud`); the bootloader does not restore 115200 at hand-off.
- `xmdm` addresses are hexadecimal. The supplied range must fit entirely in the detected PSRAM user region (the first 4 KiB are reserved); internal SRAM/IRAM addresses such as `0x3FC...` or `0x403...` are rejected. For an 8-MiB PSRAM, the normal mapped region ends at `0x3E000000` and monitor data starts at `0x3D801000`.

## GitHub Actions build

Workflow: `.github/workflows/build_v1.0.0.yml`, triggered manually by `workflow_dispatch`. It uses ESP-IDF v4.4.7 for `esp32s3`, generates `nexus.ptb` from `nexus.ptb.csv`, compiles `board.dts` to `board.dtb` (`dtc` is installed by the workflow), runs the DTB reader tests, validates the monitor memory policy, builds the bootloader/recovery placeholder, checks the second-stage image remains below `0x20000`, merges the ESP-IDF flash image plus the custom table and the DTB, and uploads the firmware artifacts, bootloader ELF/map, size summaries, and checksums. CI builds the infrastructure and packages a sample `ROMF` defaults blob; it does **not** supply a finished ESP-OS kernel, rootfs or ramdisk. The sample deliberately marks calibration as not calibrated and requires first-boot setup; a newly flashed build therefore remains in the monitor until a valid kernel and RAMD image are installed.

1. Upload `esp32-os-bootloader-source.zip` to the repository root; the workflow extracts it to `esp32-os-bootloader/`.
2. Open **Actions → ESP32-OS Bootloader build_v1.0.0 → Run workflow**.
3. If it fails, inspect the uploaded build logs and fix the actual compile/link error before flashing.
4. Flash only after successful CI, and install a valid native kernel image at `0x130000`, raw rootfs at `0x530000`, and `rootfs_data` at `0xB30000` (the initramfs travels inside the PSRAM NPIM image). CI also embeds `nexus.ptb` at `0x21000` and a sample `ROMF` defaults blob at `0xFFF000`. Validate the host-generated image sizes against the table before writing.
5. Use UART0 at 115200 baud; during the first 1000 ms, press a key to enter `bldr>`.

**Important:** the native ESP-IDF image loader establishes XIP mappings only for a valid ESP image compiled/linked for the target memory map. Merely putting an arbitrary binary in `kernel` or jumping to its offset is not sufficient. The bootloader initializes PSRAM for monitor/POST use, but kernel integration must explicitly coordinate its own external-memory startup: the standard ESP-IDF application startup may reconfigure PSRAM and perform a memory test, so do not rely on monitor-staged PSRAM bytes surviving that handoff. The RAMD blob remains on flash and should be loaded/mounted by the kernel's defined startup path.


## Copyright and license

Project-authored source files are Copyright (C) 2026 Wiring-ChaosVN by Nick and released under **GNU GPL-3.0-only**. See `LICENSE`. This program comes with ABSOLUTELY NO WARRANTY; it is free software and may be redistributed under the terms of the GPL v3.0.

ESP-IDF v4.4.7 and other upstream code retain their own licenses and notices. This project is the original Espressif ESP-IDF v4.4.7 second-stage bootloader (Copyright (C) 2015–2022 Espressif Systems, Apache License 2.0) extended with a hook/monitor; the Espressif code is not relicensed. Third-party components may use other licenses. The `version` monitor command prints these notices. See `NOTICE` and `THIRD_PARTY_NOTICES.md`.

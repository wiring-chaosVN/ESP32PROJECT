# ESP32-OS Bootloader v1.0.1

## Release notes

This is the v1.0.1 maintenance release of the ESP32-S3 bootloader/monitor source.

Target board: ESP32-S3 N16R8  
Build environment: ESP-IDF v4.4.7  
Expected memory: 16 MiB QIO flash, 8 MiB octal PSRAM

## What is included

- UART monitor with partition listing, image checks, CRC32, flash read/write, erase, XMODEM and baud-rate commands.
- ESP-IDF image verification and kernel hand-off.
- Custom MTD table with header and CRC validation.
- PSRAM initialization and range checks. The first 4 KiB are reserved for boot information.
- NBIF v3 boot information, including the active UART baud rate.
- Optional device-tree display support; supported ST7735 panels are initialized and cleared to black (no logo).
- Host-side checks for the monitor, memory policy, table layout and blob format.
- GitHub Actions workflow for building and packaging the firmware.

## Validation

The included host-side check was run successfully:

```sh
python3 tests/check_monitor_features.py
```

The ESP-IDF build and on-device behavior have **not** been verified as part of this package. In particular, PSRAM startup, cache/MMU mapping, UART transfers, flash operations and kernel hand-off still need testing on an ESP32-S3 N16R8.

Do not treat a successful host-side check as proof that the firmware is safe to flash. Run the CI build, inspect the linker output and test on a recoverable board before using it on a device containing important data.

## Before flashing

1. Build with the included GitHub Actions workflow.
2. Check that the bootloader fits below `0x20000`.
3. Confirm that the generated flash map matches the actual 16 MiB flash.
4. Install a kernel image built for this memory map.
5. Keep Secure Boot and flash-encryption eFuses untouched during initial bring-up.

## Known limitations

- The CI package contains the bootloader and a sample ROMF blob, not a complete ESP-OS kernel or root filesystem.
- The `jump` path is present but has not been tested on hardware.
- A kernel must coordinate its PSRAM startup with the mapping established by the bootloader.
- The raw rootfs has no generic integrity check; filesystem validation belongs to the OS.

## Startup presentation

The UART startup banner includes the compiled-in watermark `Wiring-ChaosVN by Nick`. Selected POST/status messages use an intentional 50–200 ms cosmetic delay; this is not a hardware timing requirement.

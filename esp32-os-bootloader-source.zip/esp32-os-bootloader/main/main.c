/*
 * SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
 * SPDX-License-Identifier: GPL-3.0-only
 */
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

/*
 * Recovery placeholder in the ESP-IDF factory slot. The second-stage hook
 * should boot the ESP-OS kernel directly from partition.vcs. If this task runs,
 * the custom handoff did not occur; it must not be mistaken for the OS kernel.
 */
void app_main(void)
{
    printf("\nESP-OS recovery/factory placeholder\n");
    printf("No kernel handoff occurred; check the second-stage hook and partition.vcs.\n");
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

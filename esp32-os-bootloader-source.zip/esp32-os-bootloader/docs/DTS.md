# board.dts: hardware description for the bootloader and kernel

`board.dts` is compiled with `dtc` (`python3 tools/build_dtb.py`, CI does it) to `board.dtb` and flashed to the `dtb` MTD at `0x22000` (max 56 KiB). One file serves two purposes: plug-and-play pin assignment (which GPIO does what) and detail for attached hardware.

## What the bootloader reads
Only two things, everything else is ignored:

| Node | Properties |
|---|---|
| the first **enabled** node whose name starts with `display` | `compatible` (`sitronix,st7735s` or `sitronix,st7735`), `bus` (string), `width`, `height`, `dc-gpios`; optional `rotation` (0..3, TFT_eSPI numbering, default 0), `x-offset`, `y-offset` (0..8), `color-order` (`"bgr"` default, or `"rgb"`), `invert`, `cs-gpios`, `reset-gpios`, `backlight-gpios`, `backlight-active-low` |
| the node whose **node name** equals the display's `bus` string (e.g. `spi2: spi2 { ... }`) | `status` (absent or `"okay"`), `sck-gpios`, `mosi-gpios` |

A GPIO property is one cell holding the GPIO number. Valid pins: 0..48 except 22..25 (do not exist on ESP32-S3), 26..37 (flash / octal PSRAM on N16R8), 43/44 (UART0 console); pins must be distinct. Width 64..132, height 64..162 (ST7735 GRAM is 132x162).

If the display node is missing, disabled, an unsupported controller, or has a bad/missing required property, the bootloader skips the boot logo, prints the reason on the console (`info`) and does not touch any GPIO. A missing or invalid DTB behaves the same. Labels (`display:`) are not stored in the DTB; the SPI node is found by its node name, so name it exactly like the `bus` string.

## Kernel-side hardware (the bootloader does not read these)
Use the same style so the kernel can plug and play. Suggested conventions:

```dts
/* I2C bus with devices: pins, frequency, per-device address and name */
i2c0: i2c0 {
    compatible = "espressif,esp32-i2c";
    status = "okay";
    sda-gpios = <1>;
    scl-gpios = <2>;
    clock-frequency = <400000>;

    imu: imu@68 {
        compatible = "invensense,mpu6050";
        reg = <0x68>;
        label = "imu0";
        interrupt-gpios = <4>;
    };
};

/* External storage: the bootloader never touches it, it only exposes internal flash MTDs */
sd0: sdcard {
    compatible = "espressif,esp32-sdmmc";   /* or "espressif,esp32-sdspi" */
    status = "okay";
    bus-width = <4>;                         /* 1 or 4 */
    clk-gpios = <38>;
    cmd-gpios = <39>;
    d0-gpios = <40>; d1-gpios = <41>; d2-gpios = <42>; d3-gpios = <47>;
    card-detect-gpios = <48>;
};

/* An external SPI flash instead of the SD card */
ext_flash: flash@0 {
    compatible = "jedec,spi-nor";
    bus = "spi3";
    cs-gpios = <21>;
    spi-max-frequency = <40000000>;
};
```
`chosen/bootargs` is the kernel command line; `memory` documents flash and PSRAM size (the bootloader uses the detected sizes, not these). `board.dts` ships with placeholder pins: set your real wiring before flashing.

## Updating only the DTB
Rebuild `board.dtb`, then in the monitor: `unlock dtb`, `xmdm`/`flash` to the `dtb` MTD (see `help flash`), `reboot`. No kernel rebuild is needed.

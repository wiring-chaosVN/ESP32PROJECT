# nexus.ptb, MTD map and PSRAM boot (NPIM)

## nexus.ptb (flash 0x21000, binary, little-endian)
Header 16 B: `"NPTB"`, u16 version=1, u16 count (5..8), u32 total_size, u32 crc32(rows).
Row 32 B: `name[16]`, u32 offset, u32 size, u32 vaddr, u16 kind, u16 flags. Row index = MTD number.
kind: 0 boot, 1 esp-image, 2 raw, 3 blob, 4 data. flags: bit0 read-only, bit1 XIP, bit2 encrypted.
vaddr is the virtual-address convention (0 = none): 0x3Cxxxxxx data bus / 0x42xxxxxx instruction bus, with the same low 16 bits as the flash offset (64-KiB MMU page).

Default map: mtd0 bootloader 0x0/0x20000 (ro) · mtd1 romfile 0xFFF000 (ro) · mtd2 kernel 0x130000/6 MiB (esp-image, XIP) · mtd3 rootfs 0x730000/6 MiB · mtd4 rootfs_data 0xD30000 · mtd5 dtb 0x22000/56 KiB (optional, rw).
Not MTDs: the ESP-IDF table (0x20000), this table (0x21000) and the recovery app (0x30000, 1 MiB, IDF table only).
Edit `nexus.ptb.csv`, run `python3 tools/generate_nexus_ptb.py`. Commands accept `mtdN` or the label (`go mtd2`, `crc32 mtd1`, `unlock mtd3`).

## jump <psram_addr> (NPIM)
`tools/make_psram_image.py kernel.bin out.npim [--initramfs x.cpio]` builds: 32-byte header (`NPIM`, ver 1, flags XIP, entry, vbase, image_size, initramfs_off, initramfs_size, 0) padded to 4 KiB, then the kernel linked for `vbase+0x1000`, then the initramfs (4-KiB aligned).
Upload with `xmdm <addr>` (addr 64-KiB aligned in PSRAM), then `jump <addr>`. No CRC is checked; only header sanity and range.
The bootloader maps the image pages onto the instruction bus at `vbase` and calls the entry with a2 = boot-info address. The watchdog stays armed; the image must feed or disable it. Untested on hardware.

## Boot-info block `NBIF` v2 (every kernel hand-off)
Written by `go`, automatic boot and `jump` alike, so the kernel never has to guess. Location: the reserved first 4 KiB of PSRAM, i.e. **PSRAM physical offset 0**. A native ESP-IDF kernel started by the IDF loader receives no argument register, and it maps PSRAM itself, so it must find the block by physical offset (map PSRAM, read the first 4 KiB). Read and validate it **before** any PSRAM memory test or clearing; disable `CONFIG_SPIRAM_MEMTEST` in the kernel or copy the block first. `jump` additionally passes the data-bus address in a2.

Little-endian, 56-byte header then `mtd_count` 32-byte nexus.ptb rows (same layout as flash):
`magic "NBIF"`, u16 version=2, u16 mtd_count, u32 psram_base (bootloader data-bus address, informational), u32 psram_size, u32 image_addr, u32 image_size, u32 vbase, u32 initramfs_addr, u32 initramfs_size (these five are 0 for the flash boot path), u32 flash_size, u32 boot_flags, u32 dtb_offset, u32 dtb_size, u32 crc32.
boot_flags: bit0 kernel loaded from flash MTD, bit1 started by `jump`, bit2 DTB valid (dtb_offset/dtb_size usable), bit3 the bootloader drew the boot logo. crc32 = IEEE CRC32 (zlib) of the header with crc32 = 0 plus the rows.
The DTB is not copied: the kernel reads it from flash at dtb_offset (mtd `dtb`).

## Filesystem advice
initramfs: cpio newc. rootfs (read-mostly): ROMFS/CramFS-style, or SquashFS if compression is needed. rootfs_data (writable): LittleFS.

#!/usr/bin/env python3
"""Compile board.dts -> board.dtb with dtc and check it fits the 'dtb' MTD.

usage: build_dtb.py [board.dts [board.dtb]]
"""
from pathlib import Path
import csv, shutil, struct, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]


def dtb_mtd_size():
    with (ROOT / "nexus.ptb.csv").open(newline="") as f:
        for r in csv.reader(l for l in f if l.strip() and not l.lstrip().startswith("#")):
            if r[0].strip() == "dtb":
                return int(r[2], 0)
    raise SystemExit("nexus.ptb.csv has no 'dtb' row")


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "board.dts"
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "board.dtb"
    if shutil.which("dtc") is None:
        raise SystemExit("dtc not found (apt install device-tree-compiler)")
    r = subprocess.run(["dtc", "-I", "dts", "-O", "dtb", "-o", str(out), str(src)],
                       capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write(r.stderr)
        raise SystemExit("dtc failed")
    d = out.read_bytes()
    magic, total = struct.unpack(">II", d[:8])
    limit = dtb_mtd_size()
    if magic != 0xD00DFEED or total != len(d):
        raise SystemExit("board.dtb header is inconsistent")
    if total > limit:
        raise SystemExit(f"board.dtb is {total} bytes, 'dtb' MTD holds {limit}")
    print(f"Generated {out.name}: {total} bytes (limit {limit})")


if __name__ == "__main__":
    main()

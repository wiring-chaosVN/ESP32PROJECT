#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
# SPDX-License-Identifier: GPL-3.0-only
"""Wrap an OS data file with the ESP-OS RAMD/ROMF header checked by bootloader."""
import argparse
from pathlib import Path
import struct
import zlib

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--magic", choices=("RAMD", "ROMF"), required=True)
p.add_argument("--input", type=Path, required=True, help="Payload file, without the 16-byte header")
p.add_argument("--output", type=Path, required=True)
p.add_argument("--max-size", type=lambda v: int(v, 0), help="Optional partition size including the header")
a = p.parse_args()
payload = a.input.read_bytes()
if not payload:
    p.error("payload must not be empty")
header = a.magic.encode("ascii") + struct.pack("<III", 1, len(payload), zlib.crc32(payload) & 0xFFFFFFFF)
image = header + payload
if a.max_size is not None and len(image) > a.max_size:
    p.error(f"image is {len(image)} bytes and exceeds partition size {a.max_size}")
a.output.parent.mkdir(parents=True, exist_ok=True)
a.output.write_bytes(image)
print(f"Wrote {a.output}: header=16 bytes payload={len(payload)} total={len(image)} CRC32=0x{zlib.crc32(payload) & 0xFFFFFFFF:08X}")

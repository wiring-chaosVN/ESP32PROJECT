#!/usr/bin/env python3
"""Pack an NPIM image for `jump <psram_addr>` (XIP from PSRAM via the instruction bus).

usage: make_psram_image.py kernel.bin out.npim [--initramfs rootfs.cpio] [--vbase 0x42000000] [--entry-off 0x1000]
The kernel binary must be linked for vbase + 0x1000 (header occupies the first 4 KiB).
Upload with `xmdm <psram_addr>` (64-KiB aligned) then `jump <psram_addr>`. No CRC is checked.
"""
import argparse, struct
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("kernel"); ap.add_argument("out")
ap.add_argument("--initramfs"); ap.add_argument("--vbase", type=lambda x: int(x, 0), default=0x42000000)
ap.add_argument("--entry-off", type=lambda x: int(x, 0), default=0x1000)
a = ap.parse_args()
if a.vbase % 0x10000 or not 0x42000000 <= a.vbase < 0x44000000 or a.entry_off % 4 or a.entry_off < 0x20:
    raise SystemExit("bad vbase/entry-off")
k = Path(a.kernel).read_bytes()
body = bytearray(k)
ird_off = ird_size = 0
if a.initramfs:
    ird = Path(a.initramfs).read_bytes()
    while (0x1000 + len(body)) % 0x1000:
        body.append(0)
    ird_off, ird_size = 0x1000 + len(body), len(ird)
    body += ird
size = 0x1000 + len(body)
hdr = struct.pack("<4sHHIIIIII", b"NPIM", 1, 1, a.vbase + a.entry_off, a.vbase, size, ird_off, ird_size, 0)
Path(a.out).write_bytes(hdr.ljust(0x1000, b"\0") + bytes(body))
print(f"NPIM {a.out}: size=0x{size:x} entry=0x{a.vbase + a.entry_off:08x} initramfs=0x{ird_off:x}+0x{ird_size:x}")

#!/usr/bin/env python3
"""Build the binary nexus.ptb (MTD table) from nexus.ptb.csv.

Layout (little-endian): header 16 B  = "NPTB", u16 version=1, u16 count, u32 total_size, u32 crc32(rows)
                        row 32 B     = name[16], u32 offset, u32 size, u32 vaddr, u16 kind, u16 flags
"""
from pathlib import Path
import csv, struct, sys, zlib

ROOT = Path(__file__).resolve().parents[1]
FLASH_SIZE = 0x1000000
SECTOR = 0x1000
PTB_OFFSET = 0x20000          # ESP-IDF partition table
ANCHOR_SIZE = 0x1000
KINDS = {"boot": 0, "esp-image": 1, "raw": 2, "blob": 3, "data": 4}
FLAGS = {"ro": 1, "rw": 0, "xip": 2 | 1, "xip-rw": 2, "enc": 4}
REQUIRED = ["romfile", "kernel", "rootfs", "rootfs_data"]


def vaddr_ok(v, off, size):
    if v == 0:
        return True
    ok = (0x3C000000 <= v and v + size <= 0x3E000000) or (0x42000000 <= v and v + size <= 0x44000000)
    return ok and ((v ^ off) & 0xFFFF) == 0


def main():
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "nexus.ptb.csv"
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "nexus.ptb"
    rows = []
    with src.open(newline="", encoding="ascii") as f:
        for r in csv.reader(l for l in f if l.strip() and not l.lstrip().startswith("#")):
            name, off, size, va, kind, fl = (x.strip() for x in r)
            rows.append((name, int(off, 0), int(size, 0), int(va, 0), kind, fl))
    if not 5 <= len(rows) <= 8:
        raise SystemExit("need 5..8 MTD rows")
    names = [r[0] for r in rows]
    if len(set(names)) != len(names) or any(not n or len(n) > 15 for n in names):
        raise SystemExit("labels must be unique, 1..15 chars")
    if not set(REQUIRED) <= set(names):
        raise SystemExit(f"missing: {sorted(set(REQUIRED) - set(names))}")
    if rows[0][4] != "boot" or rows[0][1] != 0 or rows[0][1] + rows[0][2] > PTB_OFFSET or "ro" not in rows[0][5]:
        raise SystemExit("mtd0 must be a read-only 'boot' row at 0x0 ending before the IDF table")
    by = {r[0]: r for r in rows}
    k = by["kernel"]
    if k[4] != "esp-image" or k[1] % 0x10000 or not FLAGS[k[5]] & 2:
        raise SystemExit("kernel: esp-image, 64K aligned, xip flag")
    if by["rootfs"][4] != "raw" or by["rootfs_data"][4] != "data" or by["romfile"][4] != "blob" or not FLAGS[by["romfile"][5]] & 1:
        raise SystemExit("kind/flags mismatch for rootfs/rootfs_data/romfile")
    if "dtb" in by and by["dtb"][4] != "blob":
        raise SystemExit("dtb must be a 'blob' row")
    spans = []
    for i, (n, off, size, va, kind, fl) in enumerate(rows):
        if kind not in KINDS or fl not in FLAGS:
            raise SystemExit(f"{n}: bad kind/flags")
        if i and kind == "boot":
            raise SystemExit("only mtd0 may be boot")
        if size == 0 or off % SECTOR or size % SECTOR or off + size > FLASH_SIZE:
            raise SystemExit(f"{n}: bad offset/size")
        if i and off < PTB_OFFSET + 2 * SECTOR:
            raise SystemExit(f"{n}: overlaps bootloader/table/anchor area")
        if not vaddr_ok(va, off, size):
            raise SystemExit(f"{n}: bad vaddr")
        spans.append((off, off + size, n))
    spans.sort()
    for a, b in zip(spans, spans[1:]):
        if a[1] > b[0]:
            raise SystemExit(f"overlap: {a[2]} / {b[2]}")
    body = b"".join(struct.pack("<16sIIIHH", n.encode(), off, size, va, KINDS[kind], FLAGS[fl])
                    for n, off, size, va, kind, fl in rows)
    crc = zlib.crc32(body) & 0xFFFFFFFF
    out.write_bytes(struct.pack("<4sHHII", b"NPTB", 1, len(rows), 16 + len(body), crc) + body)
    print(f"Generated {out.name}: {16 + len(body)} bytes, {len(rows)} MTDs, CRC32=0x{crc:08X}")


if __name__ == "__main__":
    main()

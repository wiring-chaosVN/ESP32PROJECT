#!/usr/bin/env python3
"""Generate CRC-protected partition.vcs from partition.vcs.csv."""
from pathlib import Path
import csv
import zlib

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "partition.vcs.csv"
OUTPUT = ROOT / "partition.vcs"
FLASH_SIZE = 0x1000000
SECTOR = 0x1000
IDF_TABLE_OFFSET = 0x20000
ANCHOR_OFFSET = 0x21000
ANCHOR_SIZE = 0x1000
FACTORY_START = 0x30000
FACTORY_SIZE = 0x100000
REQUIRED = {"kernel", "rootfs", "ramdisk", "rootfs_data", "romfile"}


def read_rows():
    rows = []
    with SOURCE.open(newline="", encoding="ascii") as f:
        for row in csv.reader(line for line in f if line.strip() and not line.lstrip().startswith("#")):
            if not row:
                continue
            if len(row) != 5:
                raise ValueError(f"Expected 5 CSV columns, got {len(row)}: {row}")
            name, offset, size, flags, kind = (part.strip() for part in row)
            rows.append((name, int(offset, 0), int(size, 0), flags, kind))
    return rows


def validate(rows):
    if ANCHOR_OFFSET != IDF_TABLE_OFFSET + SECTOR:
        raise ValueError("vcs_table must immediately follow the ESP-IDF table sector")
    names = [r[0] for r in rows]
    if len(names) != len(set(names)):
        raise ValueError("Duplicate partition labels")
    if not REQUIRED.issubset(names):
        raise ValueError(f"Missing required labels: {sorted(REQUIRED - set(names))}")
    ranges = []
    for name, offset, size, flags, kind in rows:
        if not name or len(name.encode("ascii")) > 16:
            raise ValueError(f"Invalid label: {name!r}")
        if offset % SECTOR or size <= 0 or size % SECTOR:
            raise ValueError(f"{name}: offset and size must be 4-KiB aligned")
        if offset < ANCHOR_OFFSET + ANCHOR_SIZE or offset + size > FLASH_SIZE:
            raise ValueError(f"{name}: outside allowed 16-MiB flash region")
        if flags not in {"ro", "rw", "xip-rw", "xip-ro", "enc-rw"}:
            raise ValueError(f"{name}: unsupported access flag {flags}")
        if kind not in {"esp-image", "raw", "blob", "data"}:
            raise ValueError(f"{name}: unsupported type {kind}")
        ranges.append((offset, offset + size, name))
    ranges.sort()
    for prev, cur in zip(ranges, ranges[1:]):
        if prev[1] > cur[0]:
            raise ValueError(f"Overlapping partitions: {prev[2]} and {cur[2]}")
    by_name = {row[0]: row for row in rows}
    kernel = by_name["kernel"]
    if kernel[1] % 0x10000 or kernel[3] not in {"xip-rw", "xip-ro"} or kernel[4] != "esp-image":
        raise ValueError("kernel must be a 64-KiB-aligned native ESP image marked XIP")
    if by_name["rootfs"][4] != "raw" or by_name["ramdisk"][4] != "blob" or by_name["romfile"][4] != "blob" or by_name["rootfs_data"][4] != "data":
        raise ValueError("rootfs/raw, ramdisk/blob, romfile/blob, rootfs_data/data types are required")
    if by_name["romfile"][3] != "ro":
        raise ValueError("romfile must be read-only in the bootloader table")
    if by_name["kernel"][1] != FACTORY_START + FACTORY_SIZE:
        raise ValueError("kernel start must follow the reserved ESP-IDF factory/recovery partition")
    if ranges[-1][1] != FLASH_SIZE:
        raise ValueError("The final partition must end at 16 MiB")


def main():
    rows = read_rows()
    validate(rows)
    row_bytes = "".join(
        f"{name},0x{offset:08X},0x{size:08X},{flags},{kind}\n"
        for name, offset, size, flags, kind in rows
    ).encode("ascii")
    # The size and CRC use fixed-width hex, which keeps the header length invariant.
    provisional = f"VCS1,1,{len(rows)},0x{0:08X},0x{0:08X}\n".encode("ascii")
    total_size = len(provisional) + len(row_bytes)
    crc = zlib.crc32(row_bytes) & 0xFFFFFFFF
    header = f"VCS1,1,{len(rows)},0x{total_size:08X},0x{crc:08X}\n".encode("ascii")
    assert len(header) == len(provisional)
    assert len(header) + len(row_bytes) == total_size
    OUTPUT.write_bytes(header + row_bytes)
    print(f"Generated {OUTPUT.name}: {total_size} bytes, {len(rows)} entries, rows CRC32=0x{crc:08X}")

if __name__ == "__main__":
    main()

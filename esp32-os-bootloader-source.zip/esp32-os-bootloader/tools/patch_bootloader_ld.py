#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Split bldr_hooks between iram_loader_seg and iram_seg (ESP-IDF v4.4.7, esp32s3).

iram_loader_seg (28 KiB) must hold code that survives while the app image is
being loaded. iram_seg (12 KiB) is overwritten by the load, but is only needed
before it, so POST/monitor/PSRAM code may live there. Only hooks.c (the big
monitor/POST object) is pinned to iram_loader_seg; every other bldr_hooks object
falls through to the catch-all .iram.text in iram_seg. IRAM_ATTR functions are
unaffected: *(.iram1 .iram1.*) already lands in iram_loader_seg.
"""
import os, sys
from pathlib import Path

RULE = "    *libbldr_hooks.a:hooks.c.obj(.literal .text .literal.* .text.*)\n"
OLD = "    *libbldr_hooks.a:*.*(.literal .text .literal.* .text.*)\n"
ANCHOR = "    *libspi_flash.a:*.*(.literal .text .literal.* .text.*)\n"

idf = os.environ.get("IDF_PATH") or sys.exit("IDF_PATH is not set")
ld = Path(idf) / "components/bootloader/subproject/main/ld/esp32s3/bootloader.ld"
t = ld.read_text()
if OLD in t:
    t = t.replace(OLD, "")          # undo the old whole-library rule
if RULE in t:
    print("already patched"); sys.exit(0)
if t.count(ANCHOR) != 1:
    sys.exit("anchor not found exactly once; is this ESP-IDF v4.4.7?")
ld.write_text(t.replace(ANCHOR, ANCHOR + RULE))
print("patched: hooks.c.obj -> iram_loader_seg, rest -> iram_seg")

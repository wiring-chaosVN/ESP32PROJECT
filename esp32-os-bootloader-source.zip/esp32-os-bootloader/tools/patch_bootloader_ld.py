#!/usr/bin/env python3
"""Place the bldr_hooks component in the bootloader's iram_loader_seg.

ESP-IDF v4.4.7's esp32s3 bootloader.ld gives `.iram.text` (iram_seg) only 12 KiB
and sends every component it does not list by name there. bldr_hooks (monitor,
POST, XMODEM, PSRAM init) is ~13 KiB, so the link fails with
"region `iram_seg' overflowed". iram_loader_seg (28 KiB) is where the stock
bootloader code runs, and bootloader_utility_load_boot_image() (noreturn) lives
there too, so hook code can safely live there as well.

This inserts one line into IDF's bootloader.ld. It is idempotent and fails loudly
if the anchor line is not found (i.e. the IDF version is not v4.4.7).
"""
import os
import sys
from pathlib import Path

RULE = "    *libbldr_hooks.a:*.*(.literal .text .literal.* .text.*)\n"
ANCHOR = "    *libspi_flash.a:*.*(.literal .text .literal.* .text.*)\n"

idf = os.environ.get("IDF_PATH")
if not idf:
    sys.exit("IDF_PATH is not set")
ld = Path(idf) / "components/bootloader/subproject/main/ld/esp32s3/bootloader.ld"
text = ld.read_text()
if RULE in text:
    print(f"{ld}: already patched")
    sys.exit(0)
if text.count(ANCHOR) != 1:
    sys.exit(f"{ld}: anchor line not found exactly once; is this ESP-IDF v4.4.7?")
ld.write_text(text.replace(ANCHOR, ANCHOR + RULE))
print(f"{ld}: patched (bldr_hooks -> iram_loader_seg)")

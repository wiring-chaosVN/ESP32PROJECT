/*
 * ESP32-OS bootloader UART monitor.
 * Target: ESP32-S3 / ESP-IDF v4.4.7.
 *
 * ESP-OS boot path for ESP32-S3 / ESP-IDF v4.4.7.
 * ESP-IDF's partition table anchors the reserved `vcs_table` storage region;
 * partition.vcs defines the OS regions. Kernel images use the native ESP-IDF
 * segmented image format so the bootloader can establish MMU/XIP mappings.
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>

#include "sdkconfig.h"
#include "esp_attr.h"
#include "esp32s3/rom/ets_sys.h"
#include "esp32s3/rom/uart.h"
#include "esp32s3/rom/rtc.h"
#include "esp32s3/rom/spi_flash.h"
#include "soc/rtc.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_struct.h"
#include "hal/wdt_hal.h"
#include "bootloader_flash_priv.h"
#include "bootloader_utility.h"
#include "bootloader_config.h"
#include "esp_flash_partitions.h"
#include "esp_image_format.h"
#include "esp_flash_encrypt.h"
#include "bldr_memory.h"

#define BLDR_VERSION             "2.1.0"
#define BLDR_TRIGGER_MS          500U
#define BLDR_MONITOR_MAX_MS      1800000U /* 30 minutes; watchdog is fed while waiting */
#define BLDR_LINE_MAX            128U
#define BLDR_ARG_MAX             8U
#define BLDR_SECTOR_SIZE         0x1000U
#define BLDR_FLASH_IO_CHUNK      256U
#define BLDR_XMODEM_PACKET_MAX   1024U
#define BLDR_RAM_BUFFER_SIZE     256U
#define BLDR_XMODEM_PACKET_BUFFER_SIZE 1024U
#define BLDR_XMODEM_SESSION_TIMEOUT_MS 15000U
#define BLDR_XMODEM_C_INTERVAL_MS      1000U
#define BLDR_UART_NUM            0U
#define XMODEM_SOH               0x01U
#define XMODEM_STX               0x02U
#define XMODEM_EOT               0x04U
#define XMODEM_ACK               0x06U
#define XMODEM_NAK               0x15U
#define XMODEM_CAN               0x18U
#define XMODEM_CRC_REQ           'C'

#define BLDR_VCS_ANCHOR_LABEL    "vcs_table"
#define BLDR_VCS_MAGIC           "VCS1"
#define BLDR_VCS_VERSION         1U
#define BLDR_VCS_MAX_ENTRIES     8U
#define BLDR_VCS_HEADER_MAX      96U
#define BLDR_VCS_FLAG_READ_ONLY  (1U << 0)
#define BLDR_VCS_FLAG_XIP        (1U << 1)
#define BLDR_VCS_FLAG_ENCRYPTED  (1U << 2)

enum {
    BLDR_VCS_KIND_ESP_IMAGE = 1U,
    BLDR_VCS_KIND_RAW_FS = 2U,
    BLDR_VCS_KIND_BLOB = 3U,
    BLDR_VCS_KIND_DATA = 4U,
};

typedef struct {
    char label[16];
    esp_partition_pos_t pos;
    uint32_t flags;
    uint32_t kind;
} vcs_partition_info_t;

static vcs_partition_info_t g_vcs_partitions[BLDR_VCS_MAX_ENTRIES];
static int g_vcs_partition_count;
static uint32_t crc32_ieee_update(uint32_t crc, const uint8_t *data, size_t len);

/* Internal buffers are private to bootloader code. The 256-byte RAM buffer is
 * only used by POST; the 1-KiB IRAM buffer stages one XMODEM packet. Neither is
 * exposed as a legal user-addressed destination/source. */
static uint8_t g_ram_buffer[BLDR_RAM_BUFFER_SIZE]
    __attribute__((section(".iram1"), aligned(32)));
static uint8_t g_xmodem_packet[BLDR_XMODEM_PACKET_BUFFER_SIZE]
    __attribute__((section(".iram1"), aligned(32)));
static uint8_t g_io_buffer[BLDR_FLASH_IO_CHUNK] __attribute__((aligned(32)));
static uint32_t g_monitor_elapsed_ms;
static bool g_skip_lf;
static bool g_unlock_armed;
static char g_unlock_label[17];
static uint32_t g_unlock_deadline_ms;
static uint32_t g_uart_baud = 115200U;

static void uart_putc(char c)
{
    (void)uart_tx_one_char((uint8_t)c);
}

static void uart_puts(const char *s)
{
    while (*s != '\0') {
        uart_putc(*s++);
    }
}

static void prompt(void)
{
    uart_puts("bldr> ");
}

static void set_uart_baud(uint32_t baud)
{
    uint32_t apb_hz = rtc_clk_apb_freq_get();
    if (apb_hz == 0U) apb_hz = 80000000U;
    uart_div_modify(BLDR_UART_NUM, (uint32_t)(((uint64_t)apb_hz << 4) / baud));
    g_uart_baud = baud;
}

static void feed_watchdog(void)
{
#if defined(CONFIG_BOOTLOADER_WDT_ENABLE) && CONFIG_BOOTLOADER_WDT_ENABLE
    static wdt_hal_context_t ctx = { .inst = WDT_RWDT, .rwdt_dev = &RTCCNTL };
    wdt_hal_write_protect_disable(&ctx);
    wdt_hal_feed(&ctx);
    wdt_hal_write_protect_enable(&ctx);
#endif
}

static void delay_1ms(void)
{
    ets_delay_us(1000);
    if (g_monitor_elapsed_ms < UINT32_MAX) {
        ++g_monitor_elapsed_ms;
    }
    if ((g_monitor_elapsed_ms & 0xFFU) == 0U) {
        feed_watchdog();
    }
}


static bool parse_u32(const char *s, uint32_t *out)
{
    uint32_t base = 10U;
    uint32_t v = 0U;
    const char *p = s;
    if (s == NULL || *s == '\0' || out == NULL || *s == '-') {
        return false;
    }
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) {
        base = 16U;
        p += 2;
        if (*p == '\0') return false;
    }
    for (; *p != '\0'; ++p) {
        uint32_t d;
        if (*p >= '0' && *p <= '9') d = (uint32_t)(*p - '0');
        else if (base == 16U && *p >= 'a' && *p <= 'f') d = 10U + (uint32_t)(*p - 'a');
        else if (base == 16U && *p >= 'A' && *p <= 'F') d = 10U + (uint32_t)(*p - 'A');
        else return false;
        if (d >= base || v > (UINT32_MAX - d) / base) return false;
        v = v * base + d;
    }
    *out = v;
    return true;
}

static bool parse_hex_u32(const char *s, uint32_t *out)
{
    uint32_t v = 0U;
    const char *p = s;
    if (p == NULL || *p == '\0' || out == NULL || *p == '-') return false;
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) p += 2;
    if (*p == '\0') return false;
    for (; *p != '\0'; ++p) {
        uint32_t d;
        if (*p >= '0' && *p <= '9') d = (uint32_t)(*p - '0');
        else if (*p >= 'a' && *p <= 'f') d = 10U + (uint32_t)(*p - 'a');
        else if (*p >= 'A' && *p <= 'F') d = 10U + (uint32_t)(*p - 'A');
        else return false;
        if (v > (UINT32_MAX - d) / 16U) return false;
        v = v * 16U + d;
    }
    *out = v;
    return true;
}

static int split_args(char *line, char **argv, int max_args)
{
    int argc = 0;
    char *p = line;
    while (*p != '\0') {
        while (*p == ' ' || *p == '\t') ++p;
        if (*p == '\0') break;
        if (argc >= max_args) return -1;
        argv[argc++] = p;
        while (*p != '\0' && *p != ' ' && *p != '\t') ++p;
        if (*p != '\0') *p++ = '\0';
    }
    return argc;
}

static bool command_has_help(int argc, char **argv)
{
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) return true;
    }
    return false;
}

static bool copy_xmodem_packet_to_io(uint32_t packet_offset, uint32_t len)
{
    if ((packet_offset & 3U) != 0U || len == 0U || len > sizeof(g_io_buffer) ||
        (len & 3U) != 0U || (uint64_t)packet_offset + len > BLDR_XMODEM_PACKET_MAX ||
        (uint64_t)packet_offset + len > sizeof(g_xmodem_packet)) return false;
    const volatile uint32_t *src = (const volatile uint32_t *)(g_xmodem_packet + packet_offset);
    uint32_t *dst = (uint32_t *)g_io_buffer;
    for (uint32_t i = 0U; i < len / sizeof(uint32_t); ++i) dst[i] = src[i];
    return true;
}

static bool load_idf_partition_table(const esp_partition_info_t **out, int *count)
{
    const esp_partition_info_t *table = bootloader_mmap(CONFIG_PARTITION_TABLE_OFFSET,
                                                         ESP_PARTITION_TABLE_MAX_LEN);
    if (table == NULL) {
        uart_puts("ERR: could not memory-map the ESP-IDF partition table.\r\n");
        return false;
    }
    esp_err_t err = esp_partition_table_verify(table, false, count);
    if (err != ESP_OK) {
        bootloader_munmap(table);
        uart_puts("ERR: ESP-IDF partition table invalid or MD5 check failed.\r\n");
        return false;
    }
    *out = table;
    return true;
}

static void partition_label(const vcs_partition_info_t *p, char out[17])
{
    memcpy(out, p->label, 16);
    out[16] = '\0';
}

static void idf_partition_label(const esp_partition_info_t *p, char out[17])
{
    memcpy(out, p->label, 16);
    out[16] = '\0';
}


static bool parse_vcs_number(const char *text, size_t len, uint32_t *out)
{
    char tmp[20];
    if (text == NULL || out == NULL || len == 0U || len >= sizeof(tmp)) return false;
    memcpy(tmp, text, len);
    tmp[len] = '\0';
    return parse_u32(tmp, out);
}

static bool vcs_next_field(const char **cursor, const char *end, const char **field, size_t *field_len)
{
    if (cursor == NULL || *cursor == NULL || end == NULL || field == NULL || field_len == NULL || *cursor > end) return false;
    const char *start = *cursor;
    const char *comma = start;
    while (comma < end && *comma != ',') ++comma;
    *field = start;
    *field_len = (size_t)(comma - start);
    *cursor = (comma < end) ? comma + 1 : end;
    return comma < end;
}

static bool vcs_field_equals(const char *field, size_t len, const char *value)
{
    return strlen(value) == len && memcmp(field, value, len) == 0;
}

static bool parse_vcs_row(const char *line, size_t len, vcs_partition_info_t *out)
{
    const char *cursor = line;
    const char *end = line + len;
    const char *field[5];
    size_t field_len[5];
    uint32_t offset = 0U, size = 0U;
    if (line == NULL || out == NULL || len == 0U) return false;
    for (unsigned i = 0; i < 4U; ++i) {
        if (!vcs_next_field(&cursor, end, &field[i], &field_len[i])) return false;
    }
    field[4] = cursor;
    field_len[4] = (size_t)(end - cursor);
    if (field_len[0] == 0U || field_len[0] > 16U ||
        !parse_vcs_number(field[1], field_len[1], &offset) ||
        !parse_vcs_number(field[2], field_len[2], &size) || size == 0U) return false;
    memset(out, 0, sizeof(*out));
    memcpy(out->label, field[0], field_len[0]);
    out->pos.offset = offset;
    out->pos.size = size;

    if (vcs_field_equals(field[3], field_len[3], "ro")) {
        out->flags = BLDR_VCS_FLAG_READ_ONLY;
    } else if (vcs_field_equals(field[3], field_len[3], "rw")) {
        out->flags = 0U;
    } else if (vcs_field_equals(field[3], field_len[3], "xip-rw")) {
        out->flags = BLDR_VCS_FLAG_XIP;
    } else if (vcs_field_equals(field[3], field_len[3], "xip-ro")) {
        out->flags = BLDR_VCS_FLAG_XIP | BLDR_VCS_FLAG_READ_ONLY;
    } else if (vcs_field_equals(field[3], field_len[3], "enc-rw")) {
        out->flags = BLDR_VCS_FLAG_ENCRYPTED;
    } else {
        return false;
    }

    if (vcs_field_equals(field[4], field_len[4], "esp-image")) out->kind = BLDR_VCS_KIND_ESP_IMAGE;
    else if (vcs_field_equals(field[4], field_len[4], "raw")) out->kind = BLDR_VCS_KIND_RAW_FS;
    else if (vcs_field_equals(field[4], field_len[4], "blob")) out->kind = BLDR_VCS_KIND_BLOB;
    else if (vcs_field_equals(field[4], field_len[4], "data")) out->kind = BLDR_VCS_KIND_DATA;
    else return false;
    return true;
}

static bool ranges_overlap(uint32_t a_off, uint32_t a_size, uint32_t b_off, uint32_t b_size)
{
    uint64_t a_end = (uint64_t)a_off + a_size;
    uint64_t b_end = (uint64_t)b_off + b_size;
    return ((uint64_t)a_off < b_end) && ((uint64_t)b_off < a_end);
}

static bool find_partition_in_table(const vcs_partition_info_t *table, int count,
                                    const char *label, vcs_partition_info_t *out)
{
    if (table == NULL || label == NULL) return false;
    for (int i = 0; i < count; ++i) {
        char name[17];
        partition_label(&table[i], name);
        if (strcmp(name, label) == 0) {
            if (out != NULL) *out = table[i];
            return true;
        }
    }
    return false;
}

static bool validate_vcs_entries(const esp_partition_info_t *idf_table, int idf_count,
                                 const esp_partition_info_t *anchor)
{
    const uint64_t flash_size = g_rom_flashchip.chip_size;
    const uint64_t protected_end = (uint64_t)CONFIG_PARTITION_TABLE_OFFSET + BLDR_SECTOR_SIZE;
    if (g_vcs_partition_count < 5 || !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "kernel", NULL) ||
        !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "rootfs", NULL) ||
        !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "ramdisk", NULL) ||
        !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "rootfs_data", NULL) ||
        !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "romfile", NULL)) return false;

    for (int i = 0; i < g_vcs_partition_count; ++i) {
        const vcs_partition_info_t *p = &g_vcs_partitions[i];
        char name[17];
        partition_label(p, name);
        uint64_t end = (uint64_t)p->pos.offset + p->pos.size;
        if (name[0] == '\0' || p->pos.size == 0U ||
            (p->pos.offset & (BLDR_SECTOR_SIZE - 1U)) != 0U ||
            (p->pos.size & (BLDR_SECTOR_SIZE - 1U)) != 0U ||
            p->pos.offset < protected_end || end > flash_size ||
            ranges_overlap(p->pos.offset, p->pos.size, anchor->pos.offset, anchor->pos.size)) return false;
        for (int j = 0; j < i; ++j) {
            char other[17];
            partition_label(&g_vcs_partitions[j], other);
            if (strcmp(name, other) == 0 ||
                ranges_overlap(p->pos.offset, p->pos.size,
                               g_vcs_partitions[j].pos.offset, g_vcs_partitions[j].pos.size)) return false;
        }
        for (int j = 0; j < idf_count; ++j) {
            char idf_name[17];
            idf_partition_label(&idf_table[j], idf_name);
            if (strcmp(idf_name, BLDR_VCS_ANCHOR_LABEL) != 0 &&
                ranges_overlap(p->pos.offset, p->pos.size,
                               idf_table[j].pos.offset, idf_table[j].pos.size)) return false;
        }
    }

    vcs_partition_info_t kernel, rootfs, ramdisk, rootfs_data, romfile;
    if (!find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "kernel", &kernel) ||
        !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "rootfs", &rootfs) ||
        !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "ramdisk", &ramdisk) ||
        !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "rootfs_data", &rootfs_data) ||
        !find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "romfile", &romfile)) return false;
    if (kernel.kind != BLDR_VCS_KIND_ESP_IMAGE || (kernel.flags & BLDR_VCS_FLAG_XIP) == 0U ||
        (kernel.pos.offset & 0xFFFFU) != 0U || rootfs.kind != BLDR_VCS_KIND_RAW_FS ||
        ramdisk.kind != BLDR_VCS_KIND_BLOB || rootfs_data.kind != BLDR_VCS_KIND_DATA ||
        romfile.kind != BLDR_VCS_KIND_BLOB || (romfile.flags & BLDR_VCS_FLAG_READ_ONLY) == 0U) return false;
    return true;
}

static bool load_partition_table(const vcs_partition_info_t **out, int *count)
{
    const esp_partition_info_t *idf_table = NULL;
    int idf_count = 0;
    esp_partition_info_t anchor;
    if (out == NULL || count == NULL || !load_idf_partition_table(&idf_table, &idf_count)) return false;
    bool found_anchor = false;
    for (int i = 0; i < idf_count; ++i) {
        char name[17];
        idf_partition_label(&idf_table[i], name);
        if (strcmp(name, BLDR_VCS_ANCHOR_LABEL) == 0 && idf_table[i].type == PART_TYPE_DATA) {
            anchor = idf_table[i];
            found_anchor = true;
            break;
        }
    }
    if (!found_anchor || anchor.pos.size < BLDR_SECTOR_SIZE ||
        (uint64_t)anchor.pos.offset + anchor.pos.size > g_rom_flashchip.chip_size) {
        bootloader_munmap(idf_table);
        uart_puts("ERR: ESP-IDF table lacks a valid 'vcs_table' anchor partition.\r\n");
        return false;
    }

    const uint8_t *mapped = bootloader_mmap(anchor.pos.offset, anchor.pos.size);
    if (mapped == NULL) {
        bootloader_munmap(idf_table);
        uart_puts("ERR: cannot map partition.vcs from the vcs_table partition.\r\n");
        return false;
    }
    bool valid = false;
    g_vcs_partition_count = 0;
    size_t line_len = 0U;
    while (line_len < anchor.pos.size && mapped[line_len] != '\n') ++line_len;
    if (line_len == 0U || line_len >= BLDR_VCS_HEADER_MAX || line_len >= anchor.pos.size ||
        memcmp(mapped, BLDR_VCS_MAGIC, 4U) != 0) {
        uart_puts("ERR: partition.vcs header is missing or malformed.\r\n");
        goto done;
    }

    uint32_t version = 0U, entries_count = 0U, total_size = 0U, expected_crc = 0U;
    const char *header_fields[5];
    size_t header_lens[5];
    const char *cur = (const char *)mapped;
    const char *hend = cur + line_len;
    for (unsigned i = 0; i < 4U; ++i) {
        if (!vcs_next_field(&cur, hend, &header_fields[i], &header_lens[i])) {
            uart_puts("ERR: partition.vcs header fields are invalid.\r\n");
            goto done;
        }
    }
    header_fields[4] = cur;
    header_lens[4] = (size_t)(hend - cur);
    if (!vcs_field_equals(header_fields[0], header_lens[0], BLDR_VCS_MAGIC) ||
        !parse_vcs_number(header_fields[1], header_lens[1], &version) ||
        !parse_vcs_number(header_fields[2], header_lens[2], &entries_count) ||
        !parse_vcs_number(header_fields[3], header_lens[3], &total_size) ||
        !parse_vcs_number(header_fields[4], header_lens[4], &expected_crc) ||
        version != BLDR_VCS_VERSION || entries_count < 5U || entries_count > BLDR_VCS_MAX_ENTRIES ||
        total_size > anchor.pos.size || total_size <= line_len + 1U) {
        uart_puts("ERR: partition.vcs version, count or length is invalid.\r\n");
        goto done;
    }

    {
        const char *rows = (const char *)mapped + line_len + 1U;
        const char *pos = rows;
        const char *limit = (const char *)mapped + total_size;
        for (uint32_t i = 0; i < entries_count; ++i) {
            const char *nl = pos;
            while (nl < limit && *nl != '\n') ++nl;
            if (nl == limit || nl == pos ||
                !parse_vcs_row(pos, (size_t)(nl - pos), &g_vcs_partitions[i])) {
                uart_puts("ERR: partition.vcs contains an invalid partition row.\r\n");
                goto done;
            }
            pos = nl + 1;
        }
        if (pos != limit || (crc32_ieee_update(0xFFFFFFFFU, (const uint8_t *)rows,
                                               (size_t)(limit - rows)) ^ 0xFFFFFFFFU) != expected_crc) {
            uart_puts("ERR: partition.vcs size or CRC32 does not match.\r\n");
            goto done;
        }
        g_vcs_partition_count = (int)entries_count;
    }
    valid = validate_vcs_entries(idf_table, idf_count, &anchor);
    if (!valid) uart_puts("ERR: partition.vcs layout is invalid, overlaps a protected/main region, or lacks required OS partitions.\r\n");

done:
    bootloader_munmap(mapped);
    bootloader_munmap(idf_table);
    if (!valid) {
        g_vcs_partition_count = 0;
        return false;
    }
    *out = g_vcs_partitions;
    *count = g_vcs_partition_count;
    return true;
}

static bool partition_is_mutable(const vcs_partition_info_t *p)
{
    if (p == NULL || (p->flags & BLDR_VCS_FLAG_READ_ONLY) != 0U) return false;
    uint64_t end = (uint64_t)p->pos.offset + p->pos.size;
    if (p->pos.size == 0U || end > g_rom_flashchip.chip_size) return false;
    return true;
}

static bool find_partition_by_label(const char *label, vcs_partition_info_t *out)
{
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    if (!load_partition_table(&table, &count)) return false;
    return find_partition_in_table(table, count, label, out);
}

static bool protected_flash_range(uint32_t addr, uint32_t len)
{
    uint64_t end = (uint64_t)addr + len;
    uint64_t protected_start = CONFIG_BOOTLOADER_OFFSET_IN_FLASH;
    uint64_t protected_end = (uint64_t)CONFIG_PARTITION_TABLE_OFFSET + BLDR_SECTOR_SIZE;
    return ((uint64_t)addr < protected_end && end > protected_start);
}

static bool find_partition_for_range(uint32_t addr, uint32_t len, vcs_partition_info_t *out)
{
    uint64_t end = (uint64_t)addr + len;
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    if (len == 0U || end > g_rom_flashchip.chip_size || protected_flash_range(addr, len)) return false;
    if (!load_partition_table(&table, &count)) return false;
    for (int i = 0; i < count; ++i) {
        uint64_t pstart = table[i].pos.offset;
        uint64_t pend = pstart + table[i].pos.size;
        if ((uint64_t)addr >= pstart && end <= pend) {
            if (partition_is_mutable(&table[i])) {
                if (out != NULL) *out = table[i];
                return true;
            }
            return false;
        }
    }
    return false;
}

static bool consume_unlock_for_range(uint32_t addr, uint32_t len, vcs_partition_info_t *p)
{
    vcs_partition_info_t found;
    char name[17];
    if (!find_partition_for_range(addr, len, &found)) {
        uart_puts("ERR: range is not entirely inside a writable partition.vcs region.\r\n");
        return false;
    }
    partition_label(&found, name);
    if (g_unlock_armed && g_monitor_elapsed_ms >= g_unlock_deadline_ms) {
        g_unlock_armed = false;
        g_unlock_label[0] = '\0';
        uart_puts("ERR: unlock token expired; run unlock again.\r\n");
        return false;
    }
    if (!g_unlock_armed || strcmp(g_unlock_label, name) != 0) {
        ets_printf("ERR: run 'unlock %s' before this write/erase operation.\r\n", name);
        return false;
    }
    g_unlock_armed = false;
    g_unlock_label[0] = '\0';
    if (p != NULL) *p = found;
    return true;
}

static bool partition_writes_encrypted(const vcs_partition_info_t *p)
{
    return p != NULL && esp_flash_encryption_enabled() &&
           ((p->flags & BLDR_VCS_FLAG_ENCRYPTED) != 0U);
}

static const char *vcs_kind_name(uint32_t kind)
{
    switch (kind) {
    case BLDR_VCS_KIND_ESP_IMAGE: return "esp-image";
    case BLDR_VCS_KIND_RAW_FS: return "raw";
    case BLDR_VCS_KIND_BLOB: return "blob";
    case BLDR_VCS_KIND_DATA: return "data";
    default: return "unknown";
    }
}

static void print_partition_table(void)
{
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    if (!load_partition_table(&table, &count)) return;
    uart_puts("ESP-OS partition.vcs (offset/size are bytes in internal flash)\r\n");
    uart_puts("Label           Kind       Offset     Size       Flags\r\n");
    for (int i = 0; i < count; ++i) {
        char name[17];
        partition_label(&table[i], name);
        ets_printf("%-15s %-10s 0x%08x 0x%08x %s%s%s\r\n",
                   name, vcs_kind_name(table[i].kind),
                   (unsigned)table[i].pos.offset, (unsigned)table[i].pos.size,
                   (table[i].flags & BLDR_VCS_FLAG_READ_ONLY) ? "ro" : "rw",
                   (table[i].flags & BLDR_VCS_FLAG_XIP) ? ",xip" : "",
                   (table[i].flags & BLDR_VCS_FLAG_ENCRYPTED) ? ",enc" : "");
    }
}

static uint16_t crc16_xmodem_update(uint16_t crc, const uint8_t *data, size_t len)
{
    for (size_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)data[i] << 8;
        for (unsigned b = 0; b < 8; ++b) {
            crc = (crc & 0x8000U) ? (uint16_t)((crc << 1) ^ 0x1021U) : (uint16_t)(crc << 1);
        }
    }
    return crc;
}

typedef struct {
    uint32_t h[5];
    uint64_t total_bytes;
    uint8_t block[64];
    size_t used;
} sha1_ctx_t;

static uint32_t rol32(uint32_t x, unsigned n) { return (x << n) | (x >> (32U - n)); }

static void sha1_transform(sha1_ctx_t *ctx, const uint8_t block[64])
{
    uint32_t w[80];
    for (unsigned i = 0; i < 16; ++i) {
        w[i] = ((uint32_t)block[i * 4] << 24) | ((uint32_t)block[i * 4 + 1] << 16) |
               ((uint32_t)block[i * 4 + 2] << 8) | (uint32_t)block[i * 4 + 3];
    }
    for (unsigned i = 16; i < 80; ++i) w[i] = rol32(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);
    uint32_t a = ctx->h[0], b = ctx->h[1], c = ctx->h[2], d = ctx->h[3], e = ctx->h[4];
    for (unsigned i = 0; i < 80; ++i) {
        uint32_t f, k;
        if (i < 20) { f = (b & c) | ((~b) & d); k = 0x5A827999U; }
        else if (i < 40) { f = b ^ c ^ d; k = 0x6ED9EBA1U; }
        else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8F1BBCDCU; }
        else { f = b ^ c ^ d; k = 0xCA62C1D6U; }
        uint32_t t = rol32(a, 5) + f + e + k + w[i];
        e = d; d = c; c = rol32(b, 30); b = a; a = t;
    }
    ctx->h[0] += a; ctx->h[1] += b; ctx->h[2] += c; ctx->h[3] += d; ctx->h[4] += e;
}

static void sha1_init(sha1_ctx_t *ctx)
{
    memset(ctx, 0, sizeof(*ctx));
    ctx->h[0] = 0x67452301U; ctx->h[1] = 0xEFCDAB89U; ctx->h[2] = 0x98BADCFEU;
    ctx->h[3] = 0x10325476U; ctx->h[4] = 0xC3D2E1F0U;
}

static void sha1_update(sha1_ctx_t *ctx, const uint8_t *data, size_t len)
{
    ctx->total_bytes += len;
    while (len > 0) {
        size_t take = sizeof(ctx->block) - ctx->used;
        if (take > len) take = len;
        memcpy(ctx->block + ctx->used, data, take);
        ctx->used += take; data += take; len -= take;
        if (ctx->used == sizeof(ctx->block)) {
            sha1_transform(ctx, ctx->block);
            ctx->used = 0;
        }
    }
}

static void sha1_final(sha1_ctx_t *ctx, uint8_t digest[20])
{
    uint64_t bits = ctx->total_bytes * 8U;
    ctx->block[ctx->used++] = 0x80;
    if (ctx->used > 56) {
        memset(ctx->block + ctx->used, 0, 64 - ctx->used);
        sha1_transform(ctx, ctx->block);
        ctx->used = 0;
    }
    memset(ctx->block + ctx->used, 0, 56 - ctx->used);
    for (unsigned i = 0; i < 8; ++i) ctx->block[63 - i] = (uint8_t)(bits >> (i * 8));
    sha1_transform(ctx, ctx->block);
    for (unsigned i = 0; i < 5; ++i) {
        digest[i * 4] = (uint8_t)(ctx->h[i] >> 24);
        digest[i * 4 + 1] = (uint8_t)(ctx->h[i] >> 16);
        digest[i * 4 + 2] = (uint8_t)(ctx->h[i] >> 8);
        digest[i * 4 + 3] = (uint8_t)ctx->h[i];
    }
}

static bool sha1_flash_range(uint32_t addr, uint32_t len, uint8_t digest[20])
{
    sha1_ctx_t ctx;
    if (len == 0 || (addr & 3U) != 0U || (len & 3U) != 0U ||
        (uint64_t)addr + len > g_rom_flashchip.chip_size) return false;
    sha1_init(&ctx);
    uint32_t done = 0;
    while (done < len) {
        uint32_t n = len - done;
        if (n > BLDR_FLASH_IO_CHUNK) n = BLDR_FLASH_IO_CHUNK;
        if (bootloader_flash_read(addr + done, g_io_buffer, n, true) != ESP_OK) return false;
        sha1_update(&ctx, g_io_buffer, n);
        done += n;
        feed_watchdog();
    }
    sha1_final(&ctx, digest);
    return true;
}

static void print_sha1(const uint8_t digest[20])
{
    for (unsigned i = 0; i < 20; ++i) ets_printf("%02x", digest[i]);
    uart_puts("\r\n");
}

#define BLDR_OS_BLOB_HEADER_SIZE 16U
#define BLDR_OS_BLOB_VERSION 1U

static uint32_t crc32_ieee_update(uint32_t crc, const uint8_t *data, size_t len)
{
    for (size_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8U; ++bit) {
            crc = (crc & 1U) ? ((crc >> 1) ^ 0xEDB88320U) : (crc >> 1);
        }
    }
    return crc;
}

static bool crc32_flash_range(uint32_t addr, uint32_t len, uint32_t *out_crc)
{
    uint32_t done = 0U;
    uint32_t crc = 0xFFFFFFFFU;
    if (out_crc == NULL || len == 0U || (uint64_t)addr + len > g_rom_flashchip.chip_size) return false;
    while (done < len) {
        uint32_t n = len - done;
        if (n > BLDR_FLASH_IO_CHUNK) n = BLDR_FLASH_IO_CHUNK;
        if (bootloader_flash_read(addr + done, g_io_buffer, n, true) != ESP_OK) return false;
        crc = crc32_ieee_update(crc, g_io_buffer, n);
        done += n;
        feed_watchdog();
    }
    *out_crc = crc ^ 0xFFFFFFFFU;
    return true;
}

/* ROMF/RAMD/ROOT use a 16-byte data header: magic[4], version, payload size, CRC32.
 * Kernel is a native ESP-IDF segmented image (0xE9 at partition offset), with its
 * segment checksum/SHA-256 validated by esp_image_verify so XIP MMU setup can work. */
static bool verify_os_payload_partition(const vcs_partition_info_t *p, const char magic[4],
                                        uint32_t *computed_crc, uint32_t *expected_crc,
                                        uint32_t *payload_size)
{
    uint32_t size = 0U, expected = 0U, version = BLDR_OS_BLOB_VERSION;
    if (p == NULL || p->pos.size <= BLDR_OS_BLOB_HEADER_SIZE ||
        p->kind != BLDR_VCS_KIND_BLOB ||
        (uint64_t)p->pos.offset + p->pos.size > g_rom_flashchip.chip_size ||
        bootloader_flash_read(p->pos.offset, g_io_buffer, BLDR_OS_BLOB_HEADER_SIZE, true) != ESP_OK) return false;
    if (memcmp(g_io_buffer, magic, 4U) != 0) return false;
    memcpy(&version, g_io_buffer + 4U, sizeof(version));
    memcpy(&size, g_io_buffer + 8U, sizeof(size));
    memcpy(&expected, g_io_buffer + 12U, sizeof(expected));
    if (version != BLDR_OS_BLOB_VERSION || size == 0U || size > p->pos.size - BLDR_OS_BLOB_HEADER_SIZE) return false;
    uint32_t computed = 0U;
    if (!crc32_flash_range(p->pos.offset + BLDR_OS_BLOB_HEADER_SIZE, size, &computed)) return false;
    if (computed_crc != NULL) *computed_crc = computed;
    if (expected_crc != NULL) *expected_crc = expected;
    if (payload_size != NULL) *payload_size = size;
    return computed == expected;
}

static bool verify_native_kernel_image(const vcs_partition_info_t *p, esp_image_metadata_t *metadata)
{
    if (p == NULL || p->kind != BLDR_VCS_KIND_ESP_IMAGE ||
        (p->flags & BLDR_VCS_FLAG_XIP) == 0U || (p->pos.offset & 0xFFFFU) != 0U ||
        p->pos.size == 0U || (uint64_t)p->pos.offset + p->pos.size > g_rom_flashchip.chip_size) return false;
    esp_image_metadata_t local_metadata;
    if (metadata == NULL) metadata = &local_metadata;
    esp_err_t err = esp_image_verify(ESP_IMAGE_VERIFY, &p->pos, metadata);
    return err == ESP_OK && metadata->image_len > 0U && metadata->image_len <= p->pos.size;
}

static bool post_ram_buffer_test(void)
{
    volatile uint32_t *words = (volatile uint32_t *)g_ram_buffer;
    const uint32_t count = (uint32_t)(sizeof(g_ram_buffer) / sizeof(uint32_t));
    for (uint32_t i = 0; i < count; ++i) words[i] = 0xA55A3CC3U ^ i;
    __asm__ __volatile__("memw" ::: "memory");
    for (uint32_t i = 0; i < count; ++i) if (words[i] != (0xA55A3CC3U ^ i)) return false;
    for (uint32_t i = 0; i < count; ++i) words[i] = 0x5AA5C33CU ^ i;
    __asm__ __volatile__("memw" ::: "memory");
    for (uint32_t i = 0; i < count; ++i) if (words[i] != (0x5AA5C33CU ^ i)) return false;
    for (uint32_t i = 0; i < count; ++i) words[i] = 0U;
    __asm__ __volatile__("memw" ::: "memory");
    return true;
}

static void post_print_status(const char *name, bool pass)
{
    ets_printf("[POST] %s: %s\r\n", name, pass ? "PASS" : "FAIL");
}

static bool post_self_test(void)
{
    bool ok = true;
    bool ram_ok, flash_ok;
    const vcs_partition_info_t *table = NULL;
    vcs_partition_info_t kernel, romfile, ramdisk, rootfs, rootfs_data;
    int count = 0;

    uart_puts("\r\n[POST] Starting Power-On Self-Test...\r\n");
    ram_ok = post_ram_buffer_test();
    post_print_status("Internal SRAM safe-buffer test", ram_ok);
    ok = ok && ram_ok;

    bool psram_ok = bldr_psram_ready();
    post_print_status("PSRAM init and mapped range", psram_ok);
    ok = ok && psram_ok;

    flash_ok = (g_rom_flashchip.chip_size != 0U) &&
               (bootloader_flash_read(0U, g_io_buffer, 16U, true) == ESP_OK);
    post_print_status("Internal flash read test", flash_ok);
    ok = ok && flash_ok;

    {
        const esp_partition_info_t *idf_table = NULL;
        int idf_count = 0;
        bool idf_ok = load_idf_partition_table(&idf_table, &idf_count);
        if (idf_ok) bootloader_munmap(idf_table);
        post_print_status("ESP-IDF main partition table", idf_ok);
        ok = ok && idf_ok;
    }

    if (!load_partition_table(&table, &count)) {
        post_print_status("partition.vcs table/CRC32/layout", false);
        uart_puts("[POST] Result: FAIL\r\n");
        return false;
    }
    post_print_status("partition.vcs table/CRC32/layout", true);

    bool has_kernel = find_partition_in_table(table, count, "kernel", &kernel);
    bool has_romfile = find_partition_in_table(table, count, "romfile", &romfile);
    bool has_ramdisk = find_partition_in_table(table, count, "ramdisk", &ramdisk);
    bool has_rootfs = find_partition_in_table(table, count, "rootfs", &rootfs);
    bool has_rootfs_data = find_partition_in_table(table, count, "rootfs_data", &rootfs_data);

    esp_image_metadata_t kernel_metadata;
    bool kernel_ok = has_kernel && verify_native_kernel_image(&kernel, &kernel_metadata);
    bool romfile_ok = has_romfile && verify_os_payload_partition(&romfile, "ROMF", NULL, NULL, NULL);
    bool ramdisk_ok = has_ramdisk && verify_os_payload_partition(&ramdisk, "RAMD", NULL, NULL, NULL);
    bool rootfs_data_ok = has_rootfs_data;
    bool rootfs_ok = false;

    if (has_rootfs) {
        uint8_t probe[4];
        rootfs_ok = bootloader_flash_read(rootfs.pos.offset, probe, sizeof(probe), true) == ESP_OK;
        post_print_status("RootFS flash read", rootfs_ok);
        if (rootfs_ok) uart_puts("[POST] RootFS CRC32: N/A (raw filesystem; use a filesystem-specific verifier).\r\n");
    } else {
        post_print_status("RootFS presence", false);
    }
    if (kernel_ok) {
        ets_printf("[POST] Kernel ESP image: len=0x%x entry=0x%08x segments=%u (XIP-capable image)\r\n",
                   (unsigned)kernel_metadata.image_len, (unsigned)kernel_metadata.image.entry_addr,
                   (unsigned)kernel_metadata.image.segment_count);
    }
    post_print_status("Kernel ESP image/checksum", kernel_ok);
    post_print_status("ROMFILE header/payload CRC32", romfile_ok);
    post_print_status("Ramdisk header/payload CRC32 (not loaded here)", ramdisk_ok);
    post_print_status("rootfs_data presence", rootfs_data_ok);
    ok = ok && kernel_ok && romfile_ok && ramdisk_ok && rootfs_ok && rootfs_data_ok;
    uart_puts(ok ? "[POST] Result: PASS\r\n" : "[POST] Result: FAIL\r\n");
    return ok;
}

/* This uses ESP-IDF's own image-loader handoff, but points it at the kernel
 * partition selected by partition.vcs rather than the standard factory app.
 * The ESP image loader copies only IRAM/DRAM segments and maps IROM/DROM via MMU;
 * ramdisk is intentionally NOT loaded by the bootloader. */
static bool boot_esp_os_kernel(void)
{
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    vcs_partition_info_t kernel;
    esp_image_metadata_t metadata;
    if (!load_partition_table(&table, &count) ||
        !find_partition_in_table(table, count, "kernel", &kernel) ||
        !verify_native_kernel_image(&kernel, &metadata)) {
        uart_puts("[BOOT] Kernel image or partition.vcs invalid; not transferring control.\r\n");
        return false;
    }
    bootloader_state_t os_state = {0};
    os_state.factory = kernel.pos;
    os_state.app_count = 1U;
    ets_printf("[BOOT] Loading ESP-OS kernel from 0x%08x, image=0x%x, entry=0x%08x.\r\n",
               (unsigned)kernel.pos.offset, (unsigned)metadata.image_len,
               (unsigned)metadata.image.entry_addr);
    uart_puts("[BOOT] ESP-IDF image loader will map XIP segments; ramdisk remains on flash.\r\n");
    bootloader_utility_load_boot_image(&os_state, FACTORY_INDEX);
    return false; /* The ESP-IDF bootloader API is noreturn. */
}

static bool check_flash_encryption_alignment(const vcs_partition_info_t *p, uint32_t addr, uint32_t len)
{
    if (partition_writes_encrypted(p) && (((addr | len) & 15U) != 0U)) {
        uart_puts("ERR: encrypted writes require flash address and length aligned to 16 bytes on ESP-IDF v4.4.7.\r\n");
        return false;
    }
    return true;
}

static bool flash_write_from_ram(uint32_t flash_addr, uint32_t ram_addr, uint32_t len)
{
    vcs_partition_info_t p;
    if (len == 0 || (flash_addr & 3U) != 0U || (ram_addr & 3U) != 0U || (len & 3U) != 0U) {
        uart_puts("ERR: flash address, PSRAM address and length must be 4-byte aligned; len must be nonzero.\r\n");
        return false;
    }
    if (!bldr_psram_range_valid(ram_addr, len)) {
        uart_puts("ERR: source must be a validated PSRAM range; internal SRAM/IRAM addresses are forbidden.\r\n");
        return false;
    }
    if (!find_partition_for_range(flash_addr, len, &p)) {
        uart_puts("ERR: destination must lie entirely in a writable partition, outside the bootloader/table.\r\n");
        return false;
    }
    if (!check_flash_encryption_alignment(&p, flash_addr, len)) return false;
    if (!consume_unlock_for_range(flash_addr, len, &p)) return false;

    bool encrypt = partition_writes_encrypted(&p);
    uint32_t done = 0;
    while (done < len) {
        uint32_t n = len - done;
        if (n > BLDR_FLASH_IO_CHUNK) n = BLDR_FLASH_IO_CHUNK;
        if (encrypt) n &= ~15U;
        if (n == 0) return false;
        /* Copy from validated PSRAM into aligned private scratch. Encrypted
         * ROM writes may transform this scratch buffer in place. */
        if (!bldr_psram_read(ram_addr + done, g_io_buffer, n)) {
            uart_puts("ERR: PSRAM read failed while staging the flash write.\r\n");
            return false;
        }
        esp_err_t err = bootloader_flash_write(flash_addr + done, g_io_buffer, n, encrypt);
        if (err != ESP_OK) {
            ets_printf("ERR: flash write failed at 0x%08x (0x%x); target may be partially written.\r\n",
                       (unsigned)(flash_addr + done), (unsigned)err);
            return false;
        }
        done += n;
        feed_watchdog();
    }
    ets_printf("OK: wrote %u bytes to flash 0x%08x. Run verify if this is an app image.\r\n",
               (unsigned)len, (unsigned)flash_addr);
    return true;
}

static bool flash_erase_blocks(uint32_t addr, uint32_t blocks)
{
    uint64_t len64 = (uint64_t)blocks * BLDR_SECTOR_SIZE;
    if (blocks == 0 || len64 > UINT32_MAX || (addr & (BLDR_SECTOR_SIZE - 1U)) != 0U) {
        uart_puts("ERR: erase expects a sector-aligned address and a positive sector count.\r\n");
        return false;
    }
    uint32_t len = (uint32_t)len64;
    if (!consume_unlock_for_range(addr, len, NULL)) return false;
    uint32_t n = 0;
    while (n < blocks) {
        esp_err_t err = bootloader_flash_erase_sector((addr / BLDR_SECTOR_SIZE) + n);
        if (err != ESP_OK) {
            ets_printf("ERR: erase failed at 0x%08x (0x%x); range may be partially erased.\r\n",
                       (unsigned)(addr + n * BLDR_SECTOR_SIZE), (unsigned)err);
            return false;
        }
        ++n;
        feed_watchdog();
    }
    ets_printf("OK: erased %u sector(s) at 0x%08x (%u bytes).\r\n",
               (unsigned)blocks, (unsigned)addr, (unsigned)len);
    return true;
}

static bool flash_write_packet(uint32_t addr, uint32_t packet_offset, uint32_t len,
                               const vcs_partition_info_t *partition, uint32_t *last_erased_sector)
{
    uint32_t done = 0;
    bool encrypt = partition_writes_encrypted(partition);
    if (((addr | len | packet_offset) & 3U) != 0U ||
        (uint64_t)packet_offset + len > BLDR_XMODEM_PACKET_MAX) return false;
    if (!check_flash_encryption_alignment(partition, addr, len)) return false;
    while (done < len) {
        uint32_t current = addr + done;
        uint32_t sector = current / BLDR_SECTOR_SIZE;
        uint32_t in_sector = current & (BLDR_SECTOR_SIZE - 1U);
        uint32_t n = len - done;
        if (n > BLDR_SECTOR_SIZE - in_sector) n = BLDR_SECTOR_SIZE - in_sector;
        if (sector != *last_erased_sector) {
            esp_err_t er = bootloader_flash_erase_sector(sector);
            if (er != ESP_OK) return false;
            *last_erased_sector = sector;
            feed_watchdog();
        }
        uint32_t pos = 0;
        while (pos < n) {
            uint32_t wn = n - pos;
            if (wn > BLDR_FLASH_IO_CHUNK) wn = BLDR_FLASH_IO_CHUNK;
            if (encrypt) wn &= ~15U;
            if (wn == 0U || !copy_xmodem_packet_to_io(packet_offset + done + pos, wn)) return false;
            esp_err_t wr = bootloader_flash_write(current + pos, g_io_buffer, wn, encrypt);
            if (wr != ESP_OK) {
                return false;
            }
            pos += wn;
            feed_watchdog();
        }
        done += n;
    }
    return true;
}

static uint32_t read_cpu_ccount(void)
{
    uint32_t value;
    __asm__ __volatile__("rsr.ccount %0" : "=a"(value));
    return value;
}

static uint32_t xmodem_elapsed_ms(uint32_t start_ccount, uint32_t cpu_mhz)
{
    uint32_t cycles_per_ms = (cpu_mhz == 0U ? 80U : cpu_mhz) * 1000U;
    return (uint32_t)(read_cpu_ccount() - start_ccount) / cycles_per_ms;
}

static bool xmodem_read_byte_until(uint8_t *out, uint32_t start_ccount, uint32_t cpu_mhz,
                                   uint32_t *last_feed_ms)
{
    while (xmodem_elapsed_ms(start_ccount, cpu_mhz) < BLDR_XMODEM_SESSION_TIMEOUT_MS) {
        if (uart_rx_one_char(out) == 0) return true;
        uint32_t elapsed = xmodem_elapsed_ms(start_ccount, cpu_mhz);
        if (last_feed_ms != NULL && elapsed - *last_feed_ms >= 1000U) {
            feed_watchdog();
            *last_feed_ms = elapsed;
        }
        /* Poll frequently so high-baud bursts are not throttled by 1 ms sleeps. */
        ets_delay_us(10U);
    }
    return false;
}

static uint32_t xmodem_padding_overlap(uint32_t packet_len, uint32_t payload_len,
                                       uint32_t trailing_pad)
{
    uint32_t outside = packet_len > payload_len ? packet_len - payload_len : 0U;
    if (trailing_pad <= outside) return 0U;
    uint32_t overlap = trailing_pad - outside;
    return overlap > payload_len ? payload_len : overlap;
}

static void xmodem_trim_final_padding(uint32_t *received, uint32_t packet_len,
                                     uint32_t payload_len, uint32_t trailing_pad)
{
    if (received == NULL || packet_len == 0U || payload_len == 0U) return;
    uint32_t trim = xmodem_padding_overlap(packet_len, payload_len, trailing_pad);
    if (trim > *received) trim = *received;
    *received -= trim;
}

static void xmodem_report_received(uint32_t received)
{
    ets_printf("Recieved len=%X\r\n", (unsigned)received);
}

static bool xmodem_receive(uint32_t ram_addr, uint32_t max_len,
                           bool to_flash, uint32_t flash_addr,
                           const vcs_partition_info_t *flash_partition,
                           uint32_t *out_bytes)
{
    uint32_t received = 0U;
    uint32_t last_packet_len = 0U;
    uint32_t last_packet_payload = 0U;
    uint32_t last_packet_trailing_pad = 0U;
    uint32_t start_ccount;
    uint32_t monitor_start_ms = g_monitor_elapsed_ms;
    uint32_t last_watchdog_feed_ms = 0U;
    uint32_t cpu_mhz;
    uint32_t next_c_ms = 0U;
    uint8_t expected_block = 1U;
    uint32_t last_erased_sector = UINT32_MAX;
    bool started = false;
    bool success = false;

    if (out_bytes != NULL) *out_bytes = 0U;
    if (!to_flash && (max_len == 0U || !bldr_psram_range_valid(ram_addr, max_len))) {
        uart_puts("ERR: XMODEM target must be entirely inside initialized, validated PSRAM.\r\n");
        return false;
    }
    if (to_flash && (max_len == 0U || (max_len & (BLDR_SECTOR_SIZE - 1U)) != 0U || flash_partition == NULL ||
                     !partition_is_mutable(flash_partition) ||
                     (uint64_t)flash_addr + max_len > (uint64_t)flash_partition->pos.offset + flash_partition->pos.size ||
                     (flash_addr & (BLDR_SECTOR_SIZE - 1U)) != 0U)) {
        uart_puts("ERR: XMODEM flash target must be sector-aligned and inside one writable partition.\r\n");
        return false;
    }
    rtc_cpu_freq_config_t clock_cfg;
    rtc_clk_cpu_freq_get_config(&clock_cfg);
    cpu_mhz = clock_cfg.freq_mhz;
    start_ccount = read_cpu_ccount();

    for (;;) {
        uint8_t c = 0U;
        if (xmodem_elapsed_ms(start_ccount, cpu_mhz) >= BLDR_XMODEM_SESSION_TIMEOUT_MS) break;
        if (uart_rx_one_char(&c) != 0) {
            uint32_t elapsed = xmodem_elapsed_ms(start_ccount, cpu_mhz);
            if (!started && elapsed >= next_c_ms) {
                uart_putc((char)XMODEM_CRC_REQ);
                next_c_ms += BLDR_XMODEM_C_INTERVAL_MS;
            }
            if (elapsed - last_watchdog_feed_ms >= 1000U) {
                feed_watchdog();
                last_watchdog_feed_ms = elapsed;
            }
            /* Keep polling tight so the first high-baud packet does not overflow UART FIFO. */
            ets_delay_us(10U);
            continue;
        }
        if (c == XMODEM_EOT) {
            uart_putc((char)XMODEM_ACK);
            started = true; /* This session has started; do not resume sending CRC requests. */
            /* XMODEM has no file-length field. Trim conventional 0x1A padding from the final block,
             * including padding that overlaps a too-large requested length. */
            xmodem_trim_final_padding(&received, last_packet_len, last_packet_payload, last_packet_trailing_pad);
            last_packet_len = 0U; /* An EOT retransmission must not trim the same packet twice. */
            last_packet_payload = 0U;
            last_packet_trailing_pad = 0U;
            if (received == max_len) {
                success = true;
                break;
            }
            /* The sender has ended, but the caller may have specified a length that's too large.
             * Keep waiting (without sending more 'C') until the one absolute 15-second deadline. */
            continue;
        }
        if (c == XMODEM_CAN) {
            (void)uart_rx_one_char(&c); /* Consume a paired CAN if it is already queued. */
            break;
        }
        uint32_t packet_len;
        if (c == XMODEM_SOH) packet_len = 128U;
        else if (c == XMODEM_STX) packet_len = 1024U;
        else {
            if (started) uart_putc((char)XMODEM_NAK);
            continue;
        }
        started = true; /* Stop emitting 'C' as soon as a sender starts a data packet. */

        uint8_t block = 0U, block_inv = 0U, crc_hi = 0U, crc_lo = 0U;
        bool got = xmodem_read_byte_until(&block, start_ccount, cpu_mhz, &last_watchdog_feed_ms) &&
                   xmodem_read_byte_until(&block_inv, start_ccount, cpu_mhz, &last_watchdog_feed_ms);
        uint32_t payload_len = received < max_len ? max_len - received : 0U;
        if (payload_len > packet_len) payload_len = packet_len;
        uint16_t packet_crc = 0U;
        uint32_t trailing_pad = 0U;
        for (uint32_t i = 0U; got && i < packet_len; i += 4U) {
            uint8_t quartet[4];
            for (uint32_t j = 0U; got && j < 4U; ++j)
                got = xmodem_read_byte_until(&quartet[j], start_ccount, cpu_mhz, &last_watchdog_feed_ms);
            if (got) {
                packet_crc = crc16_xmodem_update(packet_crc, quartet, sizeof(quartet));
                for (uint32_t j = 0U; j < 4U; ++j) {
                    if (quartet[j] == 0x1AU) ++trailing_pad;
                    else trailing_pad = 0U;
                    /* Stage every packet in private IRAM. Nothing is committed
                     * to PSRAM or flash until header/sequence/CRC are accepted. */
                    g_xmodem_packet[i + j] = quartet[j];
                }
            }
        }
        if (got) got = xmodem_read_byte_until(&crc_hi, start_ccount, cpu_mhz, &last_watchdog_feed_ms) &&
                       xmodem_read_byte_until(&crc_lo, start_ccount, cpu_mhz, &last_watchdog_feed_ms);
        if (!got) break;
        uint16_t want_crc = (uint16_t)(((uint16_t)crc_hi << 8) | crc_lo);
        if ((uint8_t)(block + block_inv) != 0xFFU || packet_crc != want_crc) {
            uart_putc((char)XMODEM_NAK);
            continue;
        }
        if (block == (uint8_t)(expected_block - 1U)) {
            uart_putc((char)XMODEM_ACK);
            continue;
        }
        if (block != expected_block) {
            uart_putc((char)XMODEM_NAK);
            continue;
        }
        if (received >= max_len) {
            uart_putc((char)XMODEM_CAN);
            uart_putc((char)XMODEM_CAN);
            break;
        }
        bool stored;
        if (to_flash) {
            /* Flash transfers stage a packet in private IRAM, then write only CRC-accepted bytes.
             * payload_len may be shorter than the received block at the configured range boundary. */
            stored = payload_len != 0U &&
                flash_write_packet(flash_addr + received, 0U, payload_len,
                                   flash_partition, &last_erased_sector);
        } else {
            /* Commit only CRC-validated bytes to the validated PSRAM range. */
            stored = payload_len != 0U &&
                bldr_psram_write(ram_addr + received, g_xmodem_packet, payload_len);
        }
        if (!stored) {
            uart_putc((char)XMODEM_CAN);
            uart_putc((char)XMODEM_CAN);
            break;
        }
        received += payload_len;
        last_packet_len = packet_len;
        last_packet_payload = payload_len;
        last_packet_trailing_pad = trailing_pad;
        ++expected_block;
        uart_putc((char)XMODEM_ACK);
        feed_watchdog();
        if (received == max_len) {
            /* Give the sender up to 250 ms to signal EOT so final-block 0x1A padding can be
             * removed when the requested length accidentally cuts into padding. */
            uint8_t ending = 0U;
            bool saw_eot = false;
            uint32_t complete_wait_start = xmodem_elapsed_ms(start_ccount, cpu_mhz);
            while (xmodem_elapsed_ms(start_ccount, cpu_mhz) < BLDR_XMODEM_SESSION_TIMEOUT_MS &&
                   xmodem_elapsed_ms(start_ccount, cpu_mhz) - complete_wait_start < 250U) {
                if (uart_rx_one_char(&ending) == 0) {
                    if (ending == XMODEM_EOT) {
                        saw_eot = true;
                        uart_putc((char)XMODEM_ACK);
                        xmodem_trim_final_padding(&received, last_packet_len, last_packet_payload, last_packet_trailing_pad);
                        last_packet_len = 0U;
                        last_packet_payload = 0U;
                        last_packet_trailing_pad = 0U;
                        success = (received == max_len);
                    }
                    break;
                }
                ets_delay_us(10U);
            }
            if (success) break;
            if (saw_eot) {
                /* EOT was valid but the accepted payload was shorter than expected after padding
                 * removal. Do not report success; continue waiting to the original 15s deadline. */
                continue;
            }
            /* No EOT arrived, but max_len accepted bytes were received. */
            success = true;
            break;
        }
    }

    if (!success && received == max_len && last_packet_len > last_packet_payload) {
        /* If the expected size cut through the last XMODEM block, account for visible 0x1A padding on timeout. */
        xmodem_trim_final_padding(&received, last_packet_len, last_packet_payload, last_packet_trailing_pad);
        success = (received == max_len);
    }
    g_monitor_elapsed_ms = monitor_start_ms + xmodem_elapsed_ms(start_ccount, cpu_mhz);
    if (out_bytes != NULL) *out_bytes = received;
    xmodem_report_received(received);
    return success;
}

static bool verify_image(uint32_t addr, uint32_t len)
{
    if (len == 0 || (addr & 0xFFFU) != 0U ||
        (uint64_t)addr + len > g_rom_flashchip.chip_size || protected_flash_range(addr, len)) {
        uart_puts("ERR: invalid image range; start address must be 4 KiB aligned and outside bootloader/partition table.\r\n");
        return false;
    }
    esp_partition_pos_t pos = { .offset = addr, .size = len };
    esp_image_metadata_t metadata;
    esp_err_t err = esp_image_verify(ESP_IMAGE_VERIFY, &pos, &metadata);
    if (err != ESP_OK) {
        ets_printf("VERIFY FAIL: ESP-IDF image validator returned 0x%x.\r\n", (unsigned)err);
        return false;
    }
    ets_printf("VERIFY OK: ESP image, %u bytes; segments=%u; entry=0x%08x.\r\n",
               (unsigned)metadata.image_len, (unsigned)metadata.image.segment_count,
               (unsigned)metadata.image.entry_addr);
    return true;
}

static void print_help(void)
{
    uart_puts("ESP-OS monitor 2.1.0: help [cmd], version, partitions/mtd, go, reboot\r\n");
    uart_puts("unlock <mtd>; erase <mtd|addr blocks>; flash <flash_addr psram_addr len>; dump <flash_addr len psram_addr>\r\n");
    uart_puts("xmdm <psram_addr_hex len_hex> | xmdm flash <mtd offset_hex max_hex>\r\n");
    uart_puts("crc32 <mtd>; sha1sum -a <addr len> | -p <mtd>; verify <mtd|addr len>; baud <rate>\r\n");
}

static void print_command_help(const char *cmd)
{
    if (strcmp(cmd, "help") == 0 || strcmp(cmd, "?") == 0) uart_puts("help [command]\r\n");
    else if (strcmp(cmd, "mtd") == 0 || strcmp(cmd, "partitions") == 0) uart_puts("mtd: list partition.vcs regions\r\n");
    else if (strcmp(cmd, "verify") == 0) uart_puts("verify <mtd> | verify <flash_addr> <len>\r\n");
    else if (strcmp(cmd, "sha1sum") == 0) uart_puts("sha1sum -a <addr> <len> | -p <mtd>\r\n");
    else if (strcmp(cmd, "crc32") == 0) uart_puts("crc32 <mtd>\r\n");
    else if (strcmp(cmd, "xmdm") == 0) uart_puts("xmdm <psram_addr_hex len_hex> | xmdm flash <mtd> <offset_hex> <max_hex>\r\n");
    else if (strcmp(cmd, "unlock") == 0) uart_puts("unlock <mtd>: one destructive operation, 30-second expiry\r\n");
    else if (strcmp(cmd, "erase") == 0) uart_puts("erase <mtd> | erase <flash_addr> <sector_count>\r\n");
    else if (strcmp(cmd, "flash") == 0) uart_puts("flash <flash_addr> <psram_addr> <len> (source must be PSRAM)\r\n");
    else if (strcmp(cmd, "dump") == 0) uart_puts("dump <flash_addr> <len> <psram_addr> (destination must be PSRAM)\r\n");
    else if (strcmp(cmd, "jump") == 0) uart_puts("jump is disabled; PSRAM execution and arbitrary SRAM entry points are not enabled\r\n");
    else if (strcmp(cmd, "baud") == 0) uart_puts("baud <9600|19200|38400|57600|115200|230400|460800|921600>\r\n");
    else if (strcmp(cmd, "go") == 0) uart_puts("go: POST, verify kernel, hand off to ESP-OS\r\n");
    else if (strcmp(cmd, "version") == 0) uart_puts("version: print monitor version\r\n");
    else if (strcmp(cmd, "reboot") == 0) uart_puts("reboot: reset device\r\n");
    else uart_puts("Unknown command. Use help.\r\n");
}

static bool read_line(char *line, size_t cap)
{
    size_t len = 0;
    while (g_monitor_elapsed_ms < BLDR_MONITOR_MAX_MS) {
        uint8_t c = 0;
        if (uart_rx_one_char(&c) == 0) {
            if (g_skip_lf) {
                g_skip_lf = false;
                if (c == '\n') continue;
            }
            if (c == '\r' || c == '\n') {
                if (c == '\r') g_skip_lf = true;
                uart_puts("\r\n");
                line[len] = '\0';
                return true;
            }
            if (c == 0x03U) {
                uart_puts("^C\r\nLeaving monitor.\r\n");
                return false;
            }
            if (c == 0x08U || c == 0x7FU) {
                if (len > 0) { --len; uart_puts("\b \b"); }
                continue;
            }
            if (c < 0x20U || c > 0x7EU) {
                uart_puts("\r\nERR: ASCII commands only; line discarded.\r\n");
                len = 0;
                prompt();
                continue;
            }
            if (len + 1U >= cap) {
                uart_puts("\r\nERR: line too long; line discarded.\r\n");
                len = 0;
                prompt();
                continue;
            }
            line[len++] = (char)c;
            uart_putc((char)c);
        }
        delay_1ms();
    }
    uart_puts("\r\nMonitor time limit reached; retrying ESP-OS boot checks.\r\n");
    return false;
}

static bool process_command(int argc, char **argv)
{
    uint32_t a = 0, b = 0, c = 0;
    if (argc == 0) return true;
    if (command_has_help(argc, argv)) { print_command_help(argv[0]); return true; }
    const char *cmd = argv[0];

    if (strcmp(cmd, "help") == 0 || strcmp(cmd, "?") == 0) {
        if (argc == 1) print_help();
        else if (argc == 2) print_command_help(argv[1]);
        else uart_puts("Usage: help [command] OR ? [command]\r\n");
    } else if (strcmp(cmd, "version") == 0) {
        ets_printf("ESP32-OS bootloader monitor %s\r\n", BLDR_VERSION);
    } else if (strcmp(cmd, "partitions") == 0 || strcmp(cmd, "mtd") == 0) {
        print_partition_table();
    } else if (strcmp(cmd, "go") == 0) {
        if (post_self_test()) {
            if (!boot_esp_os_kernel()) uart_puts("[BOOT] Kernel handoff failed; remaining in console.\r\n");
        } else {
            uart_puts("[BOOT] POST failed; remaining in console.\r\n");
        }
    } else if (strcmp(cmd, "reboot") == 0) {
        uart_puts("Rebooting...\r\n");
        ets_delay_us(20000);
        software_reset();
        for (;;) { }
    } else if (strcmp(cmd, "unlock") == 0) {
        /* A new unlock attempt always replaces/disarms any previous token. */
        g_unlock_armed = false;
        g_unlock_label[0] = '\0';
        if (argc != 2) { uart_puts("Usage: unlock <partition-label>\r\n"); return true; }
        vcs_partition_info_t p;
        if (!find_partition_by_label(argv[1], &p)) { uart_puts("ERR: partition not found or partition table invalid.\r\n"); return true; }
        if (!partition_is_mutable(&p)) { uart_puts("ERR: critical/read-only partition cannot be unlocked.\r\n"); return true; }
        if (strlen(argv[1]) > 16U) { uart_puts("ERR: label exceeds ESP-IDF's 16-character partition label limit.\r\n"); return true; }
        strncpy(g_unlock_label, argv[1], sizeof(g_unlock_label) - 1U);
        g_unlock_label[sizeof(g_unlock_label) - 1U] = '\0';
        g_unlock_deadline_ms = g_monitor_elapsed_ms + 30000U;
        g_unlock_armed = true;
        ets_printf("OK: '%s' armed for one flash/erase/XMODEM-to-flash operation (30 s timeout).\r\n", g_unlock_label);
    } else if (strcmp(cmd, "erase") == 0) {
        if (argc == 2) {
            vcs_partition_info_t p;
            if (!find_partition_by_label(argv[1], &p)) { uart_puts("ERR: partition not found or partition table invalid.\r\n"); return true; }
            if (!partition_is_mutable(&p)) { uart_puts("ERR: critical/read-only partition cannot be erased.\r\n"); return true; }
            if (p.pos.size == 0U || (p.pos.offset & (BLDR_SECTOR_SIZE - 1U)) != 0U ||
                (p.pos.size & (BLDR_SECTOR_SIZE - 1U)) != 0U) {
                uart_puts("ERR: partition offset/size is not erase-sector aligned.\r\n"); return true;
            }
            ets_printf("WARNING: erasing MTD partition '%s' (%u bytes); all data will be lost.\r\n",
                       argv[1], (unsigned)p.pos.size);
            (void)flash_erase_blocks(p.pos.offset, p.pos.size / BLDR_SECTOR_SIZE);
        } else if (argc == 3 && parse_u32(argv[1], &a) && parse_u32(argv[2], &b)) {
            (void)flash_erase_blocks(a, b);
        } else {
            uart_puts("Usage: erase <mtd-label> OR erase <flash_addr> <blocks-of-4096-bytes>\r\n");
        }
    } else if (strcmp(cmd, "flash") == 0) {
        if (argc != 4 || !parse_u32(argv[1], &a) || !parse_u32(argv[2], &b) || !parse_u32(argv[3], &c)) {
            uart_puts("Usage: flash <flash_addr> <psram_addr> <len>\r\n"); return true;
        }
        (void)flash_write_from_ram(a, b, c);
    } else if (strcmp(cmd, "dump") == 0) {
        if (argc != 4 || !parse_u32(argv[1], &a) || !parse_u32(argv[2], &b) || !parse_u32(argv[3], &c)) {
            uart_puts("Usage: dump <flash_addr> <len> <psram_addr>\r\n"); return true;
        }
        if (b == 0 || (a & 3U) != 0U || (b & 3U) != 0U || (c & 3U) != 0U ||
            (uint64_t)a + b > g_rom_flashchip.chip_size || !bldr_psram_range_valid(c, b)) {
            uart_puts("ERR: invalid range; require aligned flash range and a destination entirely in initialized PSRAM.\r\n"); return true;
        }
        uint32_t done = 0;
        while (done < b) {
            uint32_t n = b - done;
            if (n > BLDR_FLASH_IO_CHUNK) n = BLDR_FLASH_IO_CHUNK;
            if (bootloader_flash_read(a + done, g_io_buffer, n, true) != ESP_OK ||
                !bldr_psram_write(c + done, g_io_buffer, n)) {
                uart_puts("ERR: dump failed (flash read or PSRAM write).\r\n"); return true;
            }
            done += n; feed_watchdog();
        }
        ets_printf("OK: copied %u bytes from flash 0x%08x to PSRAM 0x%08x.\r\n", (unsigned)b, (unsigned)a, (unsigned)c);
    } else if (strcmp(cmd, "verify") == 0) {
        if (argc == 2) {
            vcs_partition_info_t p;
            if (!find_partition_by_label(argv[1], &p)) { uart_puts("ERR: partition not found or partition table invalid.\r\n"); return true; }
            if (p.kind != BLDR_VCS_KIND_ESP_IMAGE) { uart_puts("ERR: verify <label> accepts native ESP segmented images; use verify <addr> <len> for a raw image range.\r\n"); return true; }
            (void)verify_image(p.pos.offset, p.pos.size);
        } else if (argc == 3 && parse_u32(argv[1], &a) && parse_u32(argv[2], &b)) {
            (void)verify_image(a, b);
        } else {
            uart_puts("Usage: verify <partition-label> OR verify <flash_addr> <len>\r\n");
        }
    } else if (strcmp(cmd, "crc32") == 0) {
        vcs_partition_info_t p;
        uint32_t computed = 0U, expected = 0U, payload_size = 0U;
        if (argc != 2) {
            uart_puts("Usage: crc32 <partition-label>\r\n");
            return true;
        }
        if (!find_partition_by_label(argv[1], &p)) {
            uart_puts("ERR: partition not found or partition.vcs invalid.\r\n");
            return true;
        }
        if (strcmp(argv[1], "kernel") == 0) {
            esp_image_metadata_t metadata;
            if (!verify_native_kernel_image(&p, &metadata) ||
                !crc32_flash_range(p.pos.offset, metadata.image_len, &computed)) {
                uart_puts("ERR: native ESP image verification or CRC32 read failed.\r\n");
            } else {
                ets_printf("Native ESP image: PASS; CRC32=0x%08x image_len=0x%x entry=0x%08x\r\n",
                           (unsigned)computed, (unsigned)metadata.image_len,
                           (unsigned)metadata.image.entry_addr);
            }
        } else if (strcmp(argv[1], "romfile") == 0) {
            bool valid = verify_os_payload_partition(&p, "ROMF", &computed, &expected, &payload_size);
            if (payload_size != 0U) ets_printf("CRC32 payload: computed=0x%08x expected=0x%08x len=0x%x %s\r\n", (unsigned)computed, (unsigned)expected, (unsigned)payload_size, valid ? "PASS" : "FAIL");
            else uart_puts("ERR: invalid ROMFILE header/payload.\r\n");
        } else if (strcmp(argv[1], "ramdisk") == 0) {
            bool valid = verify_os_payload_partition(&p, "RAMD", &computed, &expected, &payload_size);
            if (payload_size != 0U) ets_printf("CRC32 payload: computed=0x%08x expected=0x%08x len=0x%x %s\r\n", (unsigned)computed, (unsigned)expected, (unsigned)payload_size, valid ? "PASS" : "FAIL");
            else uart_puts("ERR: invalid RAMDISK header/payload.\r\n");
        } else if (strcmp(argv[1], "rootfs") == 0) {
            uart_puts("ERR: rootfs is raw; use a filesystem-specific integrity check.\r\n");
        } else {
            uart_puts("ERR: CRC32 is supported for kernel image, romfile, and ramdisk; rootfs is raw.\r\n");
        }
    } else if (strcmp(cmd, "sha1sum") == 0) {
        uint8_t digest[20];
        if (argc == 4 && strcmp(argv[1], "-a") == 0 && parse_u32(argv[2], &a) && parse_u32(argv[3], &b)) {
            if (!sha1_flash_range(a, b, digest)) uart_puts("ERR: SHA-1 range invalid/read failed; address and length must be 4-byte aligned.\r\n");
            else print_sha1(digest);
        } else if (argc == 3 && strcmp(argv[1], "-p") == 0) {
            vcs_partition_info_t p;
            if (!find_partition_by_label(argv[2], &p)) uart_puts("ERR: partition not found or partition table invalid.\r\n");
            else if (!sha1_flash_range(p.pos.offset, p.pos.size, digest)) uart_puts("ERR: SHA-1 read failed.\r\n");
            else { print_sha1(digest); ets_printf("Partition: %s\r\n", argv[2]); }
        } else {
            uart_puts("Usage: sha1sum -a <flash_addr> <len> OR sha1sum -p <partition-label>\r\n");
        }
    } else if (strcmp(cmd, "xmdm") == 0) {
        uint32_t n = 0;
        if (argc == 3 && parse_hex_u32(argv[1], &a) && parse_hex_u32(argv[2], &b)) {
            (void)xmodem_receive(a, b, false, 0, NULL, &n);
        } else if (argc == 5 && strcmp(argv[1], "flash") == 0 && parse_hex_u32(argv[3], &b) && parse_hex_u32(argv[4], &c)) {
            vcs_partition_info_t p;
            if (!find_partition_by_label(argv[2], &p)) { uart_puts("ERR: partition not found or partition table invalid.\r\n"); return true; }
            if (!partition_is_mutable(&p)) { uart_puts("ERR: partition is read-only.\r\n"); return true; }
            if (c == 0 || (c & (BLDR_SECTOR_SIZE - 1U)) != 0U || (uint64_t)b + c > p.pos.size ||
                b > UINT32_MAX - p.pos.offset ||
                ((p.pos.offset + b) & (BLDR_SECTOR_SIZE - 1U)) != 0U) {
                uart_puts("ERR: XMODEM range must start on a sector boundary, have a nonzero sector-multiple length, and fit inside the partition.\r\n"); return true;
            }
            if (!consume_unlock_for_range(p.pos.offset + b, c, NULL)) return true;
            (void)xmodem_receive(0, c, true, p.pos.offset + b, &p, &n);
        } else {
            uart_puts("Usage: xmdm <psram_addr_hex> <len_hex> OR xmdm flash <label> <offset_hex> <max_len_hex>\r\n");
        }
    } else if (strcmp(cmd, "jump") == 0) {
        uart_puts("ERR: jump is disabled in v2.1.0; SRAM/PSRAM execution is not part of this monitor.\r\n");
    } else if (strcmp(cmd, "baud") == 0) {
        static const uint32_t rates[] = {9600U, 19200U, 38400U, 57600U, 115200U, 230400U, 460800U, 921600U};
        bool supported = false;
        if (argc != 2 || !parse_u32(argv[1], &a)) { uart_puts("Usage: baud <9600|19200|38400|57600|115200|230400|460800|921600>\r\n"); return true; }
        for (unsigned i = 0; i < sizeof(rates) / sizeof(rates[0]); ++i) if (a == rates[i]) supported = true;
        if (!supported) { uart_puts("ERR: unsupported baud rate.\r\n"); return true; }
        ets_printf("UART0 baud changing to %u; change the host terminal now.\r\n", (unsigned)a);
        ets_delay_us(100000);
        set_uart_baud(a);
    } else {
        uart_puts("ERR: unknown command. Use 'help'.\r\n");
    }
    return true;
}

void bootloader_hooks_include(void)
{
    /* Strong symbol forces the static library containing the hook into the link. */
}

void bootloader_before_init(void)
{
    /* Keep the pre-init hook empty; ROM flash/UART state is not yet fully ready. */
}

static bool enter_monitor_session(void)
{
    char line[BLDR_LINE_MAX];
    uart_puts("Monitor entered. Type 'help'.\r\n");
    prompt();
    while (g_monitor_elapsed_ms < BLDR_MONITOR_MAX_MS) {
        if (!read_line(line, sizeof(line))) return false;
        char *argv[BLDR_ARG_MAX];
        int argc = split_args(line, argv, BLDR_ARG_MAX);
        if (argc < 0) {
            uart_puts("ERR: too many command arguments.\r\n");
        } else {
            (void)process_command(argc, argv);
        }
        prompt();
    }
    uart_puts("Monitor time limit reached; returning to ESP-OS boot checks.\r\n");
    return false;
}

void bootloader_after_init(void)
{
    uint32_t waited_ms = 0U;
    uint8_t c = 0U;
    rtc_cpu_freq_config_t cfg;

    if (rtc_clk_cpu_freq_mhz_to_config(80U, &cfg)) rtc_clk_cpu_freq_set_config(&cfg);
    set_uart_baud(115200U);
    /* Flash was initialized by the ESP-IDF second-stage bootloader before
     * this hook. Do not reset MSPI/flash. Initialize the configured PSRAM now. */
    bldr_psram_init();
    rtc_clk_cpu_freq_get_config(&cfg);
    ets_printf("\r\nESP-OS Bootloader v%s\r\n", BLDR_VERSION);
    ets_printf("CPU frequency: %u MHz\r\n", (unsigned)cfg.freq_mhz);
    ets_printf("UART baudrate: %u\r\n", (unsigned)g_uart_baud);
    if (g_rom_flashchip.chip_size != 0U) {
        ets_printf("Flash: ESP-IDF bootloader initialized, capacity=%u bytes\r\n",
                   (unsigned)g_rom_flashchip.chip_size);
    } else {
        uart_puts("Flash: ERROR, ROM reports zero capacity; flash commands may fail.\r\n");
    }
    if (bldr_psram_ready()) {
        ets_printf("PSRAM: READY, detected=%u bytes, user range=0x%08x..0x%08x (end exclusive 0x%08x)\r\n",
                   (unsigned)bldr_psram_size(), (unsigned)bldr_psram_user_base(),
                   (unsigned)(bldr_psram_end() - 1U), (unsigned)bldr_psram_end());
    } else {
        uart_puts("PSRAM: UNAVAILABLE; all user-addressed RAM commands are disabled.\r\n");
    }
    uart_puts("Internal SRAM/IRAM is private to the bootloader and is not addressable by monitor commands.\r\n");
    uart_puts("Press any key in 0.5 seconds to enter console.\r\n");

    while (waited_ms < BLDR_TRIGGER_MS) {
        if (uart_rx_one_char(&c) == 0) {
            uart_puts("\r\n");
            for (;;) {
                (void)enter_monitor_session();
                if (post_self_test()) {
                    if (boot_esp_os_kernel()) return;
                }
                uart_puts("[BOOT] Automatic boot blocked; console remains available. Type 'go' to retry.\r\n");
            }
        }
        ets_delay_us(1000U);
        ++waited_ms;
        if ((waited_ms % 100U) == 0U) uart_putc('.');
        if ((waited_ms & 0xFFU) == 0U) feed_watchdog();
    }

    uart_puts("\r\n");
    if (post_self_test() && boot_esp_os_kernel()) return;
    uart_puts("[BOOT] Automatic boot blocked; entering monitor.\r\n");
    for (;;) {
        (void)enter_monitor_session();
        if (post_self_test()) {
            if (boot_esp_os_kernel()) return;
        }
        uart_puts("[BOOT] Boot failed; console remains available. Type 'go' to retry.\r\n");
    }
}

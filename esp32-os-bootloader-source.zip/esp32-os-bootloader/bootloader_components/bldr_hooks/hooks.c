/*
 * SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
 * SPDX-License-Identifier: GPL-3.0-only
 */
/*
 * ESP32-OS bootloader UART monitor.
 * Target: ESP32-S3 / ESP-IDF v4.4.7.
 *
 * ESP-OS boot path for ESP32-S3 / ESP-IDF v4.4.7.
 * ESP-IDF's partition table anchors the reserved `vcs_table` storage region;
 * partition.vcs defines the OS regions. Kernel images use the native ESP-IDF
 * segmented image format so the bootloader can establish MMU/XIP mappings.
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>

#include "sdkconfig.h"
#include "esp_attr.h"
#include "esp32s3/rom/ets_sys.h"
#include "esp32s3/rom/uart.h"
#include "esp32s3/rom/rtc.h"
#include "esp32s3/rom/crc.h"
#include "esp32s3/rom/cache.h"
#include "esp32s3/rom/spi_flash.h"
#include "soc/rtc.h"
#include "soc/soc.h"
#include "soc/uart_reg.h"
#include "soc/rtc_cntl_struct.h"
#include "hal/wdt_hal.h"
#include "bootloader_flash_priv.h"
#include "bootloader_utility.h"
#include "bootloader_config.h"
#include "esp_flash_partitions.h"
#include "esp_image_format.h"
#include "esp_flash_encrypt.h"
#include "bldr_memory.h"
#include "bldr_dt.h"
#include "bldr_display.h"

#define BLDR_VERSION             "1.0.0"
#define BLDR_WATERMARK           "By Wiring-ChaosVN"
#define BLDR_TRIGGER_MS          1000U
#define BLDR_TRIGGER_DOT_MS      200U
#define BLDR_FX_MIN_MS           50U
#define BLDR_FX_SPAN_MS          150U
#define BLDR_MONITOR_MAX_MS      1800000U /* 30 minutes; watchdog is fed while waiting */
#define BLDR_LINE_MAX            128U
#define BLDR_ARG_MAX             8U
#define BLDR_SECTOR_SIZE         0x1000U
#define BLDR_FLASH_IO_CHUNK      256U
#define BLDR_MD_MAX              1024U /* bytes shown by one `md` */
#define BLDR_XMODEM_PACKET_MAX   1024U
#define BLDR_RAM_BUFFER_SIZE     256U
#define BLDR_XMODEM_PACKET_BUFFER_SIZE 1024U
#define BLDR_XMODEM_SESSION_TIMEOUT_MS 15000U
#define BLDR_XMODEM_C_INTERVAL_MS      1000U
#define BLDR_UART_NUM            0U
#define XMODEM_SOH               0x01U
#define XMODEM_STX               0x02U
#define XMODEM_EOT               0x04U
#define XMODEM_ACK               0x06U
#define XMODEM_NAK               0x15U
#define XMODEM_CAN               0x18U
#define XMODEM_CRC_REQ           'C'

/* nexus.ptb: binary MTD table stored in the IDF anchor partition "nexus_ptb".
 * Header (16 B): magic "NPTB", u16 version, u16 count, u32 total_size, u32 crc32(entries).
 * Entry (32 B):  char name[16], u32 offset, u32 size, u32 vaddr, u16 kind, u16 flags.
 * Entry order is the MTD index: mtd0 is always the bootloader. */
#define BLDR_VCS_ANCHOR_LABEL    "nexus_ptb"
#define BLDR_VCS_MAGIC           "NPTB"
#define BLDR_VCS_VERSION         1U
#define BLDR_VCS_MAX_ENTRIES     8U
#define BLDR_PTB_HDR_SIZE        16U
#define BLDR_PTB_ENTRY_SIZE      32U
#define BLDR_VCS_FLAG_READ_ONLY  (1U << 0)
#define BLDR_VCS_FLAG_XIP        (1U << 1)
#define BLDR_VCS_FLAG_ENCRYPTED  (1U << 2)

enum {
    BLDR_VCS_KIND_BOOT = 0U,
    BLDR_VCS_KIND_ESP_IMAGE = 1U,
    BLDR_VCS_KIND_RAW_FS = 2U,
    BLDR_VCS_KIND_BLOB = 3U,
    BLDR_VCS_KIND_DATA = 4U,
};

typedef struct {
    char label[16];
    esp_partition_pos_t pos;
    uint32_t flags;
    uint32_t kind;
    uint32_t vaddr;     /* virtual address convention for the OS; 0 = not mapped */
} vcs_partition_info_t;

typedef struct {        /* on-flash nexus.ptb entry */
    char label[16];
    uint32_t offset, size, vaddr;
    uint16_t kind, flags;
} ptb_entry_t;

typedef struct {        /* on-flash nexus.ptb header */
    char magic[4];
    uint16_t version, count;
    uint32_t total_size, crc32;
} ptb_header_t;

static vcs_partition_info_t g_vcs_partitions[BLDR_VCS_MAX_ENTRIES];
static int g_vcs_partition_count;
static uint32_t crc32_ieee_update(uint32_t crc, const uint8_t *data, size_t len);

/* Internal buffers are private to bootloader code. The 256-byte RAM buffer is
 * only used by POST; the 1-KiB internal SRAM buffer stages one XMODEM packet. Neither is
 * exposed as a legal user-addressed destination/source. */
static uint8_t g_ram_buffer[BLDR_RAM_BUFFER_SIZE]
    __attribute__((section(".iram1"), aligned(32)));
/* DRAM (byte-accessible), not .iram1: the packet is filled byte by byte. */
static uint8_t g_xmodem_packet[BLDR_XMODEM_PACKET_BUFFER_SIZE] __attribute__((aligned(4)));
static uint8_t g_io_buffer[BLDR_FLASH_IO_CHUNK] __attribute__((aligned(32)));
static uint8_t g_cmp_buffer[BLDR_FLASH_IO_CHUNK] __attribute__((aligned(4)));
static uint32_t g_monitor_elapsed_ms;
static bool g_skip_lf;
static bool g_unlock_armed;
static char g_unlock_label[17];
static uint32_t g_unlock_deadline_ms;
static uint32_t g_uart_baud = 115200U;

static void uart_putc(char c)
{
    (void)uart_tx_one_char((uint8_t)c);
}

static void uart_puts(const char *s)
{
    while (*s != '\0') {
        uart_putc(*s++);
    }
}

/* Shared message helpers: tags and the CRLF live in one copy (DRAM is scarce). */
static void say(const char *tag, const char *msg)
{
    uart_puts(tag);
    uart_puts(msg);
    uart_puts("\r\n");
}
#define ERR(m)   say("ERR: ", (m))
#define BOOT(m)  say("[BOOT] ", (m))
#define POSTM(m) say("[POST] ", (m))

/* Name/usage pairs shared by `help <cmd>`, `<cmd> -h` and argument errors. */
static const char k_usage[] =
    "help\0help [cmd]\0"
    "version\0version\0"
    "mtd\0mtd (alias: partitions)\0"
    "go\0go [mtdN|label]: POST, boot esp-image (default kernel)\0"
    "reboot\0reboot\0"
    "verify\0verify <mtd>|<addr> <len>\0"
    "crc32\0crc32 <mtd>\0"
    "xmdm\0xmdm <psram_hex> <len_hex>|flash <mtd> <off_hex> <max_hex>\0"
    "unlock\0unlock <mtd> (1 op, 30 s)\0"
    "erase\0erase <mtd>|<addr> <sectors>\0"
    "flash\0flash <addr> <psram> <len>\0"
    "dump\0dump <addr> <len> <psram>\0"
    "info\0info\0"
    "jump\0jump <psram_addr>: start NPIM image (XIP, 64K-aligned)\0"
    "baud\0baud 9600|19200|38400|57600|115200|230400|460800|921600\0";

static void usage(const char *cmd)
{
    if (strcmp(cmd, "?") == 0) cmd = "help";
    else if (strcmp(cmd, "partitions") == 0) cmd = "mtd";
    for (const char *p = k_usage; *p != '\0';) {
        const char *use = p + strlen(p) + 1;
        if (strcmp(p, cmd) == 0) {
            uart_puts("Usage: ");
            uart_puts(use);
            uart_puts("\r\n");
            return;
        }
        p = use + strlen(use) + 1;
    }
    ERR("unknown command");
}

static void prompt(void)
{
    uart_puts("bldr> ");
}

/* Program UART0 for `baud` with the same maths as ESP-IDF v4.4.7 uart_ll_set_baudrate(), which
 * is what the IDF bootloader itself used to bring the console up at 115200. The source clock is
 * read from UART_SCLK_SEL (ESP32-S3 ROM runs UART0 from XTAL 40 MHz, not APB 80 MHz) and the
 * 8-bit prescaler (UART_SCLK_DIV_NUM) is used when the 12-bit integer divider would overflow
 * (e.g. 9600 baud at 40 MHz needs 4166 > 4095). The ROM divider helper is NOT used: it only
 * writes CLKDIV, ignores the prescaler and the real clock source. Divider = int<<4 | frac,
 * rounded to nearest. */
static uint32_t uart_sclk_hz(void)
{
    switch (REG_GET_FIELD(UART_CLK_CONF_REG(BLDR_UART_NUM), UART_SCLK_SEL)) {
    case 2U: return RTC_CLK_FREQ;
    case 3U: return XTAL_CLK_FREQ;
    default: return APB_CLK_FREQ;
    }
}

static void set_uart_baud(uint32_t baud)
{
    if (baud == 0U) return;
    uart_tx_wait_idle(BLDR_UART_NUM);
    const uint64_t sclk = uart_sclk_hz();
    const uint64_t max_div = 0xFFFU;   /* UART_CLKDIV integer part is 12 bits */
    uint64_t pre = (sclk + max_div * baud - 1U) / (max_div * baud);
    if (pre < 1U) pre = 1U;
    if (pre > 256U) pre = 256U;        /* UART_SCLK_DIV_NUM is 8 bits (value = pre - 1) */
    const uint64_t den = (uint64_t)baud * pre;
    const uint32_t div = (uint32_t)(((sclk << 4) + den / 2U) / den);
    REG_SET_FIELD(UART_CLKDIV_REG(BLDR_UART_NUM), UART_CLKDIV, div >> 4);
    REG_SET_FIELD(UART_CLKDIV_REG(BLDR_UART_NUM), UART_CLKDIV_FRAG, div & 0xFU);
    REG_SET_FIELD(UART_CLK_CONF_REG(BLDR_UART_NUM), UART_SCLK_DIV_NUM, (uint32_t)pre - 1U);
    g_uart_baud = baud;
}

static void feed_watchdog(void);

/*
 * Intentional cosmetic pause between monitor/POST messages.
 * This is only for presentation; it does not synchronize hardware or affect
 * a boot decision. Set both values to 0 to remove the effect.
 */
static void fx_wait(void)
{
#if (BLDR_FX_MIN_MS > 0U) || (BLDR_FX_SPAN_MS > 0U)
    static uint32_t seed = 0x9E3779B9U;
    uint32_t ccount;
    __asm__ __volatile__("rsr.ccount %0" : "=a"(ccount));
    seed ^= ccount;
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;

    const uint32_t span = BLDR_FX_SPAN_MS;
    const uint32_t delay_ms = BLDR_FX_MIN_MS + (span != 0U ? seed % (span + 1U) : 0U);
    for (uint32_t i = 0; i < delay_ms; ++i) {
        ets_delay_us(1000U);
        if ((i & 0x3FU) == 0x3FU) feed_watchdog();
    }
#endif
}

static void feed_watchdog(void)
{
#if defined(CONFIG_BOOTLOADER_WDT_ENABLE) && CONFIG_BOOTLOADER_WDT_ENABLE
    static wdt_hal_context_t ctx = { .inst = WDT_RWDT, .rwdt_dev = &RTCCNTL };
    wdt_hal_write_protect_disable(&ctx);
    wdt_hal_feed(&ctx);
    wdt_hal_write_protect_enable(&ctx);
#endif
}

static void delay_1ms(void)
{
    ets_delay_us(1000);
    if (g_monitor_elapsed_ms < UINT32_MAX) {
        ++g_monitor_elapsed_ms;
    }
    if ((g_monitor_elapsed_ms & 0xFFU) == 0U) {
        feed_watchdog();
    }
}


static bool parse_u32(const char *s, uint32_t *out)
{
    uint32_t base = 10U;
    uint32_t v = 0U;
    const char *p = s;
    if (s == NULL || *s == '\0' || out == NULL || *s == '-') {
        return false;
    }
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) {
        base = 16U;
        p += 2;
        if (*p == '\0') return false;
    }
    for (; *p != '\0'; ++p) {
        uint32_t d;
        if (*p >= '0' && *p <= '9') d = (uint32_t)(*p - '0');
        else if (base == 16U && *p >= 'a' && *p <= 'f') d = 10U + (uint32_t)(*p - 'a');
        else if (base == 16U && *p >= 'A' && *p <= 'F') d = 10U + (uint32_t)(*p - 'A');
        else return false;
        if (d >= base || v > (UINT32_MAX - d) / base) return false;
        v = v * base + d;
    }
    *out = v;
    return true;
}

static bool parse_hex_u32(const char *s, uint32_t *out)
{
    uint32_t v = 0U;
    const char *p = s;
    if (p == NULL || *p == '\0' || out == NULL || *p == '-') return false;
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) p += 2;
    if (*p == '\0') return false;
    for (; *p != '\0'; ++p) {
        uint32_t d;
        if (*p >= '0' && *p <= '9') d = (uint32_t)(*p - '0');
        else if (*p >= 'a' && *p <= 'f') d = 10U + (uint32_t)(*p - 'a');
        else if (*p >= 'A' && *p <= 'F') d = 10U + (uint32_t)(*p - 'A');
        else return false;
        if (v > (UINT32_MAX - d) / 16U) return false;
        v = v * 16U + d;
    }
    *out = v;
    return true;
}

static int split_args(char *line, char **argv, int max_args)
{
    int argc = 0;
    char *p = line;
    while (*p != '\0') {
        while (*p == ' ' || *p == '\t') ++p;
        if (*p == '\0') break;
        if (argc >= max_args) return -1;
        argv[argc++] = p;
        while (*p != '\0' && *p != ' ' && *p != '\t') ++p;
        if (*p != '\0') *p++ = '\0';
    }
    return argc;
}

static bool command_has_help(int argc, char **argv)
{
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) return true;
    }
    return false;
}

static bool copy_xmodem_packet_to_io(uint32_t packet_offset, uint32_t len)
{
    if ((packet_offset & 3U) != 0U || len == 0U || len > sizeof(g_io_buffer) ||
        (len & 3U) != 0U || (uint64_t)packet_offset + len > BLDR_XMODEM_PACKET_MAX ||
        (uint64_t)packet_offset + len > sizeof(g_xmodem_packet)) return false;
    const volatile uint32_t *src = (const volatile uint32_t *)(g_xmodem_packet + packet_offset);
    uint32_t *dst = (uint32_t *)g_io_buffer;
    for (uint32_t i = 0U; i < len / sizeof(uint32_t); ++i) dst[i] = src[i];
    return true;
}

static bool load_idf_partition_table(const esp_partition_info_t **out, int *count)
{
    const esp_partition_info_t *table = bootloader_mmap(CONFIG_PARTITION_TABLE_OFFSET,
                                                         ESP_PARTITION_TABLE_MAX_LEN);
    if (table == NULL) {
        ERR("map IDF table");
        return false;
    }
    esp_err_t err = esp_partition_table_verify(table, false, count);
    if (err != ESP_OK) {
        bootloader_munmap(table);
        ERR("IDF table invalid");
        return false;
    }
    *out = table;
    return true;
}

static void partition_label(const vcs_partition_info_t *p, char out[17])
{
    memcpy(out, p->label, 16);
    out[16] = '\0';
}

static void idf_partition_label(const esp_partition_info_t *p, char out[17])
{
    memcpy(out, p->label, 16);
    out[16] = '\0';
}


static bool ranges_overlap(uint32_t a_off, uint32_t a_size, uint32_t b_off, uint32_t b_size)
{
    uint64_t a_end = (uint64_t)a_off + a_size;
    uint64_t b_end = (uint64_t)b_off + b_size;
    return ((uint64_t)a_off < b_end) && ((uint64_t)b_off < a_end);
}

static bool find_partition_in_table(const vcs_partition_info_t *table, int count,
                                    const char *label, vcs_partition_info_t *out)
{
    if (table == NULL || label == NULL) return false;
    for (int i = 0; i < count; ++i) {
        char name[17];
        partition_label(&table[i], name);
        if (strcmp(name, label) == 0) {
            if (out != NULL) *out = table[i];
            return true;
        }
    }
    return false;
}

/* Look up by label ("kernel") or by MTD index ("mtd2"). */
static bool find_mtd(const vcs_partition_info_t *table, int count, const char *name,
                     vcs_partition_info_t *out)
{
    if (name != NULL && strncmp(name, "mtd", 3) == 0 && name[3] >= '0' && name[3] <= '9') {
        uint32_t idx = 0U;
        const char *q = name + 3;
        for (; *q >= '0' && *q <= '9' && idx < 100U; ++q) idx = idx * 10U + (uint32_t)(*q - '0');
        if (*q == '\0') {
            if (idx >= (uint32_t)count) return false;
            if (out != NULL) *out = table[idx];
            return true;
        }
    }
    return find_partition_in_table(table, count, name, out);
}

static bool vaddr_ok(const vcs_partition_info_t *p)
{
    if (p->vaddr == 0U) return true;
    const uint64_t end = (uint64_t)p->vaddr + p->pos.size;
    return ((p->vaddr >= 0x3C000000U && end <= 0x3E000000ULL) ||
            (p->vaddr >= 0x42000000U && end <= 0x44000000ULL)) &&
           ((p->vaddr ^ p->pos.offset) & 0xFFFFU) == 0U; /* same offset inside a 64-KiB MMU page */
}

static bool validate_vcs_entries(const esp_partition_info_t *idf_table, int idf_count,
                                 const esp_partition_info_t *anchor)
{
    static const char *const required[] = {"romfile", "kernel", "rootfs", "rootfs_data"};
    const uint64_t flash_size = g_rom_flashchip.chip_size;
    const uint64_t protected_end = (uint64_t)CONFIG_PARTITION_TABLE_OFFSET + BLDR_SECTOR_SIZE;
    const vcs_partition_info_t *boot = &g_vcs_partitions[0];

    /* mtd0: the bootloader itself, read-only, ending before the IDF partition table. */
    if (boot->kind != BLDR_VCS_KIND_BOOT || (boot->flags & BLDR_VCS_FLAG_READ_ONLY) == 0U ||
        boot->pos.offset != CONFIG_BOOTLOADER_OFFSET_IN_FLASH ||
        (uint64_t)boot->pos.offset + boot->pos.size > CONFIG_PARTITION_TABLE_OFFSET) return false;
    for (unsigned i = 0; i < sizeof(required) / sizeof(required[0]); ++i) {
        if (!find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, required[i], NULL)) return false;
    }

    for (int i = 0; i < g_vcs_partition_count; ++i) {
        const vcs_partition_info_t *p = &g_vcs_partitions[i];
        char name[17];
        partition_label(p, name);
        uint64_t end = (uint64_t)p->pos.offset + p->pos.size;
        if (name[0] == '\0' || p->pos.size == 0U || !vaddr_ok(p) ||
            (p->pos.offset & (BLDR_SECTOR_SIZE - 1U)) != 0U ||
            (p->pos.size & (BLDR_SECTOR_SIZE - 1U)) != 0U || end > flash_size) return false;
        if (i > 0 && (p->kind == BLDR_VCS_KIND_BOOT || p->pos.offset < protected_end ||
                      ranges_overlap(p->pos.offset, p->pos.size, anchor->pos.offset, anchor->pos.size))) return false;
        for (int j = 0; j < i; ++j) {
            char other[17];
            partition_label(&g_vcs_partitions[j], other);
            if (strcmp(name, other) == 0 ||
                ranges_overlap(p->pos.offset, p->pos.size,
                               g_vcs_partitions[j].pos.offset, g_vcs_partitions[j].pos.size)) return false;
        }
        for (int j = 0; i > 0 && j < idf_count; ++j) {
            char idf_name[17];
            idf_partition_label(&idf_table[j], idf_name);
            if (strcmp(idf_name, BLDR_VCS_ANCHOR_LABEL) != 0 &&
                ranges_overlap(p->pos.offset, p->pos.size,
                               idf_table[j].pos.offset, idf_table[j].pos.size)) return false;
        }
    }

    vcs_partition_info_t kernel, rootfs, rootfs_data, romfile, ramdisk;
    (void)find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "kernel", &kernel);
    (void)find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "rootfs", &rootfs);
    (void)find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "rootfs_data", &rootfs_data);
    (void)find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "romfile", &romfile);
    if (kernel.kind != BLDR_VCS_KIND_ESP_IMAGE || (kernel.flags & BLDR_VCS_FLAG_XIP) == 0U ||
        (kernel.pos.offset & 0xFFFFU) != 0U || rootfs.kind != BLDR_VCS_KIND_RAW_FS ||
        rootfs_data.kind != BLDR_VCS_KIND_DATA || romfile.kind != BLDR_VCS_KIND_BLOB ||
        (romfile.flags & BLDR_VCS_FLAG_READ_ONLY) == 0U) return false;
    /* ramdisk is optional (the initramfs can come from a PSRAM boot image). */
    if (find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "ramdisk", &ramdisk) &&
        ramdisk.kind != BLDR_VCS_KIND_BLOB) return false;
    /* dtb is optional (the bootloader runs without a display); if present it is a blob. */
    vcs_partition_info_t dtbp;
    if (find_partition_in_table(g_vcs_partitions, g_vcs_partition_count, "dtb", &dtbp) &&
        dtbp.kind != BLDR_VCS_KIND_BLOB) return false;
    return true;
}

static bool load_partition_table(const vcs_partition_info_t **out, int *count)
{
    const esp_partition_info_t *idf_table = NULL;
    int idf_count = 0;
    esp_partition_info_t anchor = {0};
    if (out == NULL || count == NULL || !load_idf_partition_table(&idf_table, &idf_count)) return false;
    bool found_anchor = false;
    for (int i = 0; i < idf_count; ++i) {
        char name[17];
        idf_partition_label(&idf_table[i], name);
        if (strcmp(name, BLDR_VCS_ANCHOR_LABEL) == 0 && idf_table[i].type == PART_TYPE_DATA) {
            anchor = idf_table[i];
            found_anchor = true;
            break;
        }
    }
    /* bootloader_mmap() allows only ONE live mapping ("tried to bootloader_mmap
     * twice"), so release the IDF table before mapping the anchor partition. */
    bootloader_munmap(idf_table);
    idf_table = NULL;
    if (!found_anchor || anchor.pos.size < BLDR_SECTOR_SIZE ||
        (uint64_t)anchor.pos.offset + anchor.pos.size > g_rom_flashchip.chip_size) {
        ERR("no nexus_ptb anchor");
        return false;
    }

    const uint8_t *mapped = bootloader_mmap(anchor.pos.offset, anchor.pos.size);
    if (mapped == NULL) {
        ERR("map nexus_ptb");
        return false;
    }
    bool valid = false;
    bool parsed = false;
    g_vcs_partition_count = 0;
    const ptb_header_t *h = (const ptb_header_t *)mapped;
    const uint8_t *rows = mapped + BLDR_PTB_HDR_SIZE;
    if (memcmp(h->magic, BLDR_VCS_MAGIC, 4U) != 0 || h->version != BLDR_VCS_VERSION ||
        h->count < 5U || h->count > BLDR_VCS_MAX_ENTRIES ||
        h->total_size != BLDR_PTB_HDR_SIZE + (uint32_t)h->count * BLDR_PTB_ENTRY_SIZE ||
        h->total_size > anchor.pos.size) {
        ERR("ptb header");
    } else if (crc32_ieee_update(0U, rows, (size_t)h->count * BLDR_PTB_ENTRY_SIZE) != h->crc32) {
        ERR("ptb CRC");
    } else {
        parsed = true;
        for (unsigned i = 0; i < h->count; ++i) {
            const ptb_entry_t *e = (const ptb_entry_t *)(rows + i * BLDR_PTB_ENTRY_SIZE);
            vcs_partition_info_t *d = &g_vcs_partitions[i];
            memcpy(d->label, e->label, sizeof(d->label));
            d->pos.offset = e->offset;
            d->pos.size = e->size;
            d->vaddr = e->vaddr;
            d->kind = e->kind;
            d->flags = e->flags;
            if (e->kind > BLDR_VCS_KIND_DATA || (e->flags & ~7U) != 0U) { ERR("ptb row"); parsed = false; break; }
        }
        if (parsed) g_vcs_partition_count = (int)h->count;
    }
    bootloader_munmap(mapped);
    if (parsed) {
        /* Re-map the IDF table (one mapping at a time) to check overlaps. */
        valid = load_idf_partition_table(&idf_table, &idf_count) &&
                validate_vcs_entries(idf_table, idf_count, &anchor);
        if (idf_table != NULL) bootloader_munmap(idf_table);
        if (!valid) ERR("ptb layout invalid");
    }
    if (!valid) {
        g_vcs_partition_count = 0;
        return false;
    }
    *out = g_vcs_partitions;
    *count = g_vcs_partition_count;
    return true;
}

static bool partition_is_mutable(const vcs_partition_info_t *p)
{
    if (p == NULL || (p->flags & BLDR_VCS_FLAG_READ_ONLY) != 0U) return false;
    uint64_t end = (uint64_t)p->pos.offset + p->pos.size;
    if (p->pos.size == 0U || end > g_rom_flashchip.chip_size) return false;
    return true;
}

static bool find_partition_by_label(const char *label, vcs_partition_info_t *out)
{
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    if (!load_partition_table(&table, &count)) return false;
    return find_mtd(table, count, label, out);
}

static bool protected_flash_range(uint32_t addr, uint32_t len)
{
    uint64_t end = (uint64_t)addr + len;
    uint64_t protected_start = CONFIG_BOOTLOADER_OFFSET_IN_FLASH;
    uint64_t protected_end = (uint64_t)CONFIG_PARTITION_TABLE_OFFSET + BLDR_SECTOR_SIZE;
    return ((uint64_t)addr < protected_end && end > protected_start);
}

static bool find_partition_for_range(uint32_t addr, uint32_t len, vcs_partition_info_t *out)
{
    uint64_t end = (uint64_t)addr + len;
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    if (len == 0U || end > g_rom_flashchip.chip_size || protected_flash_range(addr, len)) return false;
    if (!load_partition_table(&table, &count)) return false;
    for (int i = 0; i < count; ++i) {
        uint64_t pstart = table[i].pos.offset;
        uint64_t pend = pstart + table[i].pos.size;
        if ((uint64_t)addr >= pstart && end <= pend) {
            if (partition_is_mutable(&table[i])) {
                if (out != NULL) *out = table[i];
                return true;
            }
            return false;
        }
    }
    return false;
}

static bool consume_unlock_for_range(uint32_t addr, uint32_t len, vcs_partition_info_t *p)
{
    vcs_partition_info_t found;
    char name[17];
    if (!find_partition_for_range(addr, len, &found)) {
        ERR("range not in writable partition");
        return false;
    }
    partition_label(&found, name);
    if (g_unlock_armed && g_monitor_elapsed_ms >= g_unlock_deadline_ms) {
        g_unlock_armed = false;
        g_unlock_label[0] = '\0';
        ERR("unlock expired");
        return false;
    }
    if (!g_unlock_armed || strcmp(g_unlock_label, name) != 0) {
        ets_printf("ERR: run 'unlock %s' first\r\n", name);
        return false;
    }
    g_unlock_armed = false;
    g_unlock_label[0] = '\0';
    if (p != NULL) *p = found;
    return true;
}

static bool partition_writes_encrypted(const vcs_partition_info_t *p)
{
    return p != NULL && esp_flash_encryption_enabled() &&
           ((p->flags & BLDR_VCS_FLAG_ENCRYPTED) != 0U);
}

static const char *vcs_kind_name(uint32_t kind)
{
    switch (kind) {
    case BLDR_VCS_KIND_BOOT: return "boot";
    case BLDR_VCS_KIND_ESP_IMAGE: return "esp-image";
    case BLDR_VCS_KIND_RAW_FS: return "raw";
    case BLDR_VCS_KIND_BLOB: return "blob";
    case BLDR_VCS_KIND_DATA: return "data";
    default: return "unknown";
    }
}

static void print_partition_table(void)
{
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    if (!load_partition_table(&table, &count)) return;
    uart_puts("nexus.ptb:\r\n");
    uart_puts("MTD Label        Kind      Offset     Size       VAddr      Flags\r\n");
    for (int i = 0; i < count; ++i) {
        char name[17];
        partition_label(&table[i], name);
        ets_printf("%-3d %-12s %-9s 0x%08x 0x%08x 0x%08x %s%s%s\r\n",
                   i, name, vcs_kind_name(table[i].kind),
                   (unsigned)table[i].pos.offset, (unsigned)table[i].pos.size, (unsigned)table[i].vaddr,
                   (table[i].flags & BLDR_VCS_FLAG_READ_ONLY) ? "ro" : "rw",
                   (table[i].flags & BLDR_VCS_FLAG_XIP) ? ",xip" : "",
                   (table[i].flags & BLDR_VCS_FLAG_ENCRYPTED) ? ",enc" : "");
    }
}

static uint16_t crc16_xmodem_update(uint16_t crc, const uint8_t *data, size_t len)
{
    for (size_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)data[i] << 8;
        for (unsigned b = 0; b < 8; ++b) {
            crc = (crc & 0x8000U) ? (uint16_t)((crc << 1) ^ 0x1021U) : (uint16_t)(crc << 1);
        }
    }
    return crc;
}

#define BLDR_OS_BLOB_HEADER_SIZE 16U
#define BLDR_OS_BLOB_VERSION 1U

/* Standard CRC-32 (zlib/IEEE) using the chip's ROM routine: seed 0, chainable,
 * no pre/post inversion needed. Much faster than a bitwise loop (POST CRCs the ramdisk). */
static uint32_t crc32_ieee_update(uint32_t crc, const uint8_t *data, size_t len)
{
    return crc32_le(crc, data, (uint32_t)len); /* ROM; IDF alias: esp_rom_crc32_le */
}

static bool crc32_flash_range(uint32_t addr, uint32_t len, uint32_t *out_crc)
{
    uint32_t done = 0U;
    uint32_t crc = 0U;
    if (out_crc == NULL || len == 0U || (uint64_t)addr + len > g_rom_flashchip.chip_size) return false;
    while (done < len) {
        uint32_t n = len - done;
        if (n > BLDR_FLASH_IO_CHUNK) n = BLDR_FLASH_IO_CHUNK;
        if (bootloader_flash_read(addr + done, g_io_buffer, n, true) != ESP_OK) return false;
        crc = crc32_ieee_update(crc, g_io_buffer, n);
        done += n;
        feed_watchdog();
    }
    *out_crc = crc;
    return true;
}

/* ROMF/RAMD/ROOT use a 16-byte data header: magic[4], version, payload size, CRC32.
 * Kernel is a native ESP-IDF segmented image (0xE9 at partition offset), with its
 * segment checksum/SHA-256 validated by esp_image_verify so XIP MMU setup can work. */
static bool verify_os_payload_partition(const vcs_partition_info_t *p, const char magic[4],
                                        uint32_t *computed_crc, uint32_t *expected_crc,
                                        uint32_t *payload_size)
{
    uint32_t size = 0U, expected = 0U, version = BLDR_OS_BLOB_VERSION;
    if (p == NULL || p->pos.size <= BLDR_OS_BLOB_HEADER_SIZE ||
        p->kind != BLDR_VCS_KIND_BLOB ||
        (uint64_t)p->pos.offset + p->pos.size > g_rom_flashchip.chip_size ||
        bootloader_flash_read(p->pos.offset, g_io_buffer, BLDR_OS_BLOB_HEADER_SIZE, true) != ESP_OK) return false;
    if (memcmp(g_io_buffer, magic, 4U) != 0) return false;
    memcpy(&version, g_io_buffer + 4U, sizeof(version));
    memcpy(&size, g_io_buffer + 8U, sizeof(size));
    memcpy(&expected, g_io_buffer + 12U, sizeof(expected));
    if (version != BLDR_OS_BLOB_VERSION || size == 0U || size > p->pos.size - BLDR_OS_BLOB_HEADER_SIZE) return false;
    uint32_t computed = 0U;
    if (!crc32_flash_range(p->pos.offset + BLDR_OS_BLOB_HEADER_SIZE, size, &computed)) return false;
    if (computed_crc != NULL) *computed_crc = computed;
    if (expected_crc != NULL) *expected_crc = expected;
    if (payload_size != NULL) *payload_size = size;
    return computed == expected;
}

static bool verify_native_kernel_image(const vcs_partition_info_t *p, esp_image_metadata_t *metadata)
{
    if (p == NULL || p->kind != BLDR_VCS_KIND_ESP_IMAGE ||
        (p->flags & BLDR_VCS_FLAG_XIP) == 0U || (p->pos.offset & 0xFFFFU) != 0U ||
        p->pos.size == 0U || (uint64_t)p->pos.offset + p->pos.size > g_rom_flashchip.chip_size) return false;
    esp_image_metadata_t local_metadata;
    if (metadata == NULL) metadata = &local_metadata;
    esp_err_t err = esp_image_verify(ESP_IMAGE_VERIFY, &p->pos, metadata);
    return err == ESP_OK && metadata->image_len > 0U && metadata->image_len <= p->pos.size;
}

static bool post_ram_buffer_test(void)
{
    volatile uint32_t *words = (volatile uint32_t *)g_ram_buffer;
    const uint32_t count = (uint32_t)(sizeof(g_ram_buffer) / sizeof(uint32_t));
    for (uint32_t i = 0; i < count; ++i) words[i] = 0xA55A3CC3U ^ i;
    __asm__ __volatile__("memw" ::: "memory");
    for (uint32_t i = 0; i < count; ++i) if (words[i] != (0xA55A3CC3U ^ i)) return false;
    for (uint32_t i = 0; i < count; ++i) words[i] = 0x5AA5C33CU ^ i;
    __asm__ __volatile__("memw" ::: "memory");
    for (uint32_t i = 0; i < count; ++i) if (words[i] != (0x5AA5C33CU ^ i)) return false;
    for (uint32_t i = 0; i < count; ++i) words[i] = 0U;
    __asm__ __volatile__("memw" ::: "memory");
    return true;
}

static void post_print_status(const char *name, bool pass)
{
    fx_wait();
    ets_printf("[POST] %s: %s\r\n", name, pass ? "PASS" : "FAIL");
}

static bool post_self_test(void)
{
    bool ok = true;
    bool ram_ok, flash_ok;
    const vcs_partition_info_t *table = NULL;
    vcs_partition_info_t kernel, romfile, ramdisk, rootfs, rootfs_data;
    int count = 0;

    uart_puts("\r\n");
    POSTM("Self-test...");
    ram_ok = post_ram_buffer_test();
    post_print_status("SRAM buffer", ram_ok);
    ok = ok && ram_ok;

    bool psram_ok = bldr_psram_ready();
    post_print_status("PSRAM init and mapped range", psram_ok);
    ok = ok && psram_ok;

    flash_ok = (g_rom_flashchip.chip_size != 0U) &&
               (bootloader_flash_read(0U, g_io_buffer, 16U, true) == ESP_OK);
    post_print_status("Flash read", flash_ok);
    ok = ok && flash_ok;

    {
        const esp_partition_info_t *idf_table = NULL;
        int idf_count = 0;
        bool idf_ok = load_idf_partition_table(&idf_table, &idf_count);
        if (idf_ok) bootloader_munmap(idf_table);
        post_print_status("IDF partition table", idf_ok);
        ok = ok && idf_ok;
    }

    if (!load_partition_table(&table, &count)) {
        post_print_status("nexus.ptb table/CRC32/layout", false);
        POSTM("Result: FAIL");
        return false;
    }
    post_print_status("nexus.ptb table/CRC32/layout", true);

    bool has_kernel = find_partition_in_table(table, count, "kernel", &kernel);
    bool has_romfile = find_partition_in_table(table, count, "romfile", &romfile);
    bool has_ramdisk = find_partition_in_table(table, count, "ramdisk", &ramdisk);
    bool has_rootfs = find_partition_in_table(table, count, "rootfs", &rootfs);
    bool has_rootfs_data = find_partition_in_table(table, count, "rootfs_data", &rootfs_data);

    esp_image_metadata_t kernel_metadata;
    bool kernel_ok = has_kernel && verify_native_kernel_image(&kernel, &kernel_metadata);
    bool romfile_ok = has_romfile && verify_os_payload_partition(&romfile, "ROMF", NULL, NULL, NULL);
    bool ramdisk_ok = !has_ramdisk || verify_os_payload_partition(&ramdisk, "RAMD", NULL, NULL, NULL);
    bool rootfs_data_ok = has_rootfs_data;
    bool rootfs_ok = false;

    if (has_rootfs) {
        uint8_t probe[4];
        rootfs_ok = bootloader_flash_read(rootfs.pos.offset, probe, sizeof(probe), true) == ESP_OK;
        post_print_status("RootFS read", rootfs_ok);
        if (rootfs_ok) POSTM("RootFS CRC32: N/A (raw)");
    } else {
        post_print_status("RootFS", false);
    }
    if (kernel_ok) {
        ets_printf("[POST] Kernel: len=0x%x entry=0x%08x segs=%u\r\n",
                   (unsigned)kernel_metadata.image_len, (unsigned)kernel_metadata.image.entry_addr,
                   (unsigned)kernel_metadata.image.segment_count);
    }
    post_print_status("Kernel image", kernel_ok);
    post_print_status("ROMF CRC32", romfile_ok);
    if (has_ramdisk) post_print_status("RAMD CRC32", ramdisk_ok);
    post_print_status("rootfs_data", rootfs_data_ok);
    ok = ok && kernel_ok && romfile_ok && ramdisk_ok && rootfs_ok && rootfs_data_ok;
    uart_puts(ok ? "[POST] Result: PASS\r\n" : "[POST] Result: FAIL\r\n");
    return ok;
}

/* ---- Device tree (DTB in the "dtb" MTD) ---------------------------------------
 * Optional. A missing, invalid or display-less DTB never blocks boot: the display
 * features (display initialization) simply stays off. The kernel parses the full DTB itself. */
static bldr_dt_t g_dt;
static bool g_dtb_valid;
static uint32_t g_dtb_offset;
static bool g_display_cleared;

static void dt_load(void)
{
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    vcs_partition_info_t dtb;
    memset(&g_dt, 0, sizeof(g_dt));
    g_dtb_valid = false;
    if (!load_partition_table(&table, &count) || !find_mtd(table, count, "dtb", &dtb) ||
        dtb.kind != BLDR_VCS_KIND_BLOB || dtb.pos.size == 0U ||
        (uint64_t)dtb.pos.offset + dtb.pos.size > g_rom_flashchip.chip_size) return;
    const void *m = bootloader_mmap(dtb.pos.offset, dtb.pos.size);
    if (m == NULL) return;
    const int rc = bldr_dt_parse(m, dtb.pos.size, &g_dt);
    bootloader_munmap(m);
    if (rc != BLDR_DT_OK) {
        memset(&g_dt, 0, sizeof(g_dt));   /* silent: a missing/invalid DTB only means "no display" */
        return;
    }
    g_dtb_valid = true;
    g_dtb_offset = dtb.pos.offset;
}

/* Prints nothing unless a supported display was actually initialized: a missing, invalid or
 * display-less DTB is a normal configuration and is deliberately not reported. */
static void dt_print_summary(void)
{
    if (!g_dtb_valid || !g_display_cleared) return;
    const bldr_dt_display_t *d = &g_dt.display;
    ets_printf("Display: ST7735 %ux%u rot=%u, cleared black\r\n", (unsigned)d->width,
               (unsigned)d->height, (unsigned)d->rotation);
}

/* Write the NBIF v3 boot-info block into the reserved first 4 KiB of PSRAM. Called
 * on every kernel hand-off, so the kernel can always find the MTD map and the DTB.
 * `h` (NPIM header at image_addr) is NULL for the flash boot path. */
static bldr_bootinfo_t *bootinfo_publish(const vcs_partition_info_t *table, int count, uint32_t src,
                                         uint32_t image_addr, const bldr_npim_hdr_t *h)
{
    uint8_t *res = (uint8_t *)bldr_psram_reserved();
    const size_t total = sizeof(bldr_bootinfo_t) + (size_t)count * BLDR_PTB_ENTRY_SIZE;
    if (res == NULL || count < 0 || total > BLDR_PSRAM_RESERVED_BYTES) return NULL;
    memset(res, 0, BLDR_PSRAM_RESERVED_BYTES);
    bldr_bootinfo_t *bi = (bldr_bootinfo_t *)res;
    memcpy(bi->magic, BLDR_BOOTINFO_MAGIC, 4);
    bi->version = (uint16_t)BLDR_BOOTINFO_VERSION;
    bi->mtd_count = (uint16_t)count;
    bi->psram_base = bldr_psram_user_base() - BLDR_PSRAM_RESERVED_BYTES;
    bi->psram_size = bldr_psram_size();
    bi->flash_size = g_rom_flashchip.chip_size;
    bi->boot_flags = src;
    bi->uart_baud = g_uart_baud;   /* console speed in force at hand-off (the `baud` command may have changed it) */
    if (h != NULL) {
        bi->image_addr = image_addr;
        bi->image_size = h->image_size;
        bi->vbase = h->vbase;
        if (h->initramfs_off != 0U) {
            bi->initramfs_addr = image_addr + h->initramfs_off;
            bi->initramfs_size = h->initramfs_size;
        }
    }
    if (g_dtb_valid) {
        bi->boot_flags |= BLDR_BI_DTB_VALID;
        bi->dtb_offset = g_dtb_offset;
        bi->dtb_size = g_dt.totalsize;
    }
    if (g_display_cleared) bi->boot_flags |= BLDR_BI_DISPLAY_CLEARED;
    for (int i = 0; i < count; ++i) {
        ptb_entry_t e = {0};
        memcpy(e.label, table[i].label, sizeof(e.label));
        e.offset = table[i].pos.offset;
        e.size = table[i].pos.size;
        e.vaddr = table[i].vaddr;
        e.kind = (uint16_t)table[i].kind;
        e.flags = (uint16_t)table[i].flags;
        memcpy(res + sizeof(*bi) + (size_t)i * BLDR_PTB_ENTRY_SIZE, &e, sizeof(e));
    }
    bi->crc32 = 0U;
    bi->crc32 = crc32_ieee_update(0U, res, total);
    __asm__ __volatile__("memw" ::: "memory");
    Cache_WriteBack_All();   /* PSRAM is cached: push the block out before the cache is reconfigured */
    return bi;
}

/* This uses ESP-IDF's own image-loader handoff, but points it at the kernel
 * partition selected by partition.vcs rather than the standard factory app.
 * The ESP image loader copies only IRAM/DRAM segments and maps IROM/DROM via MMU;
 * ramdisk is intentionally NOT loaded by the bootloader. */
static bool boot_esp_os_kernel(const char *target)
{
    const vcs_partition_info_t *table = NULL;
    int count = 0;
    vcs_partition_info_t kernel;
    esp_image_metadata_t metadata;
    if (!load_partition_table(&table, &count) ||
        !find_mtd(table, count, target, &kernel) ||
        !verify_native_kernel_image(&kernel, &metadata)) {
        BOOT("kernel/ptb invalid; not booting");
        return false;
    }
    if (bootinfo_publish(table, count, BLDR_BI_SRC_FLASH, 0U, NULL) == NULL) {
        BOOT("boot-info (NBIF) not written (PSRAM unavailable?); not booting");
        return false;
    }
    bootloader_state_t os_state = {0};
    os_state.factory = kernel.pos;
    os_state.app_count = 1U;
    ets_printf("[BOOT] Loading kernel @0x%08x len=0x%x entry=0x%08x\r\n",
               (unsigned)kernel.pos.offset, (unsigned)metadata.image_len,
               (unsigned)metadata.image.entry_addr);
    BOOT("IDF loader maps XIP; ramdisk remains on flash");
    bootloader_utility_load_boot_image(&os_state, FACTORY_INDEX);
    return false; /* The ESP-IDF bootloader API is noreturn. */
}

static bool check_flash_encryption_alignment(const vcs_partition_info_t *p, uint32_t addr, uint32_t len)
{
    if (partition_writes_encrypted(p) && (((addr | len) & 15U) != 0U)) {
        ERR("encrypted write needs align16");
        return false;
    }
    return true;
}

/* Read back what was just programmed and compare (plain, unencrypted writes only:
 * encrypted ROM writes transform the staging buffer in place). Catches writes
 * to non-erased flash, where bits can only go 1->0. */
static bool flash_readback_ok(uint32_t addr, const uint8_t *expect, uint32_t n)
{
    return bootloader_flash_read(addr, g_cmp_buffer, n, false) == ESP_OK &&
           memcmp(g_cmp_buffer, expect, n) == 0;
}

static bool flash_write_from_ram(uint32_t flash_addr, uint32_t ram_addr, uint32_t len)
{
    vcs_partition_info_t p;
    if (len == 0 || (flash_addr & 3U) != 0U || (ram_addr & 3U) != 0U || (len & 3U) != 0U) {
        ERR("addr/psram/len must be align4, len>0");
        return false;
    }
    if (!bldr_psram_range_valid(ram_addr, len)) {
        ERR("source not in PSRAM");
        return false;
    }
    if (!find_partition_for_range(flash_addr, len, &p)) {
        ERR("dest not in writable partition");
        return false;
    }
    if (!check_flash_encryption_alignment(&p, flash_addr, len)) return false;
    if (!consume_unlock_for_range(flash_addr, len, &p)) return false;

    bool encrypt = partition_writes_encrypted(&p);
    uint32_t done = 0;
    while (done < len) {
        uint32_t n = len - done;
        if (n > BLDR_FLASH_IO_CHUNK) n = BLDR_FLASH_IO_CHUNK;
        if (encrypt) n &= ~15U;
        if (n == 0) return false;
        /* Copy from validated PSRAM into aligned private scratch. Encrypted
         * ROM writes may transform this scratch buffer in place. */
        if (!bldr_psram_read(ram_addr + done, g_io_buffer, n)) {
            ERR("PSRAM read failed");
            return false;
        }
        esp_err_t err = bootloader_flash_write(flash_addr + done, g_io_buffer, n, encrypt);
        if (err != ESP_OK) {
            ets_printf("ERR: flash write failed @0x%08x (0x%x)\r\n",
                       (unsigned)(flash_addr + done), (unsigned)err);
            return false;
        }
        if (!encrypt && !flash_readback_ok(flash_addr + done, g_io_buffer, n)) {
            ets_printf("ERR: verify failed @0x%08x (erase first?)\r\n", (unsigned)(flash_addr + done));
            return false;
        }
        done += n;
        feed_watchdog();
    }
    ets_printf("OK: wrote+verified %u bytes @0x%08x\r\n",
               (unsigned)len, (unsigned)flash_addr);
    return true;
}

static bool flash_erase_blocks(uint32_t addr, uint32_t blocks)
{
    uint64_t len64 = (uint64_t)blocks * BLDR_SECTOR_SIZE;
    if (blocks == 0 || len64 > UINT32_MAX || (addr & (BLDR_SECTOR_SIZE - 1U)) != 0U) {
        ERR("need 4K-aligned addr, count>0");
        return false;
    }
    uint32_t len = (uint32_t)len64;
    if (!consume_unlock_for_range(addr, len, NULL)) return false;
    uint32_t n = 0;
    while (n < blocks) {
        esp_err_t err = bootloader_flash_erase_sector((addr / BLDR_SECTOR_SIZE) + n);
        if (err != ESP_OK) {
            ets_printf("ERR: erase failed @0x%08x (0x%x)\r\n",
                       (unsigned)(addr + n * BLDR_SECTOR_SIZE), (unsigned)err);
            return false;
        }
        ++n;
        feed_watchdog();
    }
    ets_printf("OK: erased %u sectors @0x%08x (%u bytes)\r\n",
               (unsigned)blocks, (unsigned)addr, (unsigned)len);
    return true;
}

static bool flash_write_packet(uint32_t addr, uint32_t packet_offset, uint32_t len,
                               const vcs_partition_info_t *partition, uint32_t *last_erased_sector)
{
    uint32_t done = 0;
    bool encrypt = partition_writes_encrypted(partition);
    if (((addr | len | packet_offset) & 3U) != 0U ||
        (uint64_t)packet_offset + len > BLDR_XMODEM_PACKET_MAX) return false;
    if (!check_flash_encryption_alignment(partition, addr, len)) return false;
    while (done < len) {
        uint32_t current = addr + done;
        uint32_t sector = current / BLDR_SECTOR_SIZE;
        uint32_t in_sector = current & (BLDR_SECTOR_SIZE - 1U);
        uint32_t n = len - done;
        if (n > BLDR_SECTOR_SIZE - in_sector) n = BLDR_SECTOR_SIZE - in_sector;
        if (sector != *last_erased_sector) {
            esp_err_t er = bootloader_flash_erase_sector(sector);
            if (er != ESP_OK) return false;
            *last_erased_sector = sector;
            feed_watchdog();
        }
        uint32_t pos = 0;
        while (pos < n) {
            uint32_t wn = n - pos;
            if (wn > BLDR_FLASH_IO_CHUNK) wn = BLDR_FLASH_IO_CHUNK;
            if (encrypt) wn &= ~15U;
            if (wn == 0U || !copy_xmodem_packet_to_io(packet_offset + done + pos, wn)) return false;
            esp_err_t wr = bootloader_flash_write(current + pos, g_io_buffer, wn, encrypt);
            if (wr != ESP_OK || (!encrypt && !flash_readback_ok(current + pos, g_io_buffer, wn))) {
                return false;
            }
            pos += wn;
            feed_watchdog();
        }
        done += n;
    }
    return true;
}

static uint32_t read_cpu_ccount(void)
{
    uint32_t value;
    __asm__ __volatile__("rsr.ccount %0" : "=a"(value));
    return value;
}

static uint32_t xmodem_elapsed_ms(uint32_t start_ccount, uint32_t cpu_mhz)
{
    uint32_t cycles_per_ms = (cpu_mhz == 0U ? 80U : cpu_mhz) * 1000U;
    return (uint32_t)(read_cpu_ccount() - start_ccount) / cycles_per_ms;
}

static bool xmodem_read_byte_until(uint8_t *out, uint32_t start_ccount, uint32_t cpu_mhz,
                                   uint32_t *last_feed_ms)
{
    while (xmodem_elapsed_ms(start_ccount, cpu_mhz) < BLDR_XMODEM_SESSION_TIMEOUT_MS) {
        if (uart_rx_one_char(out) == 0) return true;
        uint32_t elapsed = xmodem_elapsed_ms(start_ccount, cpu_mhz);
        if (last_feed_ms != NULL && elapsed - *last_feed_ms >= 1000U) {
            feed_watchdog();
            *last_feed_ms = elapsed;
        }
        /* Poll frequently so high-baud bursts are not throttled by 1 ms sleeps. */
        ets_delay_us(10U);
    }
    return false;
}

static uint32_t xmodem_padding_overlap(uint32_t packet_len, uint32_t payload_len,
                                       uint32_t trailing_pad)
{
    uint32_t outside = packet_len > payload_len ? packet_len - payload_len : 0U;
    if (trailing_pad <= outside) return 0U;
    uint32_t overlap = trailing_pad - outside;
    return overlap > payload_len ? payload_len : overlap;
}

static void xmodem_trim_final_padding(uint32_t *received, uint32_t packet_len,
                                     uint32_t payload_len, uint32_t trailing_pad)
{
    if (received == NULL || packet_len == 0U || payload_len == 0U) return;
    uint32_t trim = xmodem_padding_overlap(packet_len, payload_len, trailing_pad);
    if (trim > *received) trim = *received;
    *received -= trim;
}

static void xmodem_report_received(uint32_t received)
{
    ets_printf("Received len=%X\r\n", (unsigned)received);
}

static bool xmodem_receive(uint32_t ram_addr, uint32_t max_len,
                           bool to_flash, uint32_t flash_addr,
                           const vcs_partition_info_t *flash_partition,
                           uint32_t *out_bytes)
{
    uint32_t received = 0U;
    uint32_t last_packet_len = 0U;
    uint32_t last_packet_payload = 0U;
    uint32_t last_packet_trailing_pad = 0U;
    uint32_t start_ccount;
    uint32_t monitor_start_ms = g_monitor_elapsed_ms;
    uint32_t last_watchdog_feed_ms = 0U;
    uint32_t cpu_mhz;
    uint32_t next_c_ms = 0U;
    uint8_t expected_block = 1U;
    uint32_t last_erased_sector = UINT32_MAX;
    bool started = false;
    bool success = false;

    if (out_bytes != NULL) *out_bytes = 0U;
    if (!to_flash && (max_len == 0U || !bldr_psram_range_valid(ram_addr, max_len))) {
        ERR("XMODEM target not in PSRAM");
        return false;
    }
    if (to_flash && (max_len == 0U || (max_len & (BLDR_SECTOR_SIZE - 1U)) != 0U || flash_partition == NULL ||
                     !partition_is_mutable(flash_partition) ||
                     (uint64_t)flash_addr + max_len > (uint64_t)flash_partition->pos.offset + flash_partition->pos.size ||
                     (flash_addr & (BLDR_SECTOR_SIZE - 1U)) != 0U)) {
        ERR("bad XMODEM flash target");
        return false;
    }
    rtc_cpu_freq_config_t clock_cfg;
    rtc_clk_cpu_freq_get_config(&clock_cfg);
    cpu_mhz = clock_cfg.freq_mhz;
    start_ccount = read_cpu_ccount();
    const uint32_t session_start_ccount = start_ccount;   /* start_ccount is re-armed per packet (idle timeout) */

    for (;;) {
        uint8_t c = 0U;
        if (xmodem_elapsed_ms(start_ccount, cpu_mhz) >= BLDR_XMODEM_SESSION_TIMEOUT_MS) break;
        if (uart_rx_one_char(&c) != 0) {
            uint32_t elapsed = xmodem_elapsed_ms(start_ccount, cpu_mhz);
            if (!started && elapsed >= next_c_ms) {
                uart_putc((char)XMODEM_CRC_REQ);
                next_c_ms += BLDR_XMODEM_C_INTERVAL_MS;
            }
            if (elapsed - last_watchdog_feed_ms >= 1000U) {
                feed_watchdog();
                last_watchdog_feed_ms = elapsed;
            }
            /* Keep polling tight so the first high-baud packet does not overflow UART FIFO. */
            ets_delay_us(10U);
            continue;
        }
        if (c == XMODEM_EOT) {
            uart_putc((char)XMODEM_ACK);
            started = true; /* This session has started; do not resume sending CRC requests. */
            /* XMODEM has no file-length field. Trim conventional 0x1A padding from the final block,
             * including padding that overlaps a too-large requested length. */
            xmodem_trim_final_padding(&received, last_packet_len, last_packet_payload, last_packet_trailing_pad);
            last_packet_len = 0U; /* An EOT retransmission must not trim the same packet twice. */
            last_packet_payload = 0U;
            last_packet_trailing_pad = 0U;
            if (received == max_len) {
                success = true;
                break;
            }
            /* The sender has ended, but the caller may have specified a length that's too large.
             * Keep waiting (without sending more 'C') until the 15-second idle deadline. */
            continue;
        }
        if (c == XMODEM_CAN) {
            (void)uart_rx_one_char(&c); /* Consume a paired CAN if it is already queued. */
            break;
        }
        uint32_t packet_len;
        if (c == XMODEM_SOH) packet_len = 128U;
        else if (c == XMODEM_STX) packet_len = 1024U;
        else {
            if (started) uart_putc((char)XMODEM_NAK);
            continue;
        }
        started = true; /* Stop emitting 'C' as soon as a sender starts a data packet. */

        uint8_t block = 0U, block_inv = 0U, crc_hi = 0U, crc_lo = 0U;
        bool got = xmodem_read_byte_until(&block, start_ccount, cpu_mhz, &last_watchdog_feed_ms) &&
                   xmodem_read_byte_until(&block_inv, start_ccount, cpu_mhz, &last_watchdog_feed_ms);
        uint32_t payload_len = received < max_len ? max_len - received : 0U;
        if (payload_len > packet_len) payload_len = packet_len;
        uint16_t packet_crc = 0U;
        uint32_t trailing_pad = 0U;
        for (uint32_t i = 0U; got && i < packet_len; i += 4U) {
            uint8_t quartet[4];
            for (uint32_t j = 0U; got && j < 4U; ++j)
                got = xmodem_read_byte_until(&quartet[j], start_ccount, cpu_mhz, &last_watchdog_feed_ms);
            if (got) {
                packet_crc = crc16_xmodem_update(packet_crc, quartet, sizeof(quartet));
                for (uint32_t j = 0U; j < 4U; ++j) {
                    if (quartet[j] == 0x1AU) ++trailing_pad;
                    else trailing_pad = 0U;
                    /* Stage every packet in private IRAM. Nothing is committed
                     * to PSRAM or flash until header/sequence/CRC are accepted. */
                    g_xmodem_packet[i + j] = quartet[j];
                }
            }
        }
        if (got) got = xmodem_read_byte_until(&crc_hi, start_ccount, cpu_mhz, &last_watchdog_feed_ms) &&
                       xmodem_read_byte_until(&crc_lo, start_ccount, cpu_mhz, &last_watchdog_feed_ms);
        if (!got) break;
        uint16_t want_crc = (uint16_t)(((uint16_t)crc_hi << 8) | crc_lo);
        if ((uint8_t)(block + block_inv) != 0xFFU || packet_crc != want_crc) {
            uart_putc((char)XMODEM_NAK);
            continue;
        }
        /* Idle timeout: every CRC-valid packet restarts the 15-second window. */
        start_ccount = read_cpu_ccount();
        last_watchdog_feed_ms = 0U;
        if (block == (uint8_t)(expected_block - 1U)) {
            uart_putc((char)XMODEM_ACK);
            continue;
        }
        if (block != expected_block) {
            uart_putc((char)XMODEM_NAK);
            continue;
        }
        if (received >= max_len) {
            uart_putc((char)XMODEM_CAN);
            uart_putc((char)XMODEM_CAN);
            break;
        }
        bool stored;
        if (to_flash) {
            /* Flash transfers stage a packet in private IRAM, then write only CRC-accepted bytes.
             * payload_len may be shorter than the received block at the configured range boundary. */
            stored = payload_len != 0U &&
                flash_write_packet(flash_addr + received, 0U, payload_len,
                                   flash_partition, &last_erased_sector);
        } else {
            /* Commit only CRC-validated bytes to the validated PSRAM range. */
            stored = payload_len != 0U &&
                bldr_psram_write(ram_addr + received, g_xmodem_packet, payload_len);
        }
        if (!stored) {
            uart_putc((char)XMODEM_CAN);
            uart_putc((char)XMODEM_CAN);
            break;
        }
        received += payload_len;
        last_packet_len = packet_len;
        last_packet_payload = payload_len;
        last_packet_trailing_pad = trailing_pad;
        ++expected_block;
        uart_putc((char)XMODEM_ACK);
        feed_watchdog();
        if (received == max_len) {
            /* Give the sender up to 250 ms to signal EOT so final-block 0x1A padding can be
             * removed when the requested length accidentally cuts into padding. */
            uint8_t ending = 0U;
            bool saw_eot = false;
            uint32_t complete_wait_start = xmodem_elapsed_ms(start_ccount, cpu_mhz);
            while (xmodem_elapsed_ms(start_ccount, cpu_mhz) < BLDR_XMODEM_SESSION_TIMEOUT_MS &&
                   xmodem_elapsed_ms(start_ccount, cpu_mhz) - complete_wait_start < 250U) {
                if (uart_rx_one_char(&ending) == 0) {
                    if (ending == XMODEM_EOT) {
                        saw_eot = true;
                        uart_putc((char)XMODEM_ACK);
                        xmodem_trim_final_padding(&received, last_packet_len, last_packet_payload, last_packet_trailing_pad);
                        last_packet_len = 0U;
                        last_packet_payload = 0U;
                        last_packet_trailing_pad = 0U;
                        success = (received == max_len);
                    }
                    break;
                }
                ets_delay_us(10U);
            }
            if (success) break;
            if (saw_eot) {
                /* EOT was valid but the accepted payload was shorter than expected after padding
                 * removal. Do not report success; continue waiting to the original 15s deadline. */
                continue;
            }
            /* No EOT arrived, but max_len accepted bytes were received. */
            success = true;
            break;
        }
    }

    if (!success && received == max_len && last_packet_len > last_packet_payload) {
        /* If the expected size cut through the last XMODEM block, account for visible 0x1A padding on timeout. */
        xmodem_trim_final_padding(&received, last_packet_len, last_packet_payload, last_packet_trailing_pad);
        success = (received == max_len);
    }
    g_monitor_elapsed_ms = monitor_start_ms + xmodem_elapsed_ms(session_start_ccount, cpu_mhz);
    if (out_bytes != NULL) *out_bytes = received;
    xmodem_report_received(received);
    return success;
}

static bool verify_image(uint32_t addr, uint32_t len)
{
    if (len == 0 || (addr & 0xFFFU) != 0U ||
        (uint64_t)addr + len > g_rom_flashchip.chip_size || protected_flash_range(addr, len)) {
        ERR("bad image range (4K-aligned, outside boot/PT)");
        return false;
    }
    esp_partition_pos_t pos = { .offset = addr, .size = len };
    esp_image_metadata_t metadata;
    esp_err_t err = esp_image_verify(ESP_IMAGE_VERIFY, &pos, &metadata);
    if (err != ESP_OK) {
        ets_printf("VERIFY FAIL: 0x%x\r\n", (unsigned)err);
        return false;
    }
    ets_printf("VERIFY OK: %u bytes, %u segs, entry=0x%08x\r\n",
               (unsigned)metadata.image_len, (unsigned)metadata.image.segment_count,
               (unsigned)metadata.image.entry_addr);
    return true;
}

static void put_hex(uint32_t v, unsigned digits)
{
    while (digits-- > 0U) uart_putc("0123456789abcdef"[(v >> (digits * 4U)) & 0xFU]);
}



/* jump <psram_addr>: header-only check (no CRC), XIP via IBUS, boot-info in a2. */
static void cmd_jump(uint32_t addr)
{
    bldr_npim_hdr_t h;
    const uint32_t base = bldr_psram_user_base();
    if (!bldr_psram_ready() || !bldr_psram_range_valid(addr, BLDR_NPIM_HDR_SIZE) ||
        !bldr_psram_read(addr, &h, sizeof(h))) { ERR("bad psram addr"); return; }
    int rc = bldr_npim_check(&h, addr, base, bldr_psram_end() - base, 0U, bldr_psram_first_data_entry());
    if (rc != BLDR_NPIM_OK) { ets_printf("ERR: NPIM check %d\r\n", rc); return; }

    const vcs_partition_info_t *table = NULL;
    int count = 0;
    if (!load_partition_table(&table, &count)) { ERR("ptb invalid"); return; }

    bldr_bootinfo_t *bi = bootinfo_publish(table, count, BLDR_BI_SRC_PSRAM, addr, &h);
    if (bi == NULL) { ERR("no boot-info"); return; }
    ets_printf("[JUMP] 0x%08x -> vbase=0x%08x entry=0x%08x (no CRC)\r\n",
               (unsigned)addr, (unsigned)h.vbase, (unsigned)h.entry);
    uart_tx_wait_idle(0);
    if (!bldr_psram_xip_map(h.vbase, addr, h.image_size)) { ERR("xip map failed"); return; }
    ((void (*)(uint32_t))(uintptr_t)h.entry)((uint32_t)(uintptr_t)bi);
    ERR("image returned");
}

static void print_status(void)
{
    rtc_cpu_freq_config_t cfg;
    rtc_clk_cpu_freq_get_config(&cfg);
    ets_printf("CPU: %u MHz\r\nUART: %u baud\r\n", (unsigned)cfg.freq_mhz, (unsigned)g_uart_baud);
    if (g_rom_flashchip.chip_size != 0U) ets_printf("Flash: %u bytes\r\n", (unsigned)g_rom_flashchip.chip_size);
    else uart_puts("Flash: ERROR zero capacity\r\n");
    if (bldr_psram_ready()) {
        ets_printf("PSRAM: %u bytes, user 0x%08x..0x%08x (end excl.)\r\n",
                   (unsigned)bldr_psram_size(), (unsigned)bldr_psram_user_base(),
                   (unsigned)bldr_psram_end());
    } else {
        uart_puts("PSRAM: UNAVAILABLE (RAM commands disabled)\r\n");
    }
    dt_print_summary();
}

/* `version`: build identity, watermark and the legal notices that must stay visible to the user
 * (GPLv3 interactive notice for the project code, Apache-2.0 attribution for the Espressif base). */
static void print_version(void)
{
    ets_printf("BOOTLOADER console v%s\r\n", BLDR_VERSION);
    ets_printf("  %s\r\n", BLDR_WATERMARK);
    uart_puts("Target   : ESP32-S3 (N16R8), ESP-IDF v4.4.7 second-stage bootloader + ESP32-OS hook\r\n");
    ets_printf("Boot-info: NBIF v%u, MTD table NPTB v%u\r\n", (unsigned)BLDR_BOOTINFO_VERSION,
               (unsigned)BLDR_VCS_VERSION);
    ets_printf("Hardware : flash %u MiB, UART0 %u baud, ", (unsigned)(g_rom_flashchip.chip_size >> 20),
               (unsigned)g_uart_baud);
    if (bldr_psram_ready()) ets_printf("PSRAM %u MiB\r\n", (unsigned)(bldr_psram_size() >> 20));
    else uart_puts("PSRAM unavailable\r\n");
    uart_puts("\r\n"
              "Copyright (C) 2026 Wiring-ChaosVN by Nick\r\n"
              "License  : GNU GPL v3.0 only (GPL-3.0-only), project-authored code.\r\n"
              "  This program comes with ABSOLUTELY NO WARRANTY. It is free software and\r\n"
              "  you may redistribute it under the terms of the GPL v3.0:\r\n"
              "  https://www.gnu.org/licenses/gpl-3.0.html (full text: file LICENSE)\r\n"
              "\r\n"
              "Upstream : Espressif ESP-IDF v4.4.7 second-stage bootloader and bootloader_support.\r\n"
              "  Copyright (C) 2015-2022 Espressif Systems; Apache License 2.0.\r\n"
              "  This firmware is the original Espressif bootloader plus a hook/monitor:\r\n"
              "  Espressif code is NOT relicensed and keeps its own notices.\r\n"
              "  https://github.com/espressif/esp-idf/tree/v4.4.7\r\n"
              "  Other third-party notices: THIRD_PARTY_NOTICES.md, LICENSES/Apache-2.0.txt\r\n");
}

static void print_help(void)
{
    ets_printf("BOOTLOADER console v%s (help <cmd> | <cmd> -h)\r\n", BLDR_VERSION);
    for (const char *p = k_usage; *p != '\0';) {
        const char *use = p + strlen(p) + 1;
        uart_puts("  ");
        uart_puts(use);
        uart_puts("\r\n");
        p = use + strlen(use) + 1;
    }
}

static bool read_line(char *line, size_t cap)
{
    size_t len = 0;
    uint8_t esc = 0U; /* 1: saw ESC, 2: inside ESC [ ... sequence */
    while (g_monitor_elapsed_ms < BLDR_MONITOR_MAX_MS) {
        uint8_t c = 0;
        if (uart_rx_one_char(&c) == 0) {
            if (esc != 0U) { /* swallow arrow/function-key sequences instead of discarding the line */
                if (esc == 1U) esc = (c == '[' || c == 'O') ? 2U : 0U;
                else if (c >= 0x40U && c <= 0x7EU) esc = 0U;
                continue;
            }
            if (c == 0x1BU) { esc = 1U; continue; }
            if (g_skip_lf) {
                g_skip_lf = false;
                if (c == '\n') continue;
            }
            if (c == '\r' || c == '\n') {
                if (c == '\r') g_skip_lf = true;
                uart_puts("\r\n");
                line[len] = '\0';
                return true;
            }
            if (c == 0x03U) {
                uart_puts("^C\r\nLeaving monitor.\r\n");
                return false;
            }
            if (c == 0x08U || c == 0x7FU) {
                if (len > 0) { --len; uart_puts("\b \b"); }
                continue;
            }
            if (c < 0x20U || c > 0x7EU) {
                uart_puts("\r\n");
                ERR("non-ASCII; line discarded");
                len = 0;
                prompt();
                continue;
            }
            if (len + 1U >= cap) {
                uart_puts("\r\n");
                ERR("line too long; discarded");
                len = 0;
                prompt();
                continue;
            }
            line[len++] = (char)c;
            uart_putc((char)c);
        }
        delay_1ms();
    }
    uart_puts("\r\nMonitor timeout; retrying boot\r\n");
    return false;
}

static bool process_command(int argc, char **argv)
{
    uint32_t a = 0, b = 0, c = 0;
    if (argc == 0) return true;
    if (command_has_help(argc, argv)) { usage(argv[0]); return true; }
    const char *cmd = argv[0];

    if (strcmp(cmd, "help") == 0 || strcmp(cmd, "?") == 0) {
        if (argc == 1) print_help();
        else if (argc == 2) usage(argv[1]);
        else usage("help");
    } else if (strcmp(cmd, "version") == 0) {
        print_version();
    } else if (strcmp(cmd, "partitions") == 0 || strcmp(cmd, "mtd") == 0) {
        print_partition_table();
    } else if (strcmp(cmd, "go") == 0) {
        if (argc > 2) usage("go");
        else if (post_self_test()) {
            if (!boot_esp_os_kernel(argc == 2 ? argv[1] : "kernel")) BOOT("kernel handoff failed");
        } else {
            BOOT("POST failed");
        }
    } else if (strcmp(cmd, "reboot") == 0) {
        uart_puts("Rebooting...\r\n");
        ets_delay_us(20000);
        software_reset();
        for (;;) { }
    } else if (strcmp(cmd, "unlock") == 0) {
        /* A new unlock attempt always replaces/disarms any previous token. */
        g_unlock_armed = false;
        g_unlock_label[0] = '\0';
        if (argc != 2) { usage("unlock"); return true; }
        vcs_partition_info_t p;
        if (!find_partition_by_label(argv[1], &p)) { ERR("no such partition/table"); return true; }
        if (!partition_is_mutable(&p)) { ERR("partition is read-only"); return true; }
        partition_label(&p, g_unlock_label); /* canonical label, so "mtd3" and "rootfs" are the same target */
        g_unlock_deadline_ms = g_monitor_elapsed_ms + 30000U;
        g_unlock_armed = true;
        ets_printf("OK: '%s' armed (1 op, 30 s)\r\n", g_unlock_label);
    } else if (strcmp(cmd, "erase") == 0) {
        if (argc == 2) {
            vcs_partition_info_t p;
            if (!find_partition_by_label(argv[1], &p)) { ERR("no such partition/table"); return true; }
            if (!partition_is_mutable(&p)) { ERR("partition is read-only"); return true; }
            if (p.pos.size == 0U || (p.pos.offset & (BLDR_SECTOR_SIZE - 1U)) != 0U ||
                (p.pos.size & (BLDR_SECTOR_SIZE - 1U)) != 0U) {
                ERR("not sector aligned"); return true;
            }
            ets_printf("WARNING: erasing MTD partition '%s' (%u bytes)\r\n",
                       argv[1], (unsigned)p.pos.size);
            (void)flash_erase_blocks(p.pos.offset, p.pos.size / BLDR_SECTOR_SIZE);
        } else if (argc == 3 && parse_u32(argv[1], &a) && parse_u32(argv[2], &b)) {
            (void)flash_erase_blocks(a, b);
        } else {
            usage("erase");
        }
    } else if (strcmp(cmd, "flash") == 0) {
        if (argc != 4 || !parse_u32(argv[1], &a) || !parse_u32(argv[2], &b) || !parse_u32(argv[3], &c)) {
            usage("flash"); return true;
        }
        (void)flash_write_from_ram(a, b, c);
    } else if (strcmp(cmd, "dump") == 0) {
        if (argc != 4 || !parse_u32(argv[1], &a) || !parse_u32(argv[2], &b) || !parse_u32(argv[3], &c)) {
            usage("dump"); return true;
        }
        if (b == 0 || (a & 3U) != 0U || (b & 3U) != 0U || (c & 3U) != 0U ||
            (uint64_t)a + b > g_rom_flashchip.chip_size || !bldr_psram_range_valid(c, b)) {
            ERR("bad range (align4; flash in chip; dest in PSRAM)"); return true;
        }
        uint32_t done = 0;
        while (done < b) {
            uint32_t n = b - done;
            if (n > BLDR_FLASH_IO_CHUNK) n = BLDR_FLASH_IO_CHUNK;
            if (bootloader_flash_read(a + done, g_io_buffer, n, true) != ESP_OK ||
                !bldr_psram_write(c + done, g_io_buffer, n)) {
                ERR("dump failed"); return true;
            }
            done += n; feed_watchdog();
        }
        ets_printf("OK: copied %u bytes flash 0x%08x -> PSRAM 0x%08x\r\n", (unsigned)b, (unsigned)a, (unsigned)c);
    } else if (strcmp(cmd, "verify") == 0) {
        if (argc == 2) {
            vcs_partition_info_t p;
            if (!find_partition_by_label(argv[1], &p)) { ERR("no such partition/table"); return true; }
            if (p.kind != BLDR_VCS_KIND_ESP_IMAGE) { ERR("not an esp-image; use verify <addr> <len>"); return true; }
            (void)verify_image(p.pos.offset, p.pos.size);
        } else if (argc == 3 && parse_u32(argv[1], &a) && parse_u32(argv[2], &b)) {
            (void)verify_image(a, b);
        } else {
            usage("verify");
        }
    } else if (strcmp(cmd, "crc32") == 0) {
        vcs_partition_info_t p;
        uint32_t computed = 0U, expected = 0U, payload_size = 0U;
        if (argc != 2) {
            usage("crc32");
            return true;
        }
        if (!find_partition_by_label(argv[1], &p)) {
            ERR("no such partition/table");
            return true;
        }
        if (p.kind == BLDR_VCS_KIND_ESP_IMAGE) {
            esp_image_metadata_t metadata;
            if (!verify_native_kernel_image(&p, &metadata) ||
                !crc32_flash_range(p.pos.offset, metadata.image_len, &computed)) {
                ERR("image verify/CRC failed");
            } else {
                ets_printf("Kernel PASS: CRC32=0x%08x len=0x%x entry=0x%08x\r\n",
                           (unsigned)computed, (unsigned)metadata.image_len,
                           (unsigned)metadata.image.entry_addr);
            }
        } else if (p.kind == BLDR_VCS_KIND_BLOB) {
            char name[17];
            partition_label(&p, name);
            bool valid = verify_os_payload_partition(&p, strcmp(name, "romfile") == 0 ? "ROMF" : "RAMD",
                                                     &computed, &expected, &payload_size);
            if (payload_size != 0U) ets_printf("CRC32: calc=0x%08x want=0x%08x len=0x%x %s\r\n", (unsigned)computed, (unsigned)expected, (unsigned)payload_size, valid ? "PASS" : "FAIL");
            else ERR("bad blob header");
        } else {
            ERR("crc32: esp-image or blob only");
        }
    } else if (strcmp(cmd, "xmdm") == 0) {
        uint32_t n = 0;
        if (argc == 3 && parse_hex_u32(argv[1], &a) && parse_hex_u32(argv[2], &b)) {
            (void)xmodem_receive(a, b, false, 0, NULL, &n);
        } else if (argc == 5 && strcmp(argv[1], "flash") == 0 && parse_hex_u32(argv[3], &b) && parse_hex_u32(argv[4], &c)) {
            vcs_partition_info_t p;
            if (!find_partition_by_label(argv[2], &p)) { ERR("no such partition/table"); return true; }
            if (!partition_is_mutable(&p)) { ERR("partition is read-only"); return true; }
            if (c == 0 || (c & (BLDR_SECTOR_SIZE - 1U)) != 0U || (uint64_t)b + c > p.pos.size ||
                b > UINT32_MAX - p.pos.offset ||
                ((p.pos.offset + b) & (BLDR_SECTOR_SIZE - 1U)) != 0U) {
                ERR("bad XMODEM range (sector-aligned, in partition)"); return true;
            }
            if (!consume_unlock_for_range(p.pos.offset + b, c, NULL)) return true;
            (void)xmodem_receive(0, c, true, p.pos.offset + b, &p, &n);
        } else {
            usage("xmdm");
        }
    } else if (strcmp(cmd, "info") == 0) {
        print_status();
    } else if (strcmp(cmd, "jump") == 0) {
        if (argc == 2 && parse_u32(argv[1], &a)) cmd_jump(a);
        else usage("jump");
    } else if (strcmp(cmd, "baud") == 0) {
        static const uint32_t rates[] = {9600U, 19200U, 38400U, 57600U, 115200U, 230400U, 460800U, 921600U};
        bool supported = false;
        if (argc != 2 || !parse_u32(argv[1], &a)) { usage("baud"); return true; }
        for (unsigned i = 0; i < sizeof(rates) / sizeof(rates[0]); ++i) if (a == rates[i]) supported = true;
        if (!supported) { ERR("unsupported baud"); return true; }
        ets_printf("Baud -> %u; switch terminal now\r\n", (unsigned)a);
        ets_delay_us(100000);
        set_uart_baud(a);
    } else {
        ERR("unknown command");
    }
    return true;
}

void bootloader_hooks_include(void)
{
    /* Strong symbol forces the static library containing the hook into the link. */
}

void bootloader_before_init(void)
{
    /* Keep the pre-init hook empty; ROM flash/UART state is not yet fully ready. */
}

static bool enter_monitor_session(void)
{
    char line[BLDR_LINE_MAX];
    uart_puts("Monitor entered. Type 'help'.\r\n");
    prompt();
    while (g_monitor_elapsed_ms < BLDR_MONITOR_MAX_MS) {
        if (!read_line(line, sizeof(line))) return false;
        char *argv[BLDR_ARG_MAX];
        int argc = split_args(line, argv, BLDR_ARG_MAX);
        if (argc < 0) {
            ERR("too many args");
        } else {
            (void)process_command(argc, argv);
        }
        prompt();
    }
    uart_puts("Monitor timeout; retrying boot\r\n");
    return false;
}

void bootloader_after_init(void)
{
    uint32_t waited_ms = 0U;
    uint8_t c = 0U;

    /* Do NOT touch the CPU clock or UART divider here: the ESP-IDF bootloader already
     * configured both for CONFIG_ESP_CONSOLE_UART_BAUDRATE (115200). Re-deriving the divider
     * from rtc_clk_apb_freq_get() after a clock switch produced garbled output on hardware. */
    /* Optional DTB. Blank the screen exactly once, as early as possible (no white flash). A missing,
     * invalid or undeclared display is skipped silently and leaves every GPIO untouched. */
    dt_load();
    g_display_cleared = bldr_display_clear_black(&g_dt.display);
    /* Flash was initialized by the ESP-IDF second-stage bootloader before
     * this hook. Do not reset MSPI/flash. Initialize the configured PSRAM now. */
    bldr_psram_init();
    fx_wait();
    ets_printf("\r\nBOOTLOADER console v%s\r\n", BLDR_VERSION);
    uart_puts("  Wiring-ChaosVN by Nick\r\n");
    fx_wait();
    print_status();
    uart_puts("Internal SRAM/IRAM is private to the bootloader.\r\n");
    uart_puts("Press any key (1 s) for console.\r\n");

    while (waited_ms < BLDR_TRIGGER_MS) {
        if (uart_rx_one_char(&c) == 0) {
            uart_puts("\r\n");
            for (;;) {
                (void)enter_monitor_session();
                if (post_self_test()) {
                    if (boot_esp_os_kernel("kernel")) return;
                }
                BOOT("Boot blocked; 'go' retries");
            }
        }
        ets_delay_us(1000U);
        ++waited_ms;
        if ((waited_ms % BLDR_TRIGGER_DOT_MS) == 0U) uart_putc('.');
        if ((waited_ms & 0xFFU) == 0U) feed_watchdog();
    }

    uart_puts("\r\n");
    if (post_self_test() && boot_esp_os_kernel("kernel")) return;
    BOOT("Auto boot blocked; monitor");
    for (;;) {
        (void)enter_monitor_session();
        if (post_self_test()) {
            if (boot_esp_os_kernel("kernel")) return;
        }
        BOOT("Boot blocked; 'go' retries");
    }
}

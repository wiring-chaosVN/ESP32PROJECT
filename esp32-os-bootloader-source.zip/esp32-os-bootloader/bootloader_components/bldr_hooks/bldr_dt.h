/*
 * SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
 * SPDX-License-Identifier: GPL-3.0-only
 */
#ifndef BLDR_DT_H
#define BLDR_DT_H

#include <stdbool.h>
#include <stdint.h>

/* Read-only, bounds-checked reader for a flattened device tree (DTB, version 17)
 * stored in the "dtb" MTD. The bootloader only needs the one display node and the
 * SPI bus node it points at; everything else in the DTB belongs to the kernel.
 * Pure C with no hardware access, so it is unit-tested on the host. */

enum {
    BLDR_DT_OK = 0,
    BLDR_DT_E_ARG,
    BLDR_DT_E_MAGIC,
    BLDR_DT_E_SIZE,
    BLDR_DT_E_VERSION,
    BLDR_DT_E_STRUCT,
};

typedef struct {
    bool     listed;          /* an enabled display node exists in the DTB */
    bool     usable;          /* supported controller and every required property is valid */
    const char *note;         /* static string: why it is not usable, or "ok" */
    uint16_t width, height;   /* native panel size in pixels (portrait) */
    uint8_t  rotation;        /* 0..3, TFT_eSPI setRotation() numbering */
    uint8_t  xoff, yoff;      /* GRAM offsets in the rotated frame */
    int8_t   sck, mosi, cs, dc, rst, bl;   /* GPIO numbers, -1 = not wired */
    bool     bgr;             /* MADCTL colour-order bit (default true, like TFT_eSPI) */
    bool     invert;          /* send INVON */
    bool     bl_active_low;
} bldr_dt_display_t;

typedef struct {
    uint32_t totalsize;       /* FDT header totalsize */
    bldr_dt_display_t display;
} bldr_dt_t;

/* `max_size` is the size of the readable region (the MTD size). Returns
 * BLDR_DT_OK when the blob is structurally valid; a missing/unusable display is
 * not an error (see out->display.listed / usable / note). */
int bldr_dt_parse(const void *blob, uint32_t max_size, bldr_dt_t *out);
const char *bldr_dt_strerror(int rc);

#endif

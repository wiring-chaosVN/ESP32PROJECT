/*
 * SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
 * SPDX-License-Identifier: GPL-3.0-only
 */
/*
 * Minimal ST7735S display initialization for the second-stage bootloader.
 * The display is initialized and its complete GRAM is cleared to RGB565 black.
 * Software (bit-bang) SPI mode 0 uses GPIOs from the board DTB.
 */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "sdkconfig.h"
#include "soc/soc.h"
#include "soc/gpio_reg.h"
#include "soc/gpio_sig_map.h"
#include "esp32s3/rom/ets_sys.h"
#include "esp32s3/rom/gpio.h"
#include "bldr_display.h"

#define LCD_RAM_W            132     /* ST7735 GRAM is 132x162: clear all of it */
#define LCD_RAM_H            162


typedef struct { uint32_t set_reg, clr_reg, en_reg, mask; } pin_t;   /* mask 0 = not wired */

static pin_t s_sclk, s_mosi, s_cs, s_dc, s_rst, s_bl;
static const bldr_dt_display_t *s_cfg;

static pin_t pin_make(int p)
{
    pin_t r = {0U, 0U, 0U, 0U};
    if (p < 0) return r;
    if (p < 32) {
        r.set_reg = GPIO_OUT_W1TS_REG; r.clr_reg = GPIO_OUT_W1TC_REG;
        r.en_reg = GPIO_ENABLE_W1TS_REG; r.mask = 1U << p;
    } else {
        r.set_reg = GPIO_OUT1_W1TS_REG; r.clr_reg = GPIO_OUT1_W1TC_REG;
        r.en_reg = GPIO_ENABLE1_W1TS_REG; r.mask = 1U << (p - 32);
    }
    return r;
}

/* Required pins (never mask 0): unguarded. Optional pins: o* variants skip when absent. */
static inline void hi(const pin_t *p)  { REG_WRITE(p->set_reg, p->mask); }
static inline void lo(const pin_t *p)  { REG_WRITE(p->clr_reg, p->mask); }
static inline void ohi(const pin_t *p) { if (p->mask != 0U) REG_WRITE(p->set_reg, p->mask); }
static inline void olo(const pin_t *p) { if (p->mask != 0U) REG_WRITE(p->clr_reg, p->mask); }

static void pin_output(const pin_t *p, bool level)
{
    if (p->mask == 0U) return;
    /* ROM helpers take the GPIO number; recover it from the mask. */
    uint32_t n = 0U;
    while (((p->mask >> n) & 1U) == 0U) ++n;
    if (p->set_reg == GPIO_OUT1_W1TS_REG) n += 32U;
    gpio_pad_select_gpio(n);
    gpio_matrix_out(n, SIG_GPIO_OUT_IDX, false, false);
    if (level) hi(p); else lo(p);                 /* set level before enabling */
    REG_WRITE(p->en_reg, p->mask);
}

static void spi_byte(uint8_t b)
{
    for (int i = 7; i >= 0; --i) {
        if ((b >> i) & 1U) hi(&s_mosi); else lo(&s_mosi);
        hi(&s_sclk);
        lo(&s_sclk);
    }
}

/* Command with 0..n data bytes, one CS frame. */
static void write_cmd(uint8_t cmd, const uint8_t *args, unsigned n)
{
    olo(&s_cs);
    lo(&s_dc);
    spi_byte(cmd);
    hi(&s_dc);
    for (unsigned i = 0; i < n; ++i) spi_byte(args[i]);
    ohi(&s_cs);
}

static void set_window_raw(unsigned x0, unsigned y0, unsigned x1, unsigned y1)
{
    const uint8_t xa[4] = {(uint8_t)(x0 >> 8), (uint8_t)x0, (uint8_t)(x1 >> 8), (uint8_t)x1};
    const uint8_t ya[4] = {(uint8_t)(y0 >> 8), (uint8_t)y0, (uint8_t)(y1 >> 8), (uint8_t)y1};
    write_cmd(0x2A, xa, 4);   /* CASET */
    write_cmd(0x2B, ya, 4);   /* RASET */
}

/* Open the RAM write; CS stays low for the whole pixel stream. */
static void ram_begin(void)
{
    olo(&s_cs);
    lo(&s_dc);
    spi_byte(0x2C);           /* RAMWR */
    hi(&s_dc);
}

static void ram_end(void) { ohi(&s_cs); }

static void delay_ms(uint32_t ms)
{
    while (ms--) ets_delay_us(1000U);
}

/* Init list (TFT_eSPI / Adafruit "Rcmd1"): cmd, nargs, args... ; 0xFF ends. */
static const uint8_t k_init[] = {
    0xB1, 3, 0x01, 0x2C, 0x2D,              /* FRMCTR1 */
    0xB2, 3, 0x01, 0x2C, 0x2D,              /* FRMCTR2 */
    0xB3, 6, 0x01, 0x2C, 0x2D, 0x01, 0x2C, 0x2D, /* FRMCTR3 */
    0xB4, 1, 0x07,                          /* INVCTR */
    0xC0, 3, 0xA2, 0x02, 0x84,              /* PWCTR1 */
    0xC1, 1, 0xC5,                          /* PWCTR2 */
    0xC2, 2, 0x0A, 0x00,                    /* PWCTR3 */
    0xC3, 2, 0x8A, 0x2A,                    /* PWCTR4 */
    0xC4, 2, 0x8A, 0xEE,                    /* PWCTR5 */
    0xC5, 1, 0x0E,                          /* VMCTR1 */
    0xFF
};

/* TFT_eSPI ST7735 setRotation(0..3) MADCTL values, without the colour-order bit. */
static const uint8_t k_madctl[4] = {0xC0U, 0xA0U, 0x00U, 0x60U};

static void panel_init(void)
{
    if (s_rst.mask != 0U) {
        ohi(&s_rst);
        delay_ms(5);
        olo(&s_rst);
        delay_ms(10);
        ohi(&s_rst);
        delay_ms(120);
    } else {
        write_cmd(0x01, 0, 0);              /* SWRESET */
        delay_ms(150);
    }
    write_cmd(0x11, 0, 0);                  /* SLPOUT */
    delay_ms(120);

    for (const uint8_t *p = k_init; *p != 0xFFU; ) {
        write_cmd(p[0], p + 2, p[1]);
        p += 2U + p[1];
    }
    write_cmd(s_cfg->invert ? 0x21 : 0x20, 0, 0);       /* INVON / INVOFF */
    const uint8_t madctl = (uint8_t)(k_madctl[s_cfg->rotation & 3U] | (s_cfg->bgr ? 0x08U : 0x00U));
    write_cmd(0x36, &madctl, 1);            /* MADCTL */
    const uint8_t colmod = 0x05;
    write_cmd(0x3A, &colmod, 1);            /* COLMOD: 16 bit */
    write_cmd(0x13, 0, 0);                  /* NORON */
}

static void clear_all_ram(void)
{
    /* Raw GRAM coordinates (no offset). With MV set (rotation 1/3) the column and
     * row ranges swap, so cover 162x132 instead of 132x162. */
    const bool swap = (s_cfg->rotation & 1U) != 0U;
    set_window_raw(0, 0, (swap ? LCD_RAM_H : LCD_RAM_W) - 1U, (swap ? LCD_RAM_W : LCD_RAM_H) - 1U);
    ram_begin();
    /* With INVON the panel inverts RGB565 values, so send white data to show black. */
    if (s_cfg->invert) hi(&s_mosi);
    else lo(&s_mosi);
    for (uint32_t i = 0; i < (uint32_t)LCD_RAM_W * LCD_RAM_H * 16U; ++i) {
        hi(&s_sclk);
        lo(&s_sclk);
    }
    ram_end();
}

bool bldr_display_clear_black(const bldr_dt_display_t *cfg)
{
    if (cfg == NULL || !cfg->usable) return false;
    s_cfg = cfg;
    s_sclk = pin_make(cfg->sck);  s_mosi = pin_make(cfg->mosi);
    s_cs   = pin_make(cfg->cs);   s_dc   = pin_make(cfg->dc);
    s_rst  = pin_make(cfg->rst);  s_bl   = pin_make(cfg->bl);

    pin_output(&s_cs, true);
    pin_output(&s_sclk, false);
    pin_output(&s_mosi, false);
    pin_output(&s_dc, true);
    pin_output(&s_rst, true);
    pin_output(&s_bl, cfg->bl_active_low);   /* backlight off while GRAM is noise */

    panel_init();
    clear_all_ram();                       /* Entire GRAM becomes RGB565 black */
    write_cmd(0x29, 0, 0);                  /* DISPON */
    delay_ms(20);
    if (cfg->bl_active_low) olo(&s_bl); else ohi(&s_bl);
    return true;
}

#ifndef BLDR_MEMORY_H
#define BLDR_MEMORY_H

#include <stdbool.h>
#include <stdint.h>

/* The virtual base is determined from the detected PSRAM capacity at boot.
 * ESP32-S3's default data-map window ends at SOC_EXTRAM_DATA_HIGH (0x3E000000).
 * The first 4 KiB of the mapped device are reserved and never exposed to monitor
 * commands. Do not hardcode 0x3D000000: that is not the base of an 8-MiB PSRAM. */
#define BLDR_PSRAM_RESERVED_BYTES   0x1000U
#define BLDR_PSRAM_MAX_SUPPORTED_BYTES 0x00800000U /* ESP32-S3 N16R8 board: 8 MiB PSRAM */

/* Pure policy helper so production range arithmetic can be unit-tested on host. */
static inline bool bldr_memory_range_within(uint32_t addr, uint32_t len,
                                             uint32_t base, uint32_t size,
                                             uint32_t reserved)
{
    const uint64_t user_start = (uint64_t)base + reserved;
    const uint64_t region_end = (uint64_t)base + size;
    const uint64_t requested_end = (uint64_t)addr + len;

    if (len == 0U || size <= reserved || region_end > UINT32_MAX ||
        user_start >= region_end || requested_end > UINT32_MAX) {
        return false;
    }
    return (uint64_t)addr >= user_start && requested_end <= region_end;
}


/* ------------------------------------------------------------------------
 * NPIM: boot image placed in PSRAM and started with `jump <psram_addr>`.
 *
 * Layout (little-endian). The header sits at the first byte of the image and
 * the image start must be 64-KiB aligned inside PSRAM (MMU page granularity).
 * The image is executed in place: PSRAM pages are mapped on the instruction
 * bus at `vbase`, so the code must be linked for 0x42xxxxxx addresses.
 * CRC is deliberately NOT checked on this path (debug/boot-from-RAM use).
 * ------------------------------------------------------------------------ */
#define BLDR_NPIM_MAGIC        "NPIM"
#define BLDR_NPIM_VERSION      1U
#define BLDR_NPIM_HDR_SIZE     32U
#define BLDR_NPIM_FLAG_XIP     (1U << 0)   /* required in v1 */
#define BLDR_IBUS_LOW          0x42000000U
#define BLDR_IBUS_HIGH         0x44000000U
#define BLDR_MMU_PAGE          0x10000U

typedef struct {
    char magic[4];
    uint16_t version;
    uint16_t flags;
    uint32_t entry;          /* virtual entry address, inside [vbase, vbase + image_size) */
    uint32_t vbase;          /* virtual address of the image start (64-KiB aligned, IBUS) */
    uint32_t image_size;     /* bytes from header start to end of image incl. initramfs */
    uint32_t initramfs_off;  /* from header start; 0 = no initramfs */
    uint32_t initramfs_size;
    uint32_t reserved;       /* must be 0 */
} bldr_npim_hdr_t;

/* Boot-info block "NBIF" (version 2), written by the bootloader on EVERY kernel
 * hand-off (go / automatic boot / jump). Location: the reserved first 4 KiB of PSRAM,
 * i.e. PSRAM physical offset 0 (the kernel maps PSRAM itself, so it must not rely on
 * the bootloader's data-bus address in psram_base). The jump path also passes its
 * address in a2. The block is followed by mtd_count 32-byte nexus.ptb rows
 * (name[16], offset, size, vaddr, kind, flags). crc32 is the IEEE CRC32 over the
 * whole block (this struct with crc32 = 0, plus the rows). */
#define BLDR_BOOTINFO_MAGIC    "NBIF"
#define BLDR_BOOTINFO_VERSION  2U
#define BLDR_BI_SRC_FLASH      (1U << 0)   /* kernel loaded from its flash MTD (go/auto boot) */
#define BLDR_BI_SRC_PSRAM      (1U << 1)   /* NPIM image started with jump */
#define BLDR_BI_DTB_VALID      (1U << 2)   /* dtb_offset/dtb_size describe a structurally valid DTB */
#define BLDR_BI_SPLASH         (1U << 3)   /* the bootloader drew the boot logo on the DTB display */

typedef struct {
    char magic[4];
    uint16_t version;        /* 2 */
    uint16_t mtd_count;
    uint32_t psram_base;     /* bootloader data-bus address of PSRAM start (informational) */
    uint32_t psram_size;
    uint32_t image_addr;     /* jump path only (else 0): data-bus address of the NPIM header */
    uint32_t image_size;
    uint32_t vbase;
    uint32_t initramfs_addr; /* data-bus address, 0 if none */
    uint32_t initramfs_size;
    uint32_t flash_size;
    uint32_t boot_flags;     /* BLDR_BI_* */
    uint32_t dtb_offset;     /* flash offset of the DTB (mtd "dtb"), 0 if none */
    uint32_t dtb_size;       /* FDT totalsize, 0 if none */
    uint32_t crc32;
} bldr_bootinfo_t;
_Static_assert(sizeof(bldr_bootinfo_t) == 56U, "NBIF v2 header layout changed");

enum {
    BLDR_NPIM_OK = 0,
    BLDR_NPIM_E_MAGIC,
    BLDR_NPIM_E_ALIGN,
    BLDR_NPIM_E_FIELDS,
    BLDR_NPIM_E_RANGE,
    BLDR_NPIM_E_VADDR,
};

/* Pure checks (host-testable). addr is the data-bus address of the header,
 * [base, base+size) the detected PSRAM, first_data_entry the MMU page index where the
 * PSRAM data window starts (the instruction mapping must stay below it, because the
 * ESP32-S3 MMU table is shared by both buses). */
static inline int bldr_npim_check(const bldr_npim_hdr_t *h, uint32_t addr,
                                  uint32_t base, uint32_t size, uint32_t reserved,
                                  uint32_t first_data_entry)
{
    if (h->magic[0] != 'N' || h->magic[1] != 'P' || h->magic[2] != 'I' || h->magic[3] != 'M')
        return BLDR_NPIM_E_MAGIC;
    if (addr < base || ((addr - base) & (BLDR_MMU_PAGE - 1U)) != 0U) return BLDR_NPIM_E_ALIGN;
    if (h->version != BLDR_NPIM_VERSION || (h->flags & BLDR_NPIM_FLAG_XIP) == 0U ||
        h->reserved != 0U || h->image_size <= BLDR_NPIM_HDR_SIZE) return BLDR_NPIM_E_FIELDS;
    if (!bldr_memory_range_within(addr, h->image_size, base, size, reserved)) return BLDR_NPIM_E_RANGE;
    if (h->initramfs_off != 0U &&
        (h->initramfs_off < BLDR_NPIM_HDR_SIZE || h->initramfs_size == 0U ||
         (uint64_t)h->initramfs_off + h->initramfs_size > h->image_size)) return BLDR_NPIM_E_FIELDS;
    if (h->initramfs_off == 0U && h->initramfs_size != 0U) return BLDR_NPIM_E_FIELDS;
    const uint64_t pages = ((uint64_t)h->image_size + BLDR_MMU_PAGE - 1U) / BLDR_MMU_PAGE;
    const uint64_t vend = (uint64_t)h->vbase + pages * BLDR_MMU_PAGE;
    if (h->vbase < BLDR_IBUS_LOW || (h->vbase & (BLDR_MMU_PAGE - 1U)) != 0U ||
        vend > BLDR_IBUS_HIGH ||
        (uint64_t)((h->vbase - BLDR_IBUS_LOW) / BLDR_MMU_PAGE) + pages > first_data_entry ||
        h->entry < h->vbase + BLDR_NPIM_HDR_SIZE || h->entry >= h->vbase + h->image_size ||
        (h->entry & 3U) != 0U) return BLDR_NPIM_E_VADDR;
    return BLDR_NPIM_OK;
}

/* These APIs accept only the PSRAM address range mapped and detected by the
 * bootloader. They never accept arbitrary SRAM, IRAM, MMIO or flash-mapped pointers. */
void bldr_psram_init(void);
bool bldr_psram_ready(void);
uint32_t bldr_psram_size(void);
uint32_t bldr_psram_user_base(void);
uint32_t bldr_psram_end(void); /* end-exclusive */
bool bldr_psram_range_valid(uint32_t addr, uint32_t len);
bool bldr_psram_read(uint32_t addr, void *dst, uint32_t len);
bool bldr_psram_write(uint32_t addr, const void *src, uint32_t len);
void *bldr_psram_reserved(void);        /* first 4 KiB of PSRAM (boot-info), NULL if PSRAM not ready */
uint32_t bldr_psram_first_data_entry(void); /* MMU page index where the PSRAM data window starts */
/* Map the PSRAM image at `addr` (64-KiB aligned) onto the instruction bus at `vbase`. */
bool bldr_psram_xip_map(uint32_t vbase, uint32_t addr, uint32_t bytes);

#endif

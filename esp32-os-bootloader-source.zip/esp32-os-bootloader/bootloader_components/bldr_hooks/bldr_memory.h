#ifndef BLDR_MEMORY_H
#define BLDR_MEMORY_H

#include <stdbool.h>
#include <stdint.h>

/* The virtual base is determined from the detected PSRAM capacity at boot.
 * ESP32-S3's default data-map window ends at SOC_EXTRAM_DATA_HIGH (0x3E000000).
 * The first 4 KiB of the mapped device are reserved and never exposed to monitor
 * commands. Do not hardcode 0x3D000000: that is not the base of an 8-MiB PSRAM. */
#define BLDR_PSRAM_RESERVED_BYTES   0x1000U
#define BLDR_PSRAM_MAX_SUPPORTED_BYTES 0x00800000U /* ESP32-S3 N16R8 board: 8 MiB PSRAM */

/* Pure policy helper so production range arithmetic can be unit-tested on host. */
static inline bool bldr_memory_range_within(uint32_t addr, uint32_t len,
                                             uint32_t base, uint32_t size,
                                             uint32_t reserved)
{
    const uint64_t user_start = (uint64_t)base + reserved;
    const uint64_t region_end = (uint64_t)base + size;
    const uint64_t requested_end = (uint64_t)addr + len;

    if (len == 0U || size <= reserved || region_end > UINT32_MAX ||
        user_start >= region_end || requested_end > UINT32_MAX) {
        return false;
    }
    return (uint64_t)addr >= user_start && requested_end <= region_end;
}

/* These APIs accept only the PSRAM address range mapped and detected by the
 * bootloader. They never accept arbitrary SRAM, IRAM, MMIO or flash-mapped pointers. */
void bldr_psram_init(void);
bool bldr_psram_ready(void);
uint32_t bldr_psram_size(void);
uint32_t bldr_psram_user_base(void);
uint32_t bldr_psram_end(void); /* end-exclusive */
bool bldr_psram_range_valid(uint32_t addr, uint32_t len);
bool bldr_psram_read(uint32_t addr, void *dst, uint32_t len);
bool bldr_psram_write(uint32_t addr, const void *src, uint32_t len);

#endif

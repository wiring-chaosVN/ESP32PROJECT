#ifndef BLDR_DISPLAY_H
#define BLDR_DISPLAY_H

#include <stdbool.h>
#include "bldr_dt.h"

/* Draw the static boot logo once, using the display described by the DTB.
 * Returns true if the logo was drawn. With a NULL/unusable config it returns
 * false and touches no GPIO, so the bootloader runs fine without a display.
 * Write-only bit-banged SPI: it never reads or waits on the panel. The kernel
 * owns the screen after hand-off and clears it itself. */
bool bldr_splash_show(const bldr_dt_display_t *cfg);

#endif

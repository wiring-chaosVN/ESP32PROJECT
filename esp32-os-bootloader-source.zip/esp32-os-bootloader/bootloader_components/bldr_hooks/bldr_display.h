/*
 * SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
 * SPDX-License-Identifier: GPL-3.0-only
 */
#ifndef BLDR_DISPLAY_H
#define BLDR_DISPLAY_H

#include <stdbool.h>
#include "bldr_dt.h"

/*
 * Initialize the ST7735 described by the DTB and clear its complete GRAM to
 * black. A missing or unusable configuration returns false without touching
 * GPIO. The kernel owns the display after hand-off.
 */
bool bldr_display_clear_black(const bldr_dt_display_t *cfg);

#endif

#ifndef BLDR_LOGO_GUARD_H
#define BLDR_LOGO_GUARD_H

#include <stdint.h>

/* ">_" boot logo as pure geometry: no bitmap, no data tables.
 * Design grid 64 x 47 px: a white chevron ">" (x 0..29) and a cyan cursor
 * bar "_" (x 32..63, y 37..46). Diagonals are exact 45-degree lines, so each
 * row is one [left, right] span computed with integer add/sub only. */
#define BLDR_LOGO_W        64
#define BLDR_LOGO_H        47

#define BLDR_LOGO_BG       0
#define BLDR_LOGO_WHITE    1
#define BLDR_LOGO_CYAN     2

static inline uint8_t bldr_logo_pixel(int x, int y)
{
    if (x < 0 || y < 0 || x >= BLDR_LOGO_W || y >= BLDR_LOGO_H) return BLDR_LOGO_BG;
    if (x >= 32 && y >= 37) return BLDR_LOGO_CYAN;

    int left = (y < 24) ? (y - 10) : (38 - y);   /* inner edge of the chevron */
    if (left < 0) left = 0;
    int right = 9 + y;                           /* outer edge, rising diagonal */
    if (right > 29) right = 29;                  /* vertical tip */
    if (55 - y < right) right = 55 - y;          /* outer edge, falling diagonal */
    return (x >= left && x <= right) ? BLDR_LOGO_WHITE : BLDR_LOGO_BG;
}

#endif

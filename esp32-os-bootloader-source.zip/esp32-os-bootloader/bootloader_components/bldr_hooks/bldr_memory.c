/*
 * SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
 * SPDX-License-Identifier: GPL-3.0-only
 */
/*
 * Bootloader-only ESP32-S3 PSRAM bring-up and address policy.
 *
 * Flash is intentionally not reinitialized here: bootloader_after_init() is
 * called by ESP-IDF after bootloader_init(), where the flash/MSPI controller is
 * already initialized. For PSRAM, reuse the matching ESP-IDF v4.4.7 octal
 * device implementation (psram_enable/psram_get_size), then establish only the
 * DBUS/MMU mapping required for normal data access. No heap is created and no
 * PSRAM pointer is exported to command parsing code.
 */
#include "sdkconfig.h"
#include "bldr_memory.h"

#include <stddef.h>
#include <stdint.h>

#include "esp_attr.h"
#include "esp_err.h"
#include "esp32s3/rom/cache.h"
#include "esp32s3/rom/opi_flash.h"
#include "soc/cache_memory.h"
#include "soc/extmem_reg.h"
#include "soc/soc.h"
#include "soc/spi_mem_reg.h"
#include "esp_private/spi_flash_os.h"
#include "spiram_psram.h"

static bool s_psram_ready;
static uint32_t s_psram_base;
static uint32_t s_psram_size;

static uint32_t psram_enum_to_bytes(psram_size_t size)
{
    switch (size) {
    case PSRAM_SIZE_16MBITS:  return 2U * 1024U * 1024U;
    case PSRAM_SIZE_32MBITS:  return 4U * 1024U * 1024U;
    case PSRAM_SIZE_64MBITS:  return 8U * 1024U * 1024U;
    case PSRAM_SIZE_128MBITS: return 16U * 1024U * 1024U;
    case PSRAM_SIZE_256MBITS: return 32U * 1024U * 1024U;
    default: return 0U;
    }
}

/* ESP-IDF v4.4.7's octal PSRAM driver expects these flash-state restore hooks.
 * They normally live in spi_flash/flash_ops.c, which is not linked into the
 * second-stage bootloader. The QIO-flash branch below mirrors that driver's
 * small restore operation without pulling the 33-KiB flash application API into
 * the bootloader. If OPI flash is explicitly selected, keep the upstream path. */
void IRAM_ATTR spi_flash_set_rom_required_regs(void)
{
#if defined(CONFIG_ESPTOOLPY_OCT_FLASH) && CONFIG_ESPTOOLPY_OCT_FLASH
    CLEAR_PERI_REG_MASK(SPI_MEM_DDR_REG(1), SPI_MEM_SPI_FMEM_VAR_DUMMY);
#endif
}

void IRAM_ATTR spi_flash_set_vendor_required_regs(void)
{
#if defined(CONFIG_ESPTOOLPY_OCT_FLASH) && CONFIG_ESPTOOLPY_OCT_FLASH
    esp_opiflash_set_required_regs();
    SET_PERI_REG_BITS(SPI_MEM_CACHE_FCTRL_REG(1), SPI_MEM_CACHE_USR_CMD_4BYTE_V,
                      1, SPI_MEM_CACHE_USR_CMD_4BYTE_S);
#else
    /* QIO flash uses the non-OPI four-byte-command state. */
    SET_PERI_REG_BITS(SPI_MEM_CACHE_FCTRL_REG(1), SPI_MEM_CACHE_USR_CMD_4BYTE_V,
                      0, SPI_MEM_CACHE_USR_CMD_4BYTE_S);
#endif
}

static void psram_map_window(uint32_t base, uint32_t size)
{
    Cache_Suspend_DCache();
    Cache_Dbus_MMU_Set(MMU_ACCESS_SPIRAM, base, 0, 64, size >> 16, 0);
    REG_CLR_BIT(EXTMEM_DCACHE_CTRL1_REG, EXTMEM_DCACHE_SHUT_CORE0_BUS);
#if !CONFIG_FREERTOS_UNICORE
    REG_CLR_BIT(EXTMEM_DCACHE_CTRL1_REG, EXTMEM_DCACHE_SHUT_CORE1_BUS);
#endif
    Cache_Resume_DCache(0);
}

static bool psram_map_detected_device(uint32_t size)
{
    const uint32_t map_low = (uint32_t)SOC_EXTRAM_DATA_LOW;
    const uint32_t map_high = (uint32_t)SOC_EXTRAM_DATA_HIGH;
    const uint32_t map_size = map_high - map_low;
    if (size == 0U || (size & 0xFFFFU) != 0U ||
        size > BLDR_PSRAM_MAX_SUPPORTED_BYTES || size > map_size ||
        size <= BLDR_PSRAM_RESERVED_BYTES) {
        return false;
    }

    /* ESP-IDF v4.4.7 maps physical PSRAM from page 0 into the top of the virtual
     * external-data window. For this N16R8 board, detected 8-MiB PSRAM maps to
     * [0x3D800000, 0x3E000000). Capacities over 8 MiB are rejected conservatively
     * so a future board variant cannot silently overlap a flash DROM mapping. */
    const uint32_t base = map_high - size;
    psram_map_window(base, size);

    s_psram_base = base;
    s_psram_size = size;
    return true;
}

/* bootloader_munmap() on ESP32-S3 runs Cache_MMU_Init(), which invalidates EVERY MMU entry
 * (including this PSRAM window) and drops the D-cache. Any flash mmap user (esp_image verify in
 * POST/go/crc32/verify, partition scans) therefore unmaps PSRAM behind our back, after which reads
 * return 0xBAD00BAD and writes are lost. Re-establish the window before every PSRAM access. */
static void psram_ensure_mapped(void)
{
    if (s_psram_size != 0U) psram_map_window(s_psram_base, s_psram_size);
}

static bool psram_mapping_test(void)
{
    if (s_psram_size < BLDR_PSRAM_RESERVED_BYTES + sizeof(uint32_t) ||
        s_psram_base > UINT32_MAX - BLDR_PSRAM_RESERVED_BYTES) {
        return false;
    }

    volatile uint32_t *first = (volatile uint32_t *)(uintptr_t)
        (s_psram_base + BLDR_PSRAM_RESERVED_BYTES);
    volatile uint32_t *last = (volatile uint32_t *)(uintptr_t)
        (s_psram_base + s_psram_size - sizeof(uint32_t));
    const uint32_t saved_first = *first;
    const uint32_t saved_last = *last;
    bool ok = true;

    *first = 0xA55A3CC3U;
    *last = 0x5AA5C33CU;
    __asm__ __volatile__("memw" ::: "memory");
    if (*first != 0xA55A3CC3U || *last != 0x5AA5C33CU) ok = false;

    *first = saved_first;
    *last = saved_last;
    __asm__ __volatile__("memw" ::: "memory");
    return ok;
}

extern void spi_timing_set_pin_drive_strength(void);   /* spi_flash_timing_tuning.c, already linked */

void bldr_psram_init(void)
{
    s_psram_ready = false;
    s_psram_base = 0U;
    s_psram_size = 0U;

#if defined(CONFIG_SPIRAM) && CONFIG_SPIRAM && defined(CONFIG_SPIRAM_MODE_OCT) && CONFIG_SPIRAM_MODE_OCT
    /* An ESP-IDF app runs esp_mspi_pin_init() before psram_enable() (spi_flash/flash_ops.c). For
     * octal PSRAM that routes the data lines D4..D7 and DQS (GPIO33..37) to the MSPI and sets the
     * pad drive strength. The second-stage bootloader never does it, so without these two calls
     * the octal lines float and the PSRAM ID reads 0x00000000 ("PSRAM chip not found"). */
    esp_rom_opiflash_pin_config();
    spi_timing_set_pin_drive_strength();

    /* Keep octal PSRAM conservative during early boot. At 40 MHz in DTR mode,
     * ESP-IDF v4.4.7 correctly compiles its timing-tune entry point as a no-op;
     * the driver still configures shared MSPI timing and restores QIO flash. */
    if (psram_enable(PSRAM_CACHE_S40M, PSRAM_VADDR_MODE_NORMAL) != ESP_OK) {
        /* The upstream v4.4.7 OPI driver returns early on an absent PSRAM ID
         * while MSPI is still in low-speed bring-up mode. Restore configured
         * clocking and QIO flash state before keeping the recovery monitor alive. */
        spi_timing_enter_mspi_high_speed_mode(true);
        spi_flash_set_rom_required_regs();
        spi_flash_set_vendor_required_regs();
        return;
    }

    const uint32_t detected = psram_enum_to_bytes(psram_get_size());
    if (!psram_map_detected_device(detected)) return;

    /* Preserve the probe words so this test does not destroy early RAM content. */
    if (!psram_mapping_test()) {
        s_psram_base = 0U;
        s_psram_size = 0U;
        return;
    }
    s_psram_ready = true;
#endif
}

bool bldr_psram_ready(void)
{
    return s_psram_ready && s_psram_size > BLDR_PSRAM_RESERVED_BYTES;
}

uint32_t bldr_psram_size(void)
{
    return bldr_psram_ready() ? s_psram_size : 0U;
}

uint32_t bldr_psram_user_base(void)
{
    return bldr_psram_ready() ? s_psram_base + BLDR_PSRAM_RESERVED_BYTES : 0U;
}

uint32_t bldr_psram_end(void)
{
    return bldr_psram_ready() ? s_psram_base + s_psram_size : 0U;
}

bool bldr_psram_range_valid(uint32_t addr, uint32_t len)
{
    return bldr_psram_ready() &&
        bldr_memory_range_within(addr, len, s_psram_base, s_psram_size,
                                 BLDR_PSRAM_RESERVED_BYTES);
}

bool bldr_psram_read(uint32_t addr, void *dst, uint32_t len)
{
    if (dst == NULL || !bldr_psram_range_valid(addr, len)) return false;
    psram_ensure_mapped();
    const volatile uint8_t *src = (const volatile uint8_t *)(uintptr_t)addr;
    uint8_t *out = (uint8_t *)dst;
    for (uint32_t i = 0U; i < len; ++i) out[i] = src[i];
    return true;
}

bool bldr_psram_write(uint32_t addr, const void *src, uint32_t len)
{
    if (src == NULL || !bldr_psram_range_valid(addr, len)) return false;
    psram_ensure_mapped();
    volatile uint8_t *dst = (volatile uint8_t *)(uintptr_t)addr;
    const uint8_t *in = (const uint8_t *)src;
    for (uint32_t i = 0U; i < len; ++i) dst[i] = in[i];
    __asm__ __volatile__("memw" ::: "memory");
    /* PSRAM is accessed through the D-cache. Push the dirty lines out now: later flash
     * erase/read/mmap operations invalidate the D-cache without writing it back, which
     * silently discards data that only ever lived in the cache. */
    if (len != 0U) Cache_WriteBack_Addr(addr, len);
    return true;
}

void *bldr_psram_reserved(void)
{
    if (!bldr_psram_ready()) return NULL;
    psram_ensure_mapped();
    return (void *)(uintptr_t)s_psram_base;
}

uint32_t bldr_psram_first_data_entry(void)
{
    return bldr_psram_ready() ? (s_psram_base - (uint32_t)DRAM0_CACHE_ADDRESS_LOW) / BLDR_MMU_PAGE : 0U;
}

bool bldr_psram_xip_map(uint32_t vbase, uint32_t addr, uint32_t bytes)
{
    if (!bldr_psram_ready() || bytes == 0U || (vbase & (BLDR_MMU_PAGE - 1U)) != 0U ||
        addr < s_psram_base + BLDR_PSRAM_RESERVED_BYTES ||
        ((addr - s_psram_base) & (BLDR_MMU_PAGE - 1U)) != 0U) {
        return false;
    }
    const uint32_t pages = (bytes + BLDR_MMU_PAGE - 1U) / BLDR_MMU_PAGE;
    psram_ensure_mapped();
    /* Make data written through the D-cache (XMODEM, `flash`) visible to PSRAM first. */
    Cache_WriteBack_All();
    const uint32_t autoload = Cache_Suspend_ICache();
    Cache_Ibus_MMU_Set(MMU_ACCESS_SPIRAM, vbase, addr - s_psram_base, 64, pages, 0);
    Cache_Invalidate_ICache_All();
    Cache_Resume_ICache(autoload);
    return true;
}

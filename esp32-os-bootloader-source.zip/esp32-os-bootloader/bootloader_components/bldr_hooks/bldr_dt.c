#include <stddef.h>
#include <string.h>
#include "bldr_dt.h"

#define FDT_MAGIC       0xD00DFEEDU
#define FDT_HDR_SIZE    40U
#define T_BEGIN_NODE    1U
#define T_END_NODE      2U
#define T_PROP          3U
#define T_NOP           4U
#define T_END           9U
#define NONE            0xFFFFFFFFU

typedef struct {
    const uint8_t *s;      /* structure block */
    uint32_t s_size;
    const char *str;       /* strings block */
    uint32_t str_size;
} dt_t;

static uint32_t be32(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}

static bool tok_at(const dt_t *d, uint32_t off, uint32_t *v)
{
    if ((off & 3U) != 0U || off > d->s_size || d->s_size - off < 4U) return false;
    *v = be32(d->s + off);
    return true;
}

static bool str_is(const char *s, uint32_t avail, const char *lit)
{
    uint32_t i = 0U;
    for (; lit[i] != '\0'; ++i) if (i >= avail || s[i] != lit[i]) return false;
    return i < avail && s[i] == '\0';
}

/* Offset just past the BEGIN_NODE token and its padded name, or 0 on error. */
static uint32_t node_body(const dt_t *d, uint32_t off, const char **name)
{
    uint32_t t, i = 0U;
    if (!tok_at(d, off, &t) || t != T_BEGIN_NODE) return 0U;
    off += 4U;
    const char *n = (const char *)d->s + off;
    while (off + i < d->s_size && n[i] != '\0') ++i;
    if (off + i >= d->s_size) return 0U;
    if (name != NULL) *name = n;
    off = (off + i + 1U + 3U) & ~3U;
    return off <= d->s_size ? off : 0U;
}

/* Property `pname` directly inside the node that begins at node_off. */
static const uint8_t *dt_prop(const dt_t *d, uint32_t node_off, const char *pname, uint32_t *plen)
{
    uint32_t off = node_body(d, node_off, NULL);
    while (off != 0U) {
        uint32_t t, len, nameoff;
        if (!tok_at(d, off, &t)) return NULL;
        if (t == T_NOP) { off += 4U; continue; }
        if (t != T_PROP) return NULL;
        if (!tok_at(d, off + 4U, &len) || !tok_at(d, off + 8U, &nameoff)) return NULL;
        if (len > d->s_size || off + 12U > d->s_size - len) return NULL;
        if (nameoff < d->str_size && str_is(d->str + nameoff, d->str_size - nameoff, pname)) {
            if (plen != NULL) *plen = len;
            return d->s + off + 12U;
        }
        off = (off + 12U + len + 3U) & ~3U;
    }
    return NULL;
}

typedef bool (*match_fn)(const dt_t *, uint32_t node, const char *name, const void *ctx);

/* First node (document order) for which fn() is true, or NONE. */
static uint32_t find_node(const dt_t *d, match_fn fn, const void *ctx)
{
    uint32_t off = 0U;
    while (off + 4U <= d->s_size) {
        uint32_t t, len;
        if (!tok_at(d, off, &t)) return NONE;
        if (t == T_BEGIN_NODE) {
            const char *name = NULL;
            const uint32_t body = node_body(d, off, &name);
            if (body == 0U) return NONE;
            if (fn(d, off, name, ctx)) return off;
            off = body;
        } else if (t == T_END_NODE || t == T_NOP) {
            off += 4U;
        } else if (t == T_PROP) {
            if (!tok_at(d, off + 4U, &len) || len > d->s_size || off + 12U > d->s_size - len) return NONE;
            off = (off + 12U + len + 3U) & ~3U;
        } else {
            return NONE;   /* FDT_END or garbage */
        }
    }
    return NONE;
}

static bool prop_u32(const dt_t *d, uint32_t node, const char *name, uint32_t *v)
{
    uint32_t len = 0U;
    const uint8_t *p = dt_prop(d, node, name, &len);
    if (p == NULL || len < 4U) return false;
    *v = be32(p);
    return true;
}

/* NUL-terminated string property; returns pointer or NULL. */
static const char *prop_str(const dt_t *d, uint32_t node, const char *name)
{
    uint32_t len = 0U;
    const uint8_t *p = dt_prop(d, node, name, &len);
    if (p == NULL || len == 0U || p[len - 1U] != 0U) return NULL;
    return (const char *)p;
}

static bool compat_has(const dt_t *d, uint32_t node, const char *lit)
{
    uint32_t len = 0U, off = 0U;
    const uint8_t *p = dt_prop(d, node, "compatible", &len);
    if (p == NULL) return false;
    while (off < len) {
        uint32_t l = 0U;
        while (off + l < len && p[off + l] != 0U) ++l;
        if (off + l >= len) return false;
        if (str_is((const char *)p + off, l + 1U, lit)) return true;
        off += l + 1U;
    }
    return false;
}

static bool node_enabled(const dt_t *d, uint32_t node)
{
    const char *s = prop_str(d, node, "status");
    return s == NULL || str_is(s, 8U, "okay") || str_is(s, 8U, "ok");
}

static bool name_starts(const char *n, const char *pfx)
{
    for (; *pfx != '\0'; ++pfx, ++n) if (*n != *pfx) return false;
    return true;
}

static bool name_is(const char *n, const char *want)
{
    for (; *want != '\0'; ++want, ++n) if (*n != *want) return false;
    return *n == '\0' || *n == '@';
}

static bool match_display(const dt_t *d, uint32_t node, const char *name, const void *ctx)
{
    (void)ctx;
    return name_starts(name, "display") && node_enabled(d, node);
}

static bool match_name(const dt_t *d, uint32_t node, const char *name, const void *ctx)
{
    (void)d; (void)node;
    return name_is(name, (const char *)ctx);
}

/* Usable ESP32-S3 GPIO for this board family: no GPIO22..25 (do not exist), no
 * 26..37 (flash / octal PSRAM), no 43/44 (UART0 console). */
static bool pin_ok(uint32_t p)
{
    return p <= 48U && !(p >= 22U && p <= 37U) && p != 43U && p != 44U;
}

/* 0 = ok (value set), 1 = absent, 2 = invalid */
static int get_pin(const dt_t *d, uint32_t node, const char *name, int8_t *out)
{
    uint32_t v;
    if (!prop_u32(d, node, name, &v)) return 1;
    if (!pin_ok(v)) return 2;
    *out = (int8_t)v;
    return 0;
}

static void parse_display(const dt_t *d, uint32_t dn, bldr_dt_display_t *o)
{
    uint32_t w = 0U, h = 0U, rot = 0U, xo = 0U, yo = 0U;
    o->listed = true;
    o->note = "unsupported controller";
    if (!compat_has(d, dn, "sitronix,st7735s") && !compat_has(d, dn, "sitronix,st7735")) return;

    if (!prop_u32(d, dn, "width", &w) || !prop_u32(d, dn, "height", &h)) { o->note = "missing width/height"; return; }
    if (w < 64U || w > 132U || h < 64U || h > 162U) { o->note = "bad width/height"; return; }
    if (prop_u32(d, dn, "rotation", &rot) && rot > 3U) { o->note = "bad rotation"; return; }
    if ((prop_u32(d, dn, "x-offset", &xo) && xo > 8U) || (prop_u32(d, dn, "y-offset", &yo) && yo > 8U)) {
        o->note = "bad offset"; return;
    }
    o->bgr = true;
    const char *co = prop_str(d, dn, "color-order");
    if (co != NULL) {
        if (str_is(co, 8U, "rgb")) o->bgr = false;
        else if (!str_is(co, 8U, "bgr")) { o->note = "bad color-order"; return; }
    }
    o->invert = dt_prop(d, dn, "invert", NULL) != NULL;
    o->bl_active_low = dt_prop(d, dn, "backlight-active-low", NULL) != NULL;

    int8_t cs = -1, rst = -1, bl = -1, dc = -1, sck = -1, mosi = -1;
    int rc;
    if (get_pin(d, dn, "dc-gpios", &dc) != 0) { o->note = "dc-gpios missing/invalid"; return; }
    if ((rc = get_pin(d, dn, "reset-gpios", &rst)) == 2) { o->note = "reset-gpios invalid"; return; }
    if ((rc = get_pin(d, dn, "backlight-gpios", &bl)) == 2) { o->note = "backlight-gpios invalid"; return; }
    if ((rc = get_pin(d, dn, "cs-gpios", &cs)) == 2) { o->note = "cs-gpios invalid"; return; }

    const char *bus = prop_str(d, dn, "bus");
    if (bus == NULL) { o->note = "bus missing"; return; }
    const uint32_t bn = find_node(d, match_name, bus);
    if (bn == NONE || !node_enabled(d, bn)) { o->note = "bus node missing/disabled"; return; }
    if (get_pin(d, bn, "sck-gpios", &sck) != 0 || get_pin(d, bn, "mosi-gpios", &mosi) != 0) {
        o->note = "sck/mosi-gpios missing/invalid"; return;
    }

    const int8_t pins[6] = {sck, mosi, cs, dc, rst, bl};
    for (int i = 0; i < 6; ++i)
        for (int j = i + 1; j < 6; ++j)
            if (pins[i] >= 0 && pins[i] == pins[j]) { o->note = "duplicate pin"; return; }

    o->width = (uint16_t)w; o->height = (uint16_t)h; o->rotation = (uint8_t)rot;
    o->xoff = (uint8_t)xo; o->yoff = (uint8_t)yo;
    o->sck = sck; o->mosi = mosi; o->cs = cs; o->dc = dc; o->rst = rst; o->bl = bl;
    o->usable = true;
    o->note = "ok";
}

int bldr_dt_parse(const void *blob, uint32_t max_size, bldr_dt_t *out)
{
    if (blob == NULL || out == NULL) return BLDR_DT_E_ARG;
    memset(out, 0, sizeof(*out));
    out->display.sck = out->display.mosi = out->display.cs = -1;
    out->display.dc = out->display.rst = out->display.bl = -1;
    out->display.note = "no display node";

    if (max_size < FDT_HDR_SIZE) return BLDR_DT_E_SIZE;
    const uint8_t *b = (const uint8_t *)blob;
    if (be32(b) != FDT_MAGIC) return BLDR_DT_E_MAGIC;
    const uint32_t total = be32(b + 4), off_struct = be32(b + 8), off_str = be32(b + 12);
    const uint32_t version = be32(b + 20), str_size = be32(b + 32), struct_size = be32(b + 36);
    if (total < FDT_HDR_SIZE || total > max_size) return BLDR_DT_E_SIZE;
    if (version < 17U) return BLDR_DT_E_VERSION;
    if ((off_struct & 3U) != 0U || off_struct < FDT_HDR_SIZE || struct_size < 8U ||
        off_struct > total || struct_size > total - off_struct ||
        off_str < FDT_HDR_SIZE || off_str > total || str_size > total - off_str) return BLDR_DT_E_STRUCT;

    dt_t d = { b + off_struct, struct_size, (const char *)b + off_str, str_size };
    uint32_t t;
    if (!tok_at(&d, 0U, &t) || t != T_BEGIN_NODE) return BLDR_DT_E_STRUCT;
    out->totalsize = total;

    const uint32_t dn = find_node(&d, match_display, NULL);
    if (dn != NONE) parse_display(&d, dn, &out->display);
    return BLDR_DT_OK;
}

const char *bldr_dt_strerror(int rc)
{
    switch (rc) {
    case BLDR_DT_OK:        return "ok";
    case BLDR_DT_E_MAGIC:   return "bad magic";
    case BLDR_DT_E_SIZE:    return "bad size";
    case BLDR_DT_E_VERSION: return "unsupported version";
    case BLDR_DT_E_STRUCT:  return "bad structure";
    default:                return "bad argument";
    }
}

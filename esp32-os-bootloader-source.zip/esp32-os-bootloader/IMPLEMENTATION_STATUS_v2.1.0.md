# ESP32-OS Bootloader v2.1.0 — Implementation Status

## Scope

Target: ESP32-S3 N16R8, ESP-IDF v4.4.7, 16 MiB QIO flash and 8 MiB octal PSRAM.

This source implements the v2.1.0 monitor/memory architecture and adds CI checks. It is a **source candidate**, not a claimed hardware-validated release. Do not flash it until the CI firmware build completes successfully and the resulting binary is reviewed.

## Implemented in source

- Flash is not reinitialized by the monitor hook. ESP-IDF `bootloader_init()` completes before `bootloader_after_init()`; the monitor checks the reported flash capacity and performs a read test.
- The exact ESP-IDF v4.4.7 OPI PSRAM device and MSPI timing sources are compiled into the bootloader hook because ESP-IDF's regular application PSRAM driver is not part of the default second-stage bootloader source set.
- PSRAM is configured at the conservative 40 MHz mode, the device capacity is detected, and the data-cache/MMU mapping is created from the detected size. The implementation conservatively rejects capacities above 8 MiB so it cannot silently overlap another mapping on an unexpected board variant.
- For 8 MiB PSRAM, the mapping is `[0x3D800000, 0x3E000000)`. The first 4 KiB are reserved; monitor commands can use only `[0x3D801000, 0x3E000000)` when that mapping has passed its probe.
- The SRAM/IRAM POST buffer and XMODEM staging buffer remain private. The command parser does not accept arbitrary SRAM/IRAM pointers.
- `flash <flash_addr> <psram_addr> <len>` sources data only from validated PSRAM. `dump <flash_addr> <len> <psram_addr>` writes flash data only into validated PSRAM. `jump` remains disabled.
- XMODEM stores each complete 128-byte or 1024-byte packet in private staging RAM, verifies block complement and CRC, and checks sequence before committing accepted bytes to the PSRAM or flash destination.
- Flash mutations remain gated by the custom-partition policy and the one-shot `unlock` token. Flash-encryption alignment checks remain in the write paths.
- POST checks the internal safe buffer, PSRAM readiness/mapping, flash readability, ESP-IDF partition table, custom VCS table, and supported payload integrity checks. If PSRAM is unavailable, automatic OS boot is blocked but the recovery monitor remains reachable.
- The CI workflow emits the bootloader ELF/map where available, size summaries and checksums; it rejects a second-stage bootloader binary at or above `0x20000`.

## Checks run in this workspace

- `python3 tests/check_monitor_features.py` — PASS. Includes a host-compiled C test of the exact production range-policy helper, plus source-policy checks, VCS geometry/CRC checks and ROMF payload/header/CRC checks.
- GitHub Actions workflow YAML parsed successfully with PyYAML; the main action command passed `bash -n`.
- `python3 tools/generate_partition_vcs.py` — PASS; generated 231-byte table with five entries and row CRC32 `0x9B087838`.
- `python3 tools/make_os_blob.py --magic ROMF --input romfile.defaults.example --output romfile.bin --max-size 0x1000` — PASS; generated a 420-byte ROMF blob, payload CRC32 `0x8FF50DF8`.
- ZIP integrity check — PASS for the v2.0.1 input archive. The v2.1.0 archive is separately checked after packaging.

## Not verified in this workspace

- A real ESP-IDF v4.4.7 Xtensa configure/build/link: `idf.py`, `IDF_PATH`, and `xtensa-esp32s3-elf-gcc` are not installed in this execution environment.
- The resulting bootloader linker's IRAM/DRAM segment budgets and final image size. The CI workflow is prepared to make these failures visible, but it has not been run here.
- Runtime OPI PSRAM initialization, cache/MMU mapping, flash recovery when PSRAM is absent, UART/XMODEM transfers, flash encryption, and kernel handoff on an actual ESP32-S3 N16R8.

## Important lifecycle rule

PSRAM is volatile scratch storage. A kernel using ESP-IDF's normal application startup may reinitialize/remap PSRAM and run its own memory test. Data staged by `xmdm` in PSRAM must therefore be consumed before handoff or explicitly preserved by a coordinated kernel startup; it is not persistent storage. The `ramdisk` image remains in flash and its later load/mount lifecycle belongs to the OS kernel.

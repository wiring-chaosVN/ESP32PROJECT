from pathlib import Path
import csv
import re
import struct
import subprocess
import sys
import tempfile
import zlib

root = Path(__file__).resolve().parents[1]
source = (root / "bootloader_components/bldr_hooks/hooks.c").read_text()
mem_c = (root / "bootloader_components/bldr_hooks/bldr_memory.c").read_text()
mem_h = (root / "bootloader_components/bldr_hooks/bldr_memory.h").read_text()
cmake = (root / "bootloader_components/bldr_hooks/CMakeLists.txt").read_text()
readme = (root / "README.md").read_text()
workflow_path = root / ".github/workflows/build_v2.1.0.yml"
workflow = workflow_path.read_text()
main_c = (root / "main/main.c").read_text()
sdkconfig = (root / "sdkconfig.defaults").read_text()

required_handlers = [
    "help", "version", "partitions", "mtd", "go", "reboot", "verify",
    "flash", "erase", "unlock", "dump", "jump", "xmdm", "sha1sum", "crc32", "baud",
]
missing = [name for name in required_handlers if f'strcmp(cmd, "{name}")' not in source]
if missing:
    print("Missing command handlers:", ", ".join(missing), file=sys.stderr)
    sys.exit(1)

for token in [
    'BLDR_VERSION             "2.1.0"',
    'bootloader_mmap(CONFIG_PARTITION_TABLE_OFFSET',
    'bootloader_munmap(idf_table)',
    'BLDR_VCS_ANCHOR_LABEL    "vcs_table"',
    'BLDR_VCS_MAGIC           "VCS1"',
    '"partition.vcs table/CRC32/layout"',
    'verify_native_kernel_image',
    'esp_image_verify(ESP_IMAGE_VERIFY',
    'bootloader_utility_load_boot_image(&os_state, FACTORY_INDEX)',
    'ramdisk remains on flash',
    'post_self_test()',
    'crc32_ieee_update',
    'verify_os_payload_partition',
    'bldr_psram_init();',
    'bldr_psram_ready()',
    'bldr_psram_range_valid',
    'Internal SRAM/IRAM is private to the bootloader',
    'BLDR_XMODEM_SESSION_TIMEOUT_MS 15000U',
    'BLDR_XMODEM_C_INTERVAL_MS      1000U',
    'xmodem_report_received(received)',
    'Keep waiting (without sending more \'C\') until the one absolute 15-second deadline.',
    'WARNING: erasing MTD partition',
    'Usage: erase <mtd-label> OR erase <flash_addr> <blocks-of-4096-bytes>',
    'PSRAM init and mapped range',
]:
    if token not in source:
        raise SystemExit(f"Missing required implementation token: {token}")

if '# ESP32-OS Bootloader v2.1.0' not in readme:
    raise SystemExit("README version mismatch")
if 'BUILD_VERSION: "2.1.0"' not in workflow or '0x21000 ../partition.vcs' not in workflow:
    raise SystemExit("Workflow version or custom table merge step missing")
if 'bootloader.elf' not in workflow or 'bootloader.map' not in workflow or 'application-size-summary.txt' not in workflow:
    raise SystemExit("Workflow must retain bootloader ELF/map and size summary")
if 'driver' in cmake.split('PRIV_REQUIRES', 1)[1].split('PRIV_INCLUDE_DIRS', 1)[0].split():
    raise SystemExit("PSRAM early-init source must not pull the application driver component into the bootloader")
if 'esp_app_desc.h' in main_c:
    raise SystemExit("Recovery app reintroduced unsupported esp_app_desc.h include")
if 'CONFIG_PARTITION_TABLE_CUSTOM=y' not in sdkconfig:
    raise SystemExit("ESP-IDF custom primary partition table is not enabled")
for token in [
    'CONFIG_ESP32S3_SPIRAM_SUPPORT=y',
    'CONFIG_SPIRAM_MODE_OCT=y',
    'CONFIG_SPIRAM_SPEED_40M=y',
    'CONFIG_SPIRAM_BOOT_INIT=y',
    'CONFIG_SPIRAM_IGNORE_NOTFOUND=y',
]:
    if token not in sdkconfig:
        raise SystemExit(f"Missing PSRAM configuration: {token}")

# Confirm source-level integration uses the exact ESP-IDF v4.4.7 octal driver,
# initializes hardware, and maps the detected capacity rather than a fixed base.
for token in [
    'opiram_psram.c', 'spi_timing_config.c', 'spi_flash_timing_tuning.c',
    'psram_enable(PSRAM_CACHE_S40M, PSRAM_VADDR_MODE_NORMAL)',
    'psram_get_size()', 'Cache_Dbus_MMU_Set(MMU_ACCESS_SPIRAM, base, 0, 64, size >> 16, 0)',
    'map_high - size', 'BLDR_PSRAM_RESERVED_BYTES',
    'bldr_memory_range_within(addr, len, s_psram_base, s_psram_size',
    'spi_flash_set_vendor_required_regs',
]:
    if token not in cmake + mem_c:
        raise SystemExit(f"PSRAM/flash integration token missing: {token}")
if '0x3D000000U' in mem_h + mem_c:
    raise SystemExit("Fixed 0x3D000000 PSRAM base must not return")
if 'esp_spiram_init(' in mem_c or 'esp_spiram_init_cache(' in mem_c:
    raise SystemExit("Bootloader must not call app-only spiram wrapper/cache initialization")

# Internal RAM buffers may exist only as private implementation details; no public
# monitor command exposes them as accepted user addresses or jump targets.
for forbidden in [
    'range_in_buffer', 'g_exec_payload', 'g_exec_payload_valid', 'g_xmodem_packet_words',
    'BLDR_EXEC_BUFFER_SIZE',
]:
    if forbidden in source:
        raise SystemExit(f"Legacy monitor buffer exposure or obsolete symbol remains: {forbidden}")
if 'jump is disabled in v2.1.0' not in source:
    raise SystemExit("The arbitrary RAM execution command must remain disabled")
if '#define BLDR_RAM_BUFFER_SIZE     256U' not in source:
    raise SystemExit("Internal POST buffer must remain capped at 256 bytes")
if '#define BLDR_XMODEM_PACKET_BUFFER_SIZE 1024U' not in source:
    raise SystemExit("XMODEM must use one fixed 1-KiB packet staging buffer")
if '#define BLDR_FLASH_IO_CHUNK      256U' not in source:
    raise SystemExit("Flash I/O scratch chunk must remain 256 bytes")
if 'if (partition_writes_encrypted(p) && (((addr | len) & 15U) != 0U))' not in source:
    raise SystemExit("Encrypted writes must follow the ESP-IDF 16-byte alignment contract")

# Source order invariant: packet bytes are staged before validation, but no target
# write happens until complement/sequence/CRC are checked.
stage = source.index('g_xmodem_packet[i + j] = quartet[j]')
crc_check = source.index('if ((uint8_t)(block + block_inv) != 0xFFU || packet_crc != want_crc)')
psram_commit = source.index('bldr_psram_write(ram_addr + received, g_xmodem_packet, payload_len)')
flash_commit = source.index('flash_write_packet(flash_addr + received, 0U, payload_len')
if not (stage < crc_check < psram_commit < flash_commit or stage < crc_check < flash_commit < psram_commit):
    raise SystemExit("XMODEM target commit must follow full block/sequence/CRC validation")
if '(payload_len == packet_len)' in source:
    raise SystemExit("XMODEM flash path still rejects a valid partial final block")

# Host-run the exact production range policy helper against boundary, invalid
# memory-region, and overflow cases. No hardware address is dereferenced.
compiler = 'gcc'
with tempfile.TemporaryDirectory(prefix='bldr-memory-test-') as td:
    exe = Path(td) / 'test_memory_policy'
    cmd = [compiler, '-std=c11', '-Wall', '-Wextra', '-Werror',
           '-I', str(root / 'bootloader_components/bldr_hooks'),
           str(root / 'tests/test_memory_policy.c'), '-o', str(exe)]
    subprocess.run(cmd, check=True, capture_output=True, text=True)
    subprocess.run([str(exe)], check=True)

# Independently verify the generated VCS table header, row CRC, and geometry.
vcs = (root / "partition.vcs").read_bytes()
try:
    header, row_bytes = vcs.split(b"\n", 1)
    fields = header.decode("ascii").split(",")
    assert fields[0] == "VCS1" and int(fields[1]) == 1
    entry_count = int(fields[2])
    total_size = int(fields[3], 0)
    expected_crc = int(fields[4], 0)
except Exception as exc:
    raise SystemExit(f"Invalid partition.vcs header: {exc}")
if total_size != len(vcs) or (zlib.crc32(row_bytes) & 0xFFFFFFFF) != expected_crc:
    raise SystemExit("partition.vcs byte length or CRC32 is incorrect")
rows = []
for line in row_bytes.decode("ascii").splitlines():
    row = line.split(",")
    if len(row) != 5:
        raise SystemExit(f"Invalid VCS row: {line!r}")
    name, offset, size, flags, kind = row
    rows.append((name, int(offset, 0), int(size, 0), flags, kind))
if len(rows) != entry_count:
    raise SystemExit("partition.vcs entry count mismatch")
required = {"kernel", "rootfs", "ramdisk", "rootfs_data", "romfile"}
if {r[0] for r in rows} != required:
    raise SystemExit("partition.vcs must contain exactly the five required ESP-OS regions")
ordered = sorted(rows, key=lambda r: r[1])
for i, r in enumerate(ordered):
    name, offset, size, flags, kind = r
    if offset % 0x1000 or size <= 0 or size % 0x1000 or offset + size > 0x1000000:
        raise SystemExit(f"Invalid flash bounds/alignment for {name}")
    if i and ordered[i - 1][1] + ordered[i - 1][2] > offset:
        raise SystemExit(f"Overlapping custom regions near {name}")
if ordered[-1][1] + ordered[-1][2] != 0x1000000:
    raise SystemExit("Custom table does not end at the configured 16-MiB flash boundary")

# Validate the starter ROMF payload that CI writes at 0xFFF000.
romfile = (root / "romfile.bin").read_bytes()
if len(romfile) < 17 or romfile[:4] != b"ROMF":
    raise SystemExit("romfile.bin has no ROMF header or empty payload")
rom_version, rom_size, rom_crc = struct.unpack("<III", romfile[4:16])
rom_payload = romfile[16:]
if rom_version != 1 or rom_size != len(rom_payload) or (zlib.crc32(rom_payload) & 0xFFFFFFFF) != rom_crc:
    raise SystemExit("romfile.bin header length/CRC32 is incorrect")
if len(romfile) > 0x1000:
    raise SystemExit("romfile.bin exceeds the 4-KiB ROMF partition")

# The source CSV and generated table must stay synchronized.
generator_result = subprocess.run(
    [sys.executable, str(root / "tools/generate_partition_vcs.py")],
    check=True, capture_output=True, text=True,
)
if "Generated partition.vcs" not in generator_result.stdout:
    raise SystemExit("partition.vcs generator did not produce its expected status")

help_block = source[source.index("static void print_help(void)"):
                    source.index("static void print_command_help")]
for name in ["flash", "dump", "xmdm", "crc32", "sha1sum", "erase", "unlock", "go", "reboot", "version"]:
    if name not in help_block:
        raise SystemExit(f"Command '{name}' missing from top-level help")

print("PASS: monitor commands; PSRAM driver/mapping contract; private SRAM buffers; XMODEM CRC-before-commit; host range-policy tests; VCS geometry/CRC; ROMF header/CRC")

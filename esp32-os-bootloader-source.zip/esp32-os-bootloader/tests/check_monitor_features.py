from pathlib import Path
import csv
import re
import subprocess
import sys
import zlib

root = Path(__file__).resolve().parents[1]
source = (root / "bootloader_components/bldr_hooks/hooks.c").read_text()
readme = (root / "README.md").read_text()
workflow = (root / ".github/workflows/build_v2.0.0.yml").read_text()
main_c = (root / "main/main.c").read_text()

required_handlers = [
    "info", "partitions", "mtd", "verify", "flash", "erase", "unlock",
    "memwl", "dump", "jump", "memrl", "xmdm", "sha1sum", "crc32", "cpufreq", "baud",
]
missing = [name for name in required_handlers if f'strcmp(cmd, "{name}")' not in source]
if missing:
    print("Missing command handlers:", ", ".join(missing), file=sys.stderr)
    sys.exit(1)

for token in [
    'BLDR_VERSION             "2.0.0"',
    'bootloader_mmap(CONFIG_PARTITION_TABLE_OFFSET',
    'bootloader_munmap(idf_table)',
    'BLDR_VCS_ANCHOR_LABEL    "vcs_table"',
    'BLDR_VCS_MAGIC           "VCS1"',
    '"partition.vcs table/CRC32/layout"',
    'verify_native_kernel_image',
    'esp_image_verify(ESP_IMAGE_VERIFY',
    'bootloader_utility_load_boot_image(&os_state, FACTORY_INDEX)',
    'ramdisk remains on flash',
    'Ramdisk header/payload CRC32 (not loaded here)',
    'copy_monitor_buffer_to_io',
    'copy_xmodem_packet_to_io',
    'if (!to_flash && to_exec) g_exec_payload_valid = false;',
    'if (dst_exec) g_exec_payload_valid = false;',
    'max_len & (BLDR_SECTOR_SIZE - 1U)',
    'crc16_xmodem_update',
    'bootloader_flash_erase_sector',
    'bootloader_flash_write',
    'range_in_buffer',
    'BLDR_XMODEM_SESSION_TIMEOUT_MS 15000U',
    'BLDR_XMODEM_C_INTERVAL_MS      1000U',
    'xmodem_report_received(received)',
    "Keep waiting (without sending more 'C') until the one absolute 15-second deadline.",
    'strcmp(cmd, "?") == 0',
    'memrl <ram_addr> <len>',
    'memwl <ram_addr> <32-bit-value>',
    'WARNING: erasing MTD partition',
    'Usage: erase <mtd-label> OR erase <flash_addr> <blocks-of-4096-bytes>',
    'post_self_test()',
    'crc32_ieee_update',
    'verify_os_payload_partition',
]:
    if token not in source:
        print(f"Missing required implementation token: {token}", file=sys.stderr)
        sys.exit(1)

if '# ESP32-OS Bootloader v2.0.0' not in readme:
    raise SystemExit("README version mismatch")
if 'BUILD_VERSION: "2.0.0"' not in workflow or '0x21000 ../partition.vcs' not in workflow:
    raise SystemExit("Workflow version or custom table merge step missing")
if 'esp_app_desc.h' in main_c:
    raise SystemExit("Recovery app reintroduced unsupported esp_app_desc.h include")
if 'CONFIG_PARTITION_TABLE_CUSTOM=y' not in (root / 'sdkconfig.defaults').read_text():
    raise SystemExit("ESP-IDF custom primary partition table is not enabled")

# Independently verify the generated VCS table header, row CRC, and exact geometry.
vcs = (root / "partition.vcs").read_bytes()
try:
    header, row_bytes = vcs.split(b"\n", 1)
    fields = header.decode("ascii").split(",")
    assert fields[0] == "VCS1" and int(fields[1]) == 1
    entry_count = int(fields[2])
    total_size = int(fields[3], 0)
    expected_crc = int(fields[4], 0)
except Exception as exc:
    raise SystemExit(f"Invalid partition.vcs header: {exc}")
if total_size != len(vcs) or (zlib.crc32(row_bytes) & 0xFFFFFFFF) != expected_crc:
    raise SystemExit("partition.vcs byte length or CRC32 is incorrect")
rows = []
for line in row_bytes.decode("ascii").splitlines():
    row = line.split(",")
    if len(row) != 5:
        raise SystemExit(f"Invalid VCS row: {line!r}")
    name, offset, size, flags, kind = row
    rows.append((name, int(offset, 0), int(size, 0), flags, kind))
if len(rows) != entry_count:
    raise SystemExit("partition.vcs entry count mismatch")
required = {"kernel", "rootfs", "ramdisk", "rootfs_data", "romfile"}
if {r[0] for r in rows} != required:
    raise SystemExit("partition.vcs must contain exactly the five required ESP-OS regions")
ordered = sorted(rows, key=lambda r: r[1])
for i, r in enumerate(ordered):
    name, offset, size, flags, kind = r
    if offset % 0x1000 or size <= 0 or size % 0x1000 or offset + size > 0x1000000:
        raise SystemExit(f"Invalid flash bounds/alignment for {name}")
    if i and ordered[i - 1][1] + ordered[i - 1][2] > offset:
        raise SystemExit(f"Overlapping custom regions near {name}")
if ordered[-1][1] + ordered[-1][2] != 0x1000000:
    raise SystemExit("Custom table does not end at the configured 16-MiB flash boundary")

# Validate the starter ROMF payload that CI writes at 0xFFF000.
romfile = (root / "romfile.bin").read_bytes()
if len(romfile) < 17 or romfile[:4] != b"ROMF":
    raise SystemExit("romfile.bin has no ROMF header or empty payload")
import struct
rom_version, rom_size, rom_crc = struct.unpack("<III", romfile[4:16])
rom_payload = romfile[16:]
if rom_version != 1 or rom_size != len(rom_payload) or (zlib.crc32(rom_payload) & 0xFFFFFFFF) != rom_crc:
    raise SystemExit("romfile.bin header length/CRC32 is incorrect")
if len(romfile) > 0x1000:
    raise SystemExit("romfile.bin exceeds the 4-KiB ROMF partition")

# The source CSV and checked-in generated table must stay synchronized.
generator_result = subprocess.run(
    [sys.executable, str(root / "tools/generate_partition_vcs.py")],
    check=True, capture_output=True, text=True,
)
if "Generated partition.vcs" not in generator_result.stdout:
    raise SystemExit("partition.vcs generator did not produce its expected status")

help_block = source[source.index("static void print_help(void)"):
                    source.index("static void print_command_help")]
for name in required_handlers:
    if name not in help_block:
        print(f"Command '{name}' missing from top-level help", file=sys.stderr)
        sys.exit(1)

for forbidden in [
    "BLDR_XMODEM_WRITE_BUFFER_SIZE", "g_write_buffer", "g_partition_table_storage",
    "BLDR_XMODEM_IDLE_TIMEOUT", "BLDR_XMODEM_RETRY_MAX", "BLDR_XMODEM_BYTE_TIMEOUT",
]:
    if forbidden in source:
        print(f"Removed high-memory object reintroduced: {forbidden}", file=sys.stderr)
        sys.exit(1)
if "#define BLDR_FLASH_IO_CHUNK      256U" not in source:
    raise SystemExit("Flash I/O scratch chunk must remain 256 bytes")
if "if (partition_writes_encrypted(p) && (((addr | len) & 15U) != 0U))" not in source:
    raise SystemExit("Encrypted writes must follow the ESP-IDF 16-byte alignment contract")
if "#define BLDR_RAM_BUFFER_SIZE     512U" not in source:
    raise SystemExit("Monitor data buffer must remain bounded to 512 bytes")

print(f"PASS: {len(required_handlers)} commands; VCS CRC/layout; custom kernel handoff; XIP-native image validation; ramdisk stays on flash until kernel; XMODEM and bounded buffers")

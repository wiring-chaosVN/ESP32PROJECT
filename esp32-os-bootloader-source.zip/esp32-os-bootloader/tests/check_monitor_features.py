from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
source = (root / "bootloader_components/bldr_hooks/hooks.c").read_text()
readme = (root / "README.md").read_text()

required_handlers = [
    "info", "partitions", "mtd", "verify", "flash", "erase", "unlock",
    "memwl", "dump", "jump", "memrl", "xmdm", "sha1sum", "cpufreq", "baud",
]
missing = [name for name in required_handlers if f'strcmp(cmd, "{name}")' not in source]
if missing:
    print("Missing command handlers:", ", ".join(missing), file=sys.stderr)
    sys.exit(1)

for token in [
    "bootloader_mmap(CONFIG_PARTITION_TABLE_OFFSET",
    "bootloader_munmap(table)",
    "copy_monitor_buffer_to_io",
    "copy_xmodem_packet_to_io",
    "if (!to_flash && to_exec) g_exec_payload_valid = false;",
    "if (dst_exec) g_exec_payload_valid = false;",
    "max_len & (BLDR_SECTOR_SIZE - 1U)",
    "crc16_xmodem_update",
    "bootloader_flash_erase_sector",
    "bootloader_flash_write",
    "esp_image_verify",
    "range_in_buffer",
]:
    if token not in source:
        print(f"Missing required implementation token: {token}", file=sys.stderr)
        sys.exit(1)

help_block = source[source.index("static void print_help(void)"):
                    source.index("static void print_command_help")]
for name in required_handlers:
    if name not in help_block:
        print(f"Command '{name}' missing from top-level help", file=sys.stderr)
        sys.exit(1)

# Guard against reintroducing large static data buffers into bootloader DRAM.
for forbidden in ["BLDR_XMODEM_WRITE_BUFFER_SIZE", "g_write_buffer", "g_partition_table_storage"]:
    if forbidden in source:
        print(f"Removed high-memory object reintroduced: {forbidden}", file=sys.stderr)
        sys.exit(1)
if "#define BLDR_FLASH_IO_CHUNK      256U" not in source:
    print("Flash I/O scratch chunk must remain 256 bytes", file=sys.stderr)
    sys.exit(1)
if "if (partition_writes_encrypted(p) && (((addr | len) & 15U) != 0U))" not in source:
    print("Encrypted writes must follow the ESP-IDF 16-byte alignment contract", file=sys.stderr)
    sys.exit(1)
if "#define BLDR_RAM_BUFFER_SIZE     512U" not in source:
    print("Monitor data buffer must remain bounded to 512 bytes", file=sys.stderr)
    sys.exit(1)
if '#define BLDR_VERSION             "1.1.2"' not in source:
    print("Source version mismatch", file=sys.stderr)
    sys.exit(1)
if "# ESP32-OS Bootloader v1.1.2" not in readme:
    print("README version mismatch", file=sys.stderr)
    sys.exit(1)

print(f"PASS: {len(required_handlers)} commands; chunked I/O; mmap partition table; no 64-KiB static DRAM buffer")

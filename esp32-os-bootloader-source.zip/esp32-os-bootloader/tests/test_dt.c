/*
 * SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
 * SPDX-License-Identifier: GPL-3.0-only
 */
/* Host driver for bldr_dt.c.
 *   test_dt <file.dtb>              print the parsed display config as key=value
 *   test_dt --fuzz <file.dtb> <n>   parse n randomly corrupted copies (build with ASAN/UBSAN) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bldr_dt.h"

static uint8_t *slurp(const char *path, long *n)
{
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END); *n = ftell(f); fseek(f, 0, SEEK_SET);
    uint8_t *b = (uint8_t *)malloc((size_t)*n ? (size_t)*n : 1U);
    if (fread(b, 1, (size_t)*n, f) != (size_t)*n) { fclose(f); free(b); return NULL; }
    fclose(f);
    return b;
}

int main(int argc, char **argv)
{
    long n = 0;
    if (argc == 4 && strcmp(argv[1], "--fuzz") == 0) {
        uint8_t *orig = slurp(argv[2], &n);
        if (!orig) return 2;
        srand(12345);
        for (int it = 0; it < atoi(argv[3]); ++it) {
            long len = n;
            if (rand() % 4 == 0) len = rand() % (n + 1);          /* truncate */
            uint8_t *b = (uint8_t *)malloc((size_t)len ? (size_t)len : 1U);  /* exact size: ASAN catches OOB */
            memcpy(b, orig, (size_t)len);
            for (int k = rand() % 8; k > 0 && len > 0; --k) b[rand() % len] = (uint8_t)rand();
            bldr_dt_t t;
            (void)bldr_dt_parse(b, (uint32_t)len, &t);
            free(b);
        }
        free(orig);
        puts("fuzz ok");
        return 0;
    }
    if (argc != 2) return 2;
    uint8_t *b = slurp(argv[1], &n);
    if (!b) return 2;
    bldr_dt_t t;
    const int rc = bldr_dt_parse(b, (uint32_t)n, &t);
    const bldr_dt_display_t *d = &t.display;
    printf("rc=%d listed=%d usable=%d note=%s w=%u h=%u rot=%u xoff=%u yoff=%u "
           "sck=%d mosi=%d cs=%d dc=%d rst=%d bl=%d bgr=%d inv=%d blal=%d\n",
           rc, d->listed, d->usable, d->note ? d->note : "-", d->width, d->height, d->rotation,
           d->xoff, d->yoff, d->sck, d->mosi, d->cs, d->dc, d->rst, d->bl, d->bgr, d->invert,
           d->bl_active_low);
    free(b);
    return 0;
}

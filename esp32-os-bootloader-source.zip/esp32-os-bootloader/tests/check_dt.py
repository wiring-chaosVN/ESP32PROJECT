#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Wiring-ChaosVN by Nick
# SPDX-License-Identifier: GPL-3.0-only
"""Host tests for the bootloader's DTB reader (needs dtc and gcc)."""
from pathlib import Path
import re, subprocess, sys, tempfile

root = Path(__file__).resolve().parents[1]
hooks = root / "bootloader_components/bldr_hooks"
board = (root / "board.dts").read_text()


def sh(*a, **k):
    return subprocess.run(a, check=True, capture_output=True, text=True, **k)


def main():
    with tempfile.TemporaryDirectory(prefix="bldr-dt-") as td:
        td = Path(td)
        exe = td / "test_dt"
        san = td / "test_dt_asan"
        src = [str(root / "tests/test_dt.c"), str(hooks / "bldr_dt.c"), "-I", str(hooks)]
        sh("gcc", "-std=c11", "-Wall", "-Wextra", "-Werror", *src, "-o", str(exe))
        sh("gcc", "-std=c11", "-g", "-fsanitize=address,undefined", "-fno-sanitize-recover=all", *src, "-o", str(san))

        def run(dts_text=None, dtb_bytes=None):
            p = td / "x.dtb"
            if dts_text is not None:
                (td / "x.dts").write_text(dts_text)
                sh("dtc", "-q", "-I", "dts", "-O", "dtb", "-o", str(p), str(td / "x.dts"))
            else:
                p.write_bytes(dtb_bytes)
            out = sh(str(exe), str(p)).stdout.strip()
            return dict(kv.split("=", 1) for kv in out.split(" ") if "=" in kv)

        def expect(r, **kw):
            for k, v in kw.items():
                if r.get(k) != str(v):
                    raise SystemExit(f"FAIL {kw}: got {r}")

        # The shipped board.dts must parse to a usable ST7735S config.
        r = run(board)
        expect(r, rc=0, listed=1, usable=1, w=128, h=160, rot=2, sck=12, mosi=11, cs=10, dc=9, rst=8, bl=7, bgr=1, inv=0)

        # No display node: valid DTB, display simply not listed.
        r = run("/dts-v1/;\n/ { model = \"x\"; uart0: serial { status = \"okay\"; }; };\n")
        expect(r, rc=0, listed=0, usable=0)

        def variant(old, new):
            assert old in board, old
            return board.replace(old, new, 1)

        expect(run(variant('status = "okay";\n    };\n};', 'status = "disabled";\n    };\n};')), listed=0, usable=0)
        expect(run(variant("sitronix,st7735s", "sitronix,st7789v")), listed=1, usable=0, note="unsupported")
        expect(run(variant("dc-gpios = <9>", "dc-gpios = <23>")), usable=0)         # GPIO23 does not exist on S3
        expect(run(variant("dc-gpios = <9>", "dc-gpios = <30>")), usable=0)         # flash pin
        expect(run(variant("dc-gpios = <9>", "dc-gpios = <10>")), usable=0, note="duplicate")
        expect(run(variant('bus = "spi2"', 'bus = "spi9"')), usable=0)
        expect(run(variant("rotation = <2>", "rotation = <7>")), usable=0)
        expect(run(variant("width = <128>", "width = <10>")), usable=0)
        expect(run(variant('sck-gpios = <12>;', '')), usable=0)
        # Optional pins: no CS / reset / backlight is fine.
        r = run(variant("cs-gpios = <10>;", "").replace("reset-gpios = <8>;", "").replace("backlight-gpios = <7>;", ""))
        expect(r, usable=1, cs=-1, rst=-1, bl=-1)
        # Pins above 31 use the second GPIO bank.
        expect(run(variant("backlight-gpios = <7>", "backlight-gpios = <40>")), usable=1, bl=40)
        r = run(variant("/* x-offset = <2>; y-offset = <1>; */", "x-offset = <2>; y-offset = <1>; invert;")
                .replace('color-order = "bgr"', 'color-order = "rgb"'))
        expect(r, usable=1, xoff=2, yoff=1, inv=1, bgr=0)

        # Structural errors are rejected, not parsed.
        good = (td / "x.dtb")
        run(board)
        d = good.read_bytes()
        assert run(dtb_bytes=b"\x00" * 4 + d[4:])["rc"] == "2", "bad magic"
        assert run(dtb_bytes=d[:20])["rc"] != "0", "truncated header"
        assert run(dtb_bytes=d[:len(d) // 2])["rc"] != "0", "truncated body"

        # Fuzz under ASAN/UBSAN: corrupted blobs must never read out of bounds.
        run(board)
        out = sh(str(san), "--fuzz", str(good), "20000").stdout
        if "fuzz ok" not in out:
            raise SystemExit("fuzz run failed")
    print("PASS: DTB reader (shipped board.dts, optional pins, error cases, 20000-case ASAN fuzz)")


if __name__ == "__main__":
    main()

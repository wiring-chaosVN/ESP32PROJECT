#include <assert.h>
#include <stdint.h>
#include "bldr_memory.h"

int main(void)
{
    /* An 8-MiB ESP32-S3 N16R8 PSRAM occupies [0x3D800000, 0x3E000000). */
    const uint32_t base = 0x3D800000U;
    const uint32_t size = 0x00800000U;
    const uint32_t reserved = 0x1000U;
    const uint32_t user = base + reserved;
    const uint32_t end = base + size; /* exclusive */

    assert(bldr_memory_range_within(user, 1U, base, size, reserved));
    assert(bldr_memory_range_within(end - 1U, 1U, base, size, reserved));
    assert(bldr_memory_range_within(user, size - reserved, base, size, reserved));

    assert(!bldr_memory_range_within(base, 1U, base, size, reserved));
    assert(!bldr_memory_range_within(base + reserved - 1U, 1U, base, size, reserved));
    assert(!bldr_memory_range_within(user - 1U, 2U, base, size, reserved));
    assert(!bldr_memory_range_within(end, 1U, base, size, reserved));
    assert(!bldr_memory_range_within(end - 2U, 4U, base, size, reserved));
    assert(!bldr_memory_range_within(user, 0U, base, size, reserved));

    /* Addresses in internal DRAM, IRAM, flash mapping, and MMIO are outside PSRAM. */
    assert(!bldr_memory_range_within(0x3FC88000U, 4U, base, size, reserved));
    assert(!bldr_memory_range_within(0x40378000U, 4U, base, size, reserved));
    assert(!bldr_memory_range_within(0x42000000U, 4U, base, size, reserved));
    assert(!bldr_memory_range_within(0x60000000U, 4U, base, size, reserved));

    /* Reject arithmetic overflow and invalid/mis-sized device ranges. */
    assert(!bldr_memory_range_within(0xFFFFFFF0U, 0x30U, base, size, reserved));
    assert(!bldr_memory_range_within(user, 4U, base, reserved, reserved));
    assert(!bldr_memory_range_within(user, 4U, 0xFFFFFFF0U, 0x40U, 0x10U));
    assert(!bldr_memory_range_within(user, 4U, base, size, size));
    return 0;
}

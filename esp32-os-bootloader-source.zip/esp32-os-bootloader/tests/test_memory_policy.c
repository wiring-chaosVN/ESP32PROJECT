#include <assert.h>
#include <stdint.h>
#include "bldr_memory.h"

int main(void)
{
    /* An 8-MiB ESP32-S3 N16R8 PSRAM occupies [0x3D800000, 0x3E000000). */
    const uint32_t base = 0x3D800000U;
    const uint32_t size = 0x00800000U;
    const uint32_t reserved = 0x1000U;
    const uint32_t user = base + reserved;
    const uint32_t end = base + size; /* exclusive */

    assert(bldr_memory_range_within(user, 1U, base, size, reserved));
    assert(bldr_memory_range_within(end - 1U, 1U, base, size, reserved));
    assert(bldr_memory_range_within(user, size - reserved, base, size, reserved));

    assert(!bldr_memory_range_within(base, 1U, base, size, reserved));
    assert(!bldr_memory_range_within(base + reserved - 1U, 1U, base, size, reserved));
    assert(!bldr_memory_range_within(user - 1U, 2U, base, size, reserved));
    assert(!bldr_memory_range_within(end, 1U, base, size, reserved));
    assert(!bldr_memory_range_within(end - 2U, 4U, base, size, reserved));
    assert(!bldr_memory_range_within(user, 0U, base, size, reserved));

    /* Addresses in internal DRAM, IRAM, flash mapping, and MMIO are outside PSRAM. */
    assert(!bldr_memory_range_within(0x3FC88000U, 4U, base, size, reserved));
    assert(!bldr_memory_range_within(0x40378000U, 4U, base, size, reserved));
    assert(!bldr_memory_range_within(0x42000000U, 4U, base, size, reserved));
    assert(!bldr_memory_range_within(0x60000000U, 4U, base, size, reserved));

    /* Reject arithmetic overflow and invalid/mis-sized device ranges. */
    assert(!bldr_memory_range_within(0xFFFFFFF0U, 0x30U, base, size, reserved));
    assert(!bldr_memory_range_within(user, 4U, base, reserved, reserved));
    assert(!bldr_memory_range_within(user, 4U, 0xFFFFFFF0U, 0x40U, 0x10U));
    assert(!bldr_memory_range_within(user, 4U, base, size, size));

    /* NPIM header policy. */
    {
        const uint32_t first_entry = (base - 0x3C000000U) / 0x10000U; /* 0x180 for 8 MiB */
        const uint32_t addr = base + 0x10000U;
        bldr_npim_hdr_t h = {
            .magic = {'N', 'P', 'I', 'M'}, .version = 1, .flags = 1,
            .entry = 0x42000020U + 0x1000U, .vbase = 0x42000000U, .image_size = 0x30000U,
            .initramfs_off = 0x20000U, .initramfs_size = 0x8000U, .reserved = 0,
        };
        assert(bldr_npim_check(&h, addr, base, size, reserved, first_entry) == BLDR_NPIM_OK);
        assert(bldr_npim_check(&h, addr + 0x1000U, base, size, reserved, first_entry) == BLDR_NPIM_E_ALIGN);
        assert(bldr_npim_check(&h, base, base, size, reserved, first_entry) == BLDR_NPIM_E_RANGE); /* reserved page */
        bldr_npim_hdr_t t = h; t.magic[3] = 'X';
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_E_MAGIC);
        t = h; t.flags = 0;
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_E_FIELDS);
        t = h; t.image_size = size; /* runs past the end of PSRAM from addr */
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_E_RANGE);
        t = h; t.initramfs_off = 0x2F000U; t.initramfs_size = 0x2000U; /* beyond image */
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_E_FIELDS);
        t = h; t.initramfs_off = 0; t.initramfs_size = 0; /* no initramfs is fine */
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_OK);
        t = h; t.vbase = 0x3C000000U; /* not an instruction-bus address */
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_E_VADDR);
        t = h; t.vbase = 0x42000000U + (first_entry - 2U) * 0x10000U; /* would clobber PSRAM data window */
        t.entry = t.vbase + 0x1000U;
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_E_VADDR);
        t = h; t.entry = 0x42000000U + 0x30000U; /* entry past image end */
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_E_VADDR);
        t = h; t.entry = 0x42000002U;
        assert(bldr_npim_check(&t, addr, base, size, reserved, first_entry) == BLDR_NPIM_E_VADDR);
    }
    return 0;
}
